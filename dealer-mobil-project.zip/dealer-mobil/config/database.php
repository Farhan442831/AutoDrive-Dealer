<?php
/**
 * Konfigurasi Database & Konstanta Global
 * Lokasi: config/database.php
 */

// ---- Konfigurasi Database -------------------------------------------
define('DB_HOST', 'localhost');
define('DB_NAME', 'dealer_mobil');
define('DB_USER', 'root');
define('DB_PASS', '');          // Biarkan kosong jika pakai XAMPP default

// ---- Deteksi BASE_URL otomatis --------------------------------------
$docRoot = str_replace('\\', '/', rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/'));
$appRoot = str_replace('\\', '/', dirname(__DIR__));
$basePath = ($docRoot && strpos($appRoot, $docRoot) === 0)
    ? substr($appRoot, strlen($docRoot))
    : '';
define('BASE_URL', $basePath === '' ? '/' : $basePath . '/');

// ---- Path Upload -----------------------------------------------------
define('UPLOAD_PATH', __DIR__ . '/../assets/uploads/');
define('UPLOAD_URL',  BASE_URL . 'assets/uploads/');

// ---- Zona Waktu ------------------------------------------------------
date_default_timezone_set('Asia/Jakarta');

// ---- Session ---------------------------------------------------------
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---- Koneksi PDO -----------------------------------------------------
try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    die('<div style="font-family:sans-serif;padding:40px;max-width:600px;margin:auto">
            <h2 style="color:#c0392b">Koneksi Database Gagal</h2>
            <p>Pastikan MySQL pada XAMPP sudah berjalan dan database <b>dealer_mobil</b> sudah diimport.</p>
            <pre style="background:#f4f4f4;padding:12px;border-radius:6px">'
            . htmlspecialchars($e->getMessage()) . '</pre>
        </div>');
}