<?php
/**
 * Detail Artikel
 * Lokasi: detail_artikel.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . BASE_URL . 'artikel.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM artikel WHERE id = :id AND status = 'publish'");
$stmt->execute([':id' => $id]);
$artikel = $stmt->fetch();

if (!$artikel) {
    set_flash('danger', 'Artikel tidak ditemukan.');
    header('Location: ' . BASE_URL . 'artikel.php');
    exit;
}

// Update views
$pdo->prepare("UPDATE artikel SET views = views + 1 WHERE id = :id")->execute([':id' => $id]);

// Artikel terkait
$stmtR = $pdo->prepare("
    SELECT * FROM artikel
    WHERE status='publish' AND id != :id
      AND (kategori = :kat)
    ORDER BY created_at DESC
    LIMIT 3
");
$stmtR->execute([':id' => $id, ':kat' => $artikel['kategori']]);
$terkait = $stmtR->fetchAll();

// Kalau kurang dari 3, ambil yang lain
if (count($terkait) < 3) {
    $stmtR2 = $pdo->prepare("
        SELECT * FROM artikel
        WHERE status='publish' AND id != :id
        ORDER BY created_at DESC
        LIMIT 3
    ");
    $stmtR2->execute([':id' => $id]);
    $terkait = $stmtR2->fetchAll();
}

$pageTitle = $artikel['judul'];
$pageDesc  = $artikel['ringkasan'];

include __DIR__ . '/includes/header.php';
?>

<div class="breadcrumb-bar">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-2">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Home</a></li>
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>artikel.php">Artikel</a></li>
        <li class="breadcrumb-item active"><?= e(potong($artikel['judul'], 40)) ?></li>
      </ol>
    </nav>
    <h1 style="font-size:clamp(1.3rem,1rem+1.4vw,1.85rem);line-height:1.35;max-width:820px">
      <?= e($artikel['judul']) ?>
    </h1>
    <div class="d-flex flex-wrap gap-3 mt-3" style="color:rgba(255,255,255,.65);font-size:13px">
      <span><i class="fa-regular fa-user me-1"></i><?= e($artikel['penulis']) ?></span>
      <span><i class="fa-regular fa-calendar me-1"></i><?= tanggal_id($artikel['created_at']) ?></span>
      <span><i class="fa-regular fa-eye me-1"></i><?= (int)$artikel['views'] + 1 ?>x dibaca</span>
      <span><i class="fa-solid fa-tag me-1"></i><?= e($artikel['kategori']) ?></span>
    </div>
  </div>
</div>

<section class="section">
  <div class="container">
    <div class="row g-5">

      <div class="col-lg-8">
        <article class="detail-box">
          <img src="<?= img_aset($artikel['thumbnail'], 'artikel') ?>"
               alt="<?= e($artikel['judul']) ?>" class="img-fluid rounded mb-4"
               style="width:100%;max-height:420px;object-fit:cover">

          <div class="artikel-isi">
            <?= nl2br(e($artikel['isi'])) ?>
          </div>

          <div class="mt-5 pt-4" style="border-top:1px solid var(--line)">
            <div class="d-flex flex-wrap gap-2 align-items-center justify-content-between">
              <div>
                <span class="text-muted" style="font-size:13px">Bagikan artikel ini:</span>
              </div>
              <div class="d-flex gap-2">
                <a href="https://wa.me/?text=<?= rawurlencode($artikel['judul'] . ' - ' . BASE_URL . 'detail_artikel.php?id=' . $artikel['id']) ?>"
                   target="_blank" rel="noopener" class="btn btn-wa btn-sm">
                  <i class="fa-brands fa-whatsapp me-1"></i>WhatsApp
                </a>
                <a href="https://www.facebook.com/sharer/sharer.php?u=<?= rawurlencode(BASE_URL . 'detail_artikel.php?id=' . $artikel['id']) ?>"
                   target="_blank" rel="noopener" class="btn btn-navy btn-sm">
                  <i class="fa-brands fa-facebook-f me-1"></i>Facebook
                </a>
                <button type="button" class="btn btn-ghost btn-sm btn-copy-link"
                        data-link="<?= BASE_URL ?>detail_artikel.php?id=<?= (int)$artikel['id'] ?>">
                  <i class="fa-solid fa-link me-1"></i>Copy Link
                </button>
              </div>
            </div>
          </div>
        </article>

        <div class="mt-4">
          <a href="<?= BASE_URL ?>artikel.php" class="btn btn-ghost">
            <i class="fa-solid fa-arrow-left me-2"></i>Kembali ke Artikel
          </a>
        </div>
      </div>

      <div class="col-lg-4">
        <div class="detail-box mb-4">
          <h6 class="mb-3"><i class="fa-solid fa-circle-info text-orange me-2"></i>Tentang Artikel</h6>
          <div class="d-flex flex-column gap-2" style="font-size:13.5px">
            <div class="d-flex justify-content-between">
              <span class="text-muted">Kategori</span>
              <strong><?= e($artikel['kategori']) ?></strong>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted">Penulis</span>
              <strong><?= e($artikel['penulis']) ?></strong>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted">Tanggal</span>
              <strong><?= tanggal_id($artikel['created_at']) ?></strong>
            </div>
            <div class="d-flex justify-content-between">
              <span class="text-muted">Dibaca</span>
              <strong><?= (int)$artikel['views'] + 1 ?>x</strong>
            </div>
          </div>
        </div>

        <div class="p-4 rounded-lg mb-4" style="background:linear-gradient(160deg,#0f2440,#1b3a66);color:#fff">
          <h6 class="text-white mb-2">Butuh Mobil Berkualitas?</h6>
          <p style="color:rgba(255,255,255,.75);font-size:13.5px">
            Lihat koleksi mobil bekas berkualitas kami atau konsultasi gratis dengan tim.
          </p>
          <a href="<?= BASE_URL ?>katalog.php" class="btn btn-brand w-100 mb-2">
            <i class="fa-solid fa-car me-2"></i>Lihat Katalog
          </a>
          <a href="<?= wa_link('Halo, saya ingin konsultasi membeli mobil') ?>"
             target="_blank" rel="noopener" class="btn btn-wa w-100">
            <i class="fa-brands fa-whatsapp me-2"></i>Konsultasi
          </a>
        </div>

        <?php if ($terkait): ?>
          <div class="detail-box">
            <h6 class="mb-3"><i class="fa-solid fa-fire text-orange me-2"></i>Artikel Terkait</h6>
            <div class="d-flex flex-column gap-3">
              <?php foreach ($terkait as $t): ?>
                <a href="<?= BASE_URL ?>detail_artikel.php?id=<?= (int)$t['id'] ?>"
                   class="text-decoration-none text-dark">
                  <div class="d-flex gap-3">
                    <img src="<?= img_aset($t['thumbnail'], 'artikel') ?>" alt=""
                         style="width:80px;height:60px;object-fit:cover;border-radius:8px;flex-shrink:0">
                    <div>
                      <strong style="font-size:13.5px;line-height:1.35;display:block">
                        <?= e(potong($t['judul'], 55)) ?>
                      </strong>
                      <small class="text-muted"><?= tanggal_id($t['created_at']) ?></small>
                    </div>
                  </div>
                </a>
              <?php endforeach; ?>
            </div>
          </div>
        <?php endif; ?>
      </div>

    </div>
  </div>
</section>

<script>
document.querySelectorAll('.btn-copy-link').forEach(function(btn){
  btn.addEventListener('click', function(){
    navigator.clipboard.writeText(this.dataset.link).then(() => {
      const original = this.innerHTML;
      this.innerHTML = '<i class="fa-solid fa-check me-1"></i>Copied!';
      this.classList.add('btn-brand');
      setTimeout(() => {
        this.innerHTML = original;
        this.classList.remove('btn-brand');
      }, 1500);
    });
  });
});
</script>

<style>
.artikel-isi{
  font-size:15px;
  line-height:1.9;
  color:var(--ink-700);
}
.artikel-isi br + br{ content:''; display:block; margin:8px 0; }
</style>

<?php include __DIR__ . '/includes/footer.php'; ?>