<?php
/**
 * Detail Mobil
 * Lokasi: detail_mobil.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . BASE_URL . 'katalog.php');
    exit;
}

$stmt = $pdo->prepare("
    SELECT m.*, mk.nama_merek, mk.slug AS merek_slug
    FROM mobil m
    JOIN merek mk ON mk.id = m.merek_id
    WHERE m.id = :id
");
$stmt->execute([':id' => $id]);
$mobil = $stmt->fetch();

if (!$mobil) {
    set_flash('danger', 'Mobil tidak ditemukan.');
    header('Location: ' . BASE_URL . 'katalog.php');
    exit;
}

// Update views
$pdo->prepare("UPDATE mobil SET views = views + 1 WHERE id = :id")->execute([':id' => $id]);

// Galeri
$stmtG = $pdo->prepare("SELECT * FROM mobil_gallery WHERE mobil_id = :id ORDER BY urutan ASC");
$stmtG->execute([':id' => $id]);
$gallery = $stmtG->fetchAll();

// Inspeksi
$stmtI = $pdo->prepare("SELECT * FROM inspeksi WHERE mobil_id = :id ORDER BY id DESC LIMIT 1");
$stmtI->execute([':id' => $id]);
$inspeksi = $stmtI->fetch();

// Mobil terkait
$stmtR = $pdo->prepare("
    SELECT m.*, mk.nama_merek
    FROM mobil m
    JOIN merek mk ON mk.id = m.merek_id
    WHERE m.id != :id AND m.status = 'Ready'
    ORDER BY m.unggulan DESC, RAND()
    LIMIT 4
");
$stmtR->execute([':id' => $id]);
$mobilTerkait = $stmtR->fetchAll();

$pageTitle = $mobil['nama_mobil'] . ' ' . $mobil['tahun'];
$pageDesc  = potong($mobil['deskripsi'], 160);

$pesanWa = 'Halo, saya tertarik dengan mobil ' . $mobil['nama_mobil'] . ' '
         . $mobil['tahun'] . ' dengan harga ' . rupiah($mobil['harga'])
         . '. Saya ingin mendapatkan informasi lebih lanjut.';

include __DIR__ . '/includes/header.php';
?>

<!-- BREADCRUMB -->
<div class="breadcrumb-bar">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-2">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Home</a></li>
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>katalog.php">Katalog</a></li>
        <li class="breadcrumb-item active"><?= e($mobil['nama_mobil']) ?></li>
      </ol>
    </nav>
    <h1><?= e($mobil['nama_mobil']) ?> <?= (int)$mobil['tahun'] ?></h1>
    <div class="d-flex flex-wrap gap-3 mt-2" style="color:rgba(255,255,255,.7);font-size:13px">
      <span><i class="fa-solid fa-location-dot me-1"></i><?= e($mobil['lokasi'] ?: '-') ?></span>
      <span><i class="fa-regular fa-eye me-1"></i><?= (int)$mobil['views'] ?>x dilihat</span>
      <span><i class="fa-regular fa-calendar me-1"></i>Diposting <?= tanggal_id($mobil['created_at']) ?></span>
    </div>
  </div>
</div>

<section class="section">
  <div class="container">
    <div class="row g-4">

      <!-- KIRI: FOTO + INFO -->
      <div class="col-lg-8">

        <!-- GALERI -->
        <div class="detail-galeri">
          <div class="galeri-utama">
            <img id="gambarUtama" src="<?= img_mobil($mobil['foto_utama']) ?>"
                 alt="<?= e($mobil['nama_mobil']) ?>">
            <span class="<?= badge_mobil($mobil['status']) ?> badge-utama"><?= e($mobil['status']) ?></span>
          </div>

          <?php if ($gallery): ?>
            <div class="galeri-thumb">
              <?php foreach ($gallery as $i => $g): ?>
                <div class="thumb-item <?= $i === 0 ? 'active' : '' ?>"
                     onclick="gantiGambar(this, '<?= img_mobil($g['foto']) ?>')">
                  <img src="<?= img_mobil($g['foto']) ?>" alt="Foto <?= $i + 1 ?>" loading="lazy">
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>

        <!-- INFO UTAMA -->
        <div class="detail-box">
          <div class="detail-head-row">
            <div class="detail-head-left">
              <span class="eyebrow mb-2"><i class="fa-solid fa-tag"></i> <?= e($mobil['nama_merek']) ?></span>
              <h2 class="detail-judul"><?= e($mobil['nama_mobil']) ?></h2>
              <p class="detail-sub"><?= e($mobil['model']) ?> · <?= (int)$mobil['tahun'] ?></p>
            </div>
            <div class="detail-head-right">
              <div class="harga-label">Harga</div>
              <div class="harga-besar"><?= rupiah($mobil['harga']) ?></div>
            </div>
          </div>

          <!-- SPEC MINI -->
          <div class="spec-mini">
            <div class="spec-item">
              <i class="fa-regular fa-calendar"></i>
              <div>
                <small>Tahun</small>
                <strong><?= (int)$mobil['tahun'] ?></strong>
              </div>
            </div>
            <div class="spec-item">
              <i class="fa-solid fa-gauge-high"></i>
              <div>
                <small>Kilometer</small>
                <strong><?= km($mobil['kilometer']) ?></strong>
              </div>
            </div>
            <div class="spec-item">
              <i class="fa-solid fa-gear"></i>
              <div>
                <small>Transmisi</small>
                <strong><?= e($mobil['transmisi']) ?></strong>
              </div>
            </div>
            <div class="spec-item">
              <i class="fa-solid fa-gas-pump"></i>
              <div>
                <small>Bahan Bakar</small>
                <strong><?= e($mobil['bahan_bakar']) ?></strong>
              </div>
            </div>
          </div>
        </div>

        <!-- DESKRIPSI -->
        <?php if ($mobil['deskripsi']): ?>
        <div class="detail-box">
          <h5 class="detail-heading"><i class="fa-regular fa-file-lines"></i> Deskripsi Kendaraan</h5>
          <div class="deskripsi-mobil">
            <?= nl2br(e($mobil['deskripsi'])) ?>
          </div>
        </div>
        <?php endif; ?>

        <!-- SPESIFIKASI -->
        <div class="detail-box">
          <h5 class="detail-heading"><i class="fa-solid fa-list-check"></i> Spesifikasi Lengkap</h5>
          <div class="row g-3">
            <?php
            $spesifikasi = [
              ['Tahun', (int)$mobil['tahun']],
              ['Kilometer', km($mobil['kilometer'])],
              ['Transmisi', $mobil['transmisi']],
              ['Bahan Bakar', $mobil['bahan_bakar']],
              ['Kapasitas Mesin', $mobil['kapasitas_mesin'] ?: '-'],
              ['Warna', $mobil['warna'] ?: '-'],
              ['Nomor Polisi', $mobil['nomor_polisi'] ?: '-'],
              ['Lokasi', $mobil['lokasi'] ?: '-'],
              ['Merek', $mobil['nama_merek']],
              ['Model', $mobil['model']],
            ];
            foreach ($spesifikasi as $s): ?>
              <div class="col-6 col-md-4">
                <div class="spec-card">
                  <small><?= e($s[0]) ?></small>
                  <strong><?= e($s[1]) ?></strong>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- INSPEKSI -->
        <?php if ($inspeksi): ?>
        <div class="detail-box">
          <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
            <h5 class="detail-heading mb-0"><i class="fa-solid fa-shield-halved"></i> Hasil Inspeksi</h5>
            <small class="text-muted">
              <?= tanggal_id($inspeksi['tanggal_inspeksi']) ?> · <?= e($inspeksi['pemeriksa']) ?>
            </small>
          </div>

          <div class="row g-3 mb-3">
            <?php
            $kondisiList = [
              ['Eksterior', $inspeksi['eksterior'], 'fa-car-side'],
              ['Interior', $inspeksi['interior'], 'fa-couch'],
              ['Mesin', $inspeksi['mesin'], 'fa-gears'],
              ['Kelistrikan', $inspeksi['kelistrikan'], 'fa-bolt'],
              ['Ban', $inspeksi['ban'], 'fa-circle-dot'],
              ['Dokumen', $inspeksi['dokumen'], 'fa-file-shield'],
            ];
            foreach ($kondisiList as $k): ?>
              <div class="col-6 col-md-4 col-lg-2">
                <div class="inspeksi-card">
                  <i class="fa-solid <?= $k[2] ?>"></i>
                  <div class="inspeksi-label"><?= e($k[0]) ?></div>
                  <div class="mt-2"><span class="<?= badge_kondisi($k[1]) ?>"><?= e($k[1]) ?></span></div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>

          <?php if ($inspeksi['catatan']): ?>
            <div class="catatan-inspeksi">
              <i class="fa-solid fa-circle-info"></i>
              <div>
                <strong>Catatan Pemeriksa:</strong>
                <p class="mb-0"><?= e($inspeksi['catatan']) ?></p>
              </div>
            </div>
          <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- SIMULASI KREDIT -->
        <div class="detail-box" id="simulasi">
          <h5 class="detail-heading"><i class="fa-solid fa-calculator"></i> Simulasi Kredit</h5>
          <p class="text-muted" style="font-size:13.5px">
            Hitung estimasi cicilan bulanan sesuai budget Anda. Ubah DP atau tenor, hasil terupdate otomatis.
          </p>

          <div class="row g-4 mt-2">
            <div class="col-lg-7">
              <div class="mb-3">
                <label class="form-label">Harga Mobil</label>
                <input type="text" class="form-control" id="simHarga"
                       value="<?= number_format($mobil['harga'], 0, ',', '.') ?>" readonly>
                <input type="hidden" id="simHargaRaw" value="<?= (int)$mobil['harga'] ?>">
              </div>
              <div class="mb-3">
                <label class="form-label">Uang Muka (DP)</label>
                <div class="input-group">
                  <span class="input-group-text">Rp</span>
                  <input type="number" class="form-control" id="simDp"
                         value="<?= (int)round($mobil['harga']*0.2) ?>" min="0" step="1000000">
                </div>
                <input type="range" class="form-range mt-2" id="simDpRange"
                       min="0" max="<?= (int)$mobil['harga'] ?>"
                       value="<?= (int)round($mobil['harga']*0.2) ?>" step="1000000">
                <small class="form-text">Geser slider atau ubah angka. Minimal DP 20% direkomendasikan.</small>
              </div>
              <div class="row g-3">
                <div class="col-sm-6">
                  <label class="form-label">Tenor</label>
                  <select class="form-select" id="simTenor">
                    <option value="12">1 Tahun (12 bulan)</option>
                    <option value="24">2 Tahun (24 bulan)</option>
                    <option value="36" selected>3 Tahun (36 bulan)</option>
                    <option value="48">4 Tahun (48 bulan)</option>
                    <option value="60">5 Tahun (60 bulan)</option>
                  </select>
                </div>
                <div class="col-sm-6">
                  <label class="form-label">Bunga per Tahun (%)</label>
                  <input type="number" class="form-control" id="simBunga" value="8" min="0" max="30" step="0.5">
                </div>
              </div>
            </div>

            <div class="col-lg-5">
              <div class="hasil-simulasi">
                <div class="hasil-label">Estimasi Cicilan / Bulan</div>
                <div class="hasil-utama" id="hasilCicilan">Rp 0</div>
                <hr>
                <div class="hasil-row"><span>Harga Kendaraan</span><strong id="hasilHarga">Rp 0</strong></div>
                <div class="hasil-row"><span>Uang Muka (DP)</span><strong id="hasilDp">Rp 0</strong></div>
                <div class="hasil-row"><span>Jumlah Pembiayaan</span><strong id="hasilPokok">Rp 0</strong></div>
                <div class="hasil-row"><span>Tenor</span><strong id="hasilTenor">36 bulan</strong></div>
                <div class="hasil-row"><span>Bunga per Tahun</span><strong id="hasilBunga">8%</strong></div>
                <div class="hasil-row"><span>Total Bunga</span><strong id="hasilTotalBunga">Rp 0</strong></div>
                <div class="hasil-row total"><span>Total Pembayaran</span><strong id="hasilTotal">Rp 0</strong></div>
                <a href="<?= wa_link('Halo, saya ingin mengajukan kredit untuk ' . $mobil['nama_mobil'] . ' ' . $mobil['tahun']) ?>"
                   target="_blank" rel="noopener" class="btn btn-wa w-100 mt-3">
                  <i class="fa-brands fa-whatsapp me-2"></i>Ajukan Kredit
                </a>
                <p class="disclaimer mt-3 mb-0">
                  <i class="fa-solid fa-triangle-exclamation me-1"></i>
                  Hasil simulasi hanya perkiraan, bukan pengajuan kredit resmi.
                </p>
              </div>
            </div>
          </div>
        </div>

      </div>

      <!-- KANAN: STICKY CTA -->
      <div class="col-lg-4">
        <div class="sidebar-cta sticky-top" style="top:90px">
          <div class="cta-harga">
            <small>Harga Penawaran</small>
            <div class="cta-angka"><?= rupiah($mobil['harga']) ?></div>
            <div class="text-muted" style="font-size:13px">
              <i class="fa-solid fa-hand-holding-dollar me-1"></i>Nego sampai jadi
            </div>
          </div>

          <div class="d-grid gap-2 mt-3">
            <a href="<?= wa_link($pesanWa) ?>" target="_blank" rel="noopener" class="btn btn-wa btn-lg">
              <i class="fa-brands fa-whatsapp me-2"></i>Chat via WhatsApp
            </a>
            <a href="<?= BASE_URL ?>test_drive.php?mobil_id=<?= (int)$mobil['id'] ?>" class="btn btn-brand btn-lg">
              <i class="fa-solid fa-car-side me-2"></i>Booking Test Drive
            </a>
            <a href="#simulasi" class="btn btn-outline-navy btn-lg">
              <i class="fa-solid fa-calculator me-2"></i>Simulasi Kredit
            </a>
            <a href="tel:<?= e(setting('telepon')) ?>" class="btn btn-ghost">
              <i class="fa-solid fa-phone me-2"></i><?= e(setting('telepon')) ?>
            </a>
          </div>

          <div class="info-mini mt-4">
            <div class="d-flex gap-2 mb-3">
              <i class="fa-solid fa-shield-halved"></i>
              <div>
                <strong>Garansi Mesin 1 Tahun</strong>
                <p class="mb-0">Setiap unit dilindungi garansi mesin &amp; transmisi.</p>
              </div>
            </div>
            <div class="d-flex gap-2 mb-3">
              <i class="fa-solid fa-file-shield"></i>
              <div>
                <strong>Dokumen Lengkap</strong>
                <p class="mb-0">BPKB, STNK, faktur sudah diverifikasi.</p>
              </div>
            </div>
            <div class="d-flex gap-2">
              <i class="fa-solid fa-money-bill-transfer"></i>
              <div>
                <strong>Bisa Tukar Tambah</strong>
                <p class="mb-0">Tukar mobil lama, kami nilai transparan.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

    <!-- MOBIL TERKAIT -->
    <?php if ($mobilTerkait): ?>
      <div class="mt-5 pt-5" style="border-top:1px solid var(--line)">
        <div class="section-head text-center">
          <span class="eyebrow"><i class="fa-solid fa-car"></i> Rekomendasi</span>
          <h3 class="section-title">Mobil Serupa Lainnya</h3>
          <p class="section-sub">Pilihan unit lain dengan kriteria serupa.</p>
        </div>
        <div class="row g-4">
          <?php foreach ($mobilTerkait as $m): ?>
            <div class="col-xl-3 col-lg-4 col-md-6 reveal">
              <?php include __DIR__ . '/includes/card_mobil.php'; ?>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endif; ?>

  </div>
</section>

<script>
function gantiGambar(el, src) {
  document.getElementById('gambarUtama').src = src;
  document.querySelectorAll('.thumb-item').forEach(function(t){ t.classList.remove('active'); });
  el.classList.add('active');
}

(function(){
  const harga   = document.getElementById('simHargaRaw');
  const dp      = document.getElementById('simDp');
  const dpRange = document.getElementById('simDpRange');
  const tenor   = document.getElementById('simTenor');
  const bunga   = document.getElementById('simBunga');
  if (!harga) return;

  const fmt = n => 'Rp ' + Math.round(n).toLocaleString('id-ID');

  function hitung() {
    const H = parseFloat(harga.value) || 0;
    const D = Math.min(parseFloat(dp.value) || 0, H);
    const T = parseInt(tenor.value) || 36;
    const B = parseFloat(bunga.value) || 0;
    const pokok = Math.max(H - D, 0);
    const bungaTotal = pokok * (B / 100) * (T / 12);
    const total = pokok + bungaTotal;
    const cicilan = T > 0 ? total / T : 0;

    document.getElementById('hasilHarga').textContent      = fmt(H);
    document.getElementById('hasilDp').textContent         = fmt(D);
    document.getElementById('hasilPokok').textContent      = fmt(pokok);
    document.getElementById('hasilTenor').textContent      = T + ' bulan';
    document.getElementById('hasilBunga').textContent      = B + '%';
    document.getElementById('hasilTotalBunga').textContent = fmt(bungaTotal);
    document.getElementById('hasilTotal').textContent      = fmt(total);
    document.getElementById('hasilCicilan').textContent    = fmt(cicilan);
  }

  dp.addEventListener('input', function(){ dpRange.value = dp.value; hitung(); });
  dpRange.addEventListener('input', function(){ dp.value = dpRange.value; hitung(); });
  tenor.addEventListener('change', hitung);
  bunga.addEventListener('input', hitung);
  hitung();
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>