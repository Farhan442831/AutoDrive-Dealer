<?php
/**
 * Registrasi Customer
 * Lokasi: register.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

if (!empty($_SESSION['user'])) {
    header('Location: ' . BASE_URL . 'index.php');
    exit;
}

$pageTitle = 'Daftar Akun';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama     = trim($_POST['nama'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $whatsapp = trim($_POST['whatsapp'] ?? '');
    $password = $_POST['password'] ?? '';
    $konfirm  = $_POST['konfirmasi'] ?? '';

    if ($nama === '')                     $errors[] = 'Nama lengkap wajib diisi.';
    if ($email === '')                    $errors[] = 'Email wajib diisi.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Format email tidak valid.';
    if ($whatsapp === '')                 $errors[] = 'Nomor WhatsApp wajib diisi.';
    if (strlen($password) < 6)            $errors[] = 'Password minimal 6 karakter.';
    if ($password !== $konfirm)           $errors[] = 'Konfirmasi password tidak cocok.';

    if (!$errors) {
        $cek = $pdo->prepare("SELECT id FROM users WHERE email = :email");
        $cek->execute([':email' => $email]);
        if ($cek->fetch()) {
            $errors[] = 'Email sudah terdaftar. Silakan login.';
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO users (nama, email, password, no_whatsapp, role, status)
                VALUES (:nama, :email, :password, :wa, 'customer', 'aktif')
            ");
            $stmt->execute([
                ':nama'     => $nama,
                ':email'    => $email,
                ':password' => password_hash($password, PASSWORD_DEFAULT),
                ':wa'       => $whatsapp,
            ]);

            // Simpan ke tabel customers juga
            $uid = (int)$pdo->lastInsertId();
            $pdo->prepare("INSERT INTO customers (user_id, nama, email, whatsapp) VALUES (:uid, :nama, :email, :wa)")
                ->execute([':uid' => $uid, ':nama' => $nama, ':email' => $email, ':wa' => $whatsapp]);

            set_flash('success', 'Registrasi berhasil! Silakan login.');
            header('Location: ' . BASE_URL . 'login.php');
            exit;
        }
    }
}

include __DIR__ . '/includes/header.php';
?>

<section class="section">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-5 col-md-8">
        <div class="detail-box">
          <div class="text-center mb-4">
            <div class="brand-mark mx-auto mb-3" style="width:56px;height:56px;font-size:22px">
              <i class="fa-solid fa-user-plus"></i>
            </div>
            <h3 class="mb-1">Buat Akun Baru</h3>
            <p class="text-muted mb-0" style="font-size:14px">
              Daftar untuk mengajukan test drive, jual mobil, dan tukar tambah.
            </p>
          </div>

          <?php if ($errors): ?>
            <div class="alert alert-danger">
              <ul class="mb-0 ps-3">
                <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
              </ul>
            </div>
          <?php endif; ?>

          <form method="post" novalidate>
            <div class="mb-3">
              <label class="form-label">Nama Lengkap</label>
              <input type="text" name="nama" class="form-control" required
                     value="<?= e($_POST['nama'] ?? '') ?>">
            </div>
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control" required
                     value="<?= e($_POST['email'] ?? '') ?>">
            </div>
            <div class="mb-3">
              <label class="form-label">Nomor WhatsApp</label>
              <input type="text" name="whatsapp" class="form-control" required
                     placeholder="08xxxxxxxxxx"
                     value="<?= e($_POST['whatsapp'] ?? '') ?>">
            </div>
            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" name="password" class="form-control" required minlength="6">
              <small class="form-text">Minimal 6 karakter.</small>
            </div>
            <div class="mb-3">
              <label class="form-label">Konfirmasi Password</label>
              <input type="password" name="konfirmasi" class="form-control" required minlength="6">
            </div>
            <button type="submit" class="btn btn-brand w-100">
              <i class="fa-solid fa-user-plus me-2"></i>Daftar Sekarang
            </button>
          </form>

          <p class="text-center mt-3 mb-0" style="font-size:14px">
            Sudah punya akun?
            <a href="<?= BASE_URL ?>login.php" class="fw-bold">Masuk di sini</a>
          </p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>