/* =====================================================================
   AutoPrime Motor — Script Utama
   Lokasi: assets/js/main.js
   ===================================================================== */
(function () {
  'use strict';

  /* Back to top */
  const backTop = document.getElementById('backTop');
  if (backTop) {
    window.addEventListener('scroll', function () {
      backTop.classList.toggle('show', window.scrollY > 400);
    });
    backTop.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* Navbar shadow saat scroll */
  const nav = document.getElementById('mainNavbar');
  if (nav) {
    window.addEventListener('scroll', function () {
      nav.style.boxShadow = window.scrollY > 10
        ? '0 6px 22px rgba(10,23,41,.28)'
        : '0 2px 14px rgba(10,23,41,.18)';
    });
  }

  /* Auto close alert */
  document.querySelectorAll('.alert-dismissible').forEach(function (el) {
    setTimeout(function () {
      if (window.bootstrap && bootstrap.Alert) {
        bootstrap.Alert.getOrCreateInstance(el).close();
      }
    }, 6000);
  });

  /* Animasi muncul halus */
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });

    document.querySelectorAll('.reveal').forEach(function (el) {
      el.style.opacity = '0';
      el.style.transform = 'translateY(16px)';
      el.style.transition = 'opacity .55s ease, transform .55s ease';
      io.observe(el);
    });
  }

  /* Filter harga min/max */
  const hMin = document.getElementById('harga_min');
  const hMax = document.getElementById('harga_max');
  if (hMin && hMax) {
    hMin.addEventListener('change', function () {
      if (hMax.value && Number(hMax.value) < Number(hMin.value)) hMax.value = hMin.value;
    });
    hMax.addEventListener('change', function () {
      if (hMin.value && Number(hMax.value) < Number(hMin.value)) hMin.value = hMax.value;
    });
  }
})();