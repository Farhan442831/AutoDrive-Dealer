/* =====================================================================
   POLISH JS — Micro-interactions & Animations
   Lokasi: assets/js/polish.js
   Load SETELAH main.js
   ===================================================================== */
(function () {
  'use strict';

  /* ================================================================
     1. Ripple effect on buttons
     ================================================================ */
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('.btn-brand, .btn-navy, .btn-wa');
    if (!btn || btn.classList.contains('disabled')) return;

    const rect = btn.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const ripple = document.createElement('span');
    ripple.style.cssText = `
      position:absolute;
      width:${size}px;height:${size}px;
      left:${e.clientX - rect.left - size / 2}px;
      top:${e.clientY - rect.top - size / 2}px;
      background:rgba(255,255,255,.35);
      border-radius:50%;
      transform:scale(0);
      pointer-events:none;
      animation:ripple-anim .55s ease-out;
      z-index:0;
    `;
    btn.appendChild(ripple);
    setTimeout(() => ripple.remove(), 600);
  });

  if (!document.getElementById('ripple-style')) {
    const style = document.createElement('style');
    style.id = 'ripple-style';
    style.textContent = `
      @keyframes ripple-anim{
        to{ transform:scale(2.4); opacity:0; }
      }
    `;
    document.head.appendChild(style);
  }

  /* ================================================================
     2. Auto-hide navbar on scroll down, show on scroll up
     ================================================================ */
  const navbar = document.getElementById('mainNavbar');
  if (navbar && window.innerWidth > 991) {
    let lastY = window.scrollY;
    window.addEventListener('scroll', function () {
      const y = window.scrollY;
      if (y > 200 && y > lastY) {
        navbar.style.transform = 'translateY(-100%)';
      } else {
        navbar.style.transform = 'translateY(0)';
      }
      navbar.style.transition = 'transform .3s ease';
      lastY = y;
    });
  }

  /* ================================================================
     3. Counter animation for hero stats & stat cards
     ================================================================ */
  function animateCounter(el) {
    const target = parseInt(el.textContent.replace(/\D/g, ''), 10);
    if (isNaN(target) || target === 0) return;
    const dur = 1000;
    const start = performance.now();
    const suffix = el.textContent.replace(/[0-9.,]/g, '');

    function tick(now) {
      const progress = Math.min((now - start) / dur, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.floor(target * eased).toLocaleString('id-ID') + suffix;
      if (progress < 1) requestAnimationFrame(tick);
      else el.textContent = target.toLocaleString('id-ID') + suffix;
    }
    requestAnimationFrame(tick);
  }

  if ('IntersectionObserver' in window) {
    const counterObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          counterObs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });

    document.querySelectorAll('.hero-stat strong, .stat-value').forEach(el => {
      if (/^[0-9.,]+[+]?$/.test(el.textContent.trim())) counterObs.observe(el);
    });
  }

  /* ================================================================
     4. Table row click highlight (admin)
     ================================================================ */
  document.querySelectorAll('.table-admin tbody tr').forEach(function (row) {
    row.addEventListener('mouseenter', function () {
      this.style.transform = 'translateX(2px)';
      this.style.transition = 'transform .18s ease';
    });
    row.addEventListener('mouseleave', function () {
      this.style.transform = 'translateX(0)';
    });
  });

  /* ================================================================
     5. Auto-dismiss alerts with fade + slide
     ================================================================ */
  document.querySelectorAll('.alert-dismissible').forEach(function (el) {
    el.style.transition = 'opacity .35s, transform .35s';
    setTimeout(function () {
      el.style.opacity = '0';
      el.style.transform = 'translateY(-10px)';
      setTimeout(() => el.remove(), 400);
    }, 6500);
  });

  /* ================================================================
     6. Smooth scroll for anchor links
     ================================================================ */
  document.querySelectorAll('a[href^="#"]').forEach(function (link) {
    link.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target && this.getAttribute('href') !== '#') {
        e.preventDefault();
        const top = target.getBoundingClientRect().top + window.scrollY - 90;
        window.scrollTo({ top, behavior: 'smooth' });
      }
    });
  });

  /* ================================================================
     7. Form input floating feedback
     ================================================================ */
  document.querySelectorAll('.form-control, .form-select').forEach(function (input) {
    input.addEventListener('focus', function () {
      this.parentElement.classList.add('is-focused');
    });
    input.addEventListener('blur', function () {
      this.parentElement.classList.remove('is-focused');
    });
  });

  /* ================================================================
     8. Image lazy load with fade-in
     ================================================================ */
  document.querySelectorAll('img[loading="lazy"]').forEach(function (img) {
    img.classList.add('lazy-load');
    if (img.complete) {
      img.classList.add('loaded');
    } else {
      img.addEventListener('load', () => img.classList.add('loaded'));
      img.addEventListener('error', () => img.classList.add('loaded'));
    }
  });

  /* ================================================================
     9. Card tilt effect (subtle) — only desktop
     ================================================================ */
  if (window.innerWidth > 991 && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.querySelectorAll('.car-card').forEach(function (card) {
      card.addEventListener('mousemove', function (e) {
        const rect = this.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width - 0.5;
        const y = (e.clientY - rect.top) / rect.height - 0.5;
        this.style.transform = `translateY(-4px) rotateX(${-y * 3}deg) rotateY(${x * 3}deg)`;
        this.style.transformStyle = 'preserve-3d';
        this.style.perspective = '800px';
      });
      card.addEventListener('mouseleave', function () {
        this.style.transform = '';
      });
    });
  }

  /* ================================================================
     10. Progress bar on page load (thin top bar)
     ================================================================ */
  const progress = document.createElement('div');
  progress.style.cssText = `
    position:fixed;top:0;left:0;height:3px;width:0%;
    background:linear-gradient(90deg,#f97316,#fb923c);
    z-index:99999;transition:width .25s ease, opacity .4s;
    box-shadow:0 0 8px rgba(249,115,22,.5);
  `;
  document.body.appendChild(progress);

  let p = 0;
  const interval = setInterval(() => {
    p += Math.random() * 15;
    if (p > 90) p = 90;
    progress.style.width = p + '%';
  }, 180);

  window.addEventListener('load', function () {
    clearInterval(interval);
    progress.style.width = '100%';
    setTimeout(() => {
      progress.style.opacity = '0';
      setTimeout(() => progress.remove(), 500);
    }, 250);
  });

})();