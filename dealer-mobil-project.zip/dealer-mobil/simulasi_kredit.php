<?php
/**
 * Simulasi Kredit (standalone)
 * Lokasi: simulasi_kredit.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Simulasi Kredit';
$pageDesc  = 'Hitung estimasi cicilan mobil bekas sesuai budget Anda.';

// Daftar mobil untuk dipilih
$mobilList = $pdo->query("
    SELECT m.id, m.nama_mobil, m.tahun, m.harga, mk.nama_merek
    FROM mobil m JOIN merek mk ON mk.id = m.merek_id
    WHERE m.status IN ('Ready','Booked')
    ORDER BY mk.nama_merek, m.nama_mobil
")->fetchAll();

$mobil_id = (int)($_GET['mobil_id'] ?? 0);
$mobilTerpilih = null;
foreach ($mobilList as $mm) {
    if ((int)$mm['id'] === $mobil_id) { $mobilTerpilih = $mm; break; }
}

include __DIR__ . '/includes/header.php';
?>

<div class="breadcrumb-bar">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-2">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Simulasi Kredit</li>
      </ol>
    </nav>
    <h1>Simulasi Kredit Mobil</h1>
    <p class="mb-0" style="color:rgba(255,255,255,.7);font-size:14px">
      Hitung estimasi cicilan bulanan sebelum mengajukan kredit.
    </p>
  </div>
</div>

<section class="section">
  <div class="container">
    <div class="row g-4">

      <div class="col-lg-7">
        <div class="detail-box">
          <h5 class="detail-heading"><i class="fa-solid fa-calculator"></i> Kalkulator Kredit</h5>

          <div class="mb-3">
            <label class="form-label">Pilih Mobil</label>
            <select class="form-select" id="pilihMobil">
              <option value="">-- Pilih mobil --</option>
              <?php foreach ($mobilList as $mm): ?>
                <option value="<?= (int)$mm['id'] ?>"
                        data-harga="<?= (int)$mm['harga'] ?>"
                        <?= $mobilTerpilih && $mobilTerpilih['id'] == $mm['id'] ? 'selected' : '' ?>>
                  <?= e($mm['nama_merek']) ?> <?= e($mm['nama_mobil']) ?> (<?= (int)$mm['tahun'] ?>) &mdash; <?= rupiah($mm['harga']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label">Harga Mobil</label>
            <div class="input-group">
              <span class="input-group-text">Rp</span>
              <input type="number" class="form-control" id="kHarga"
                     value="<?= $mobilTerpilih ? (int)$mobilTerpilih['harga'] : 200000000 ?>" min="0" step="1000000">
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label">Uang Muka (DP)</label>
            <div class="input-group">
              <span class="input-group-text">Rp</span>
              <input type="number" class="form-control" id="kDp" value="50000000" min="0" step="1000000">
            </div>
            <input type="range" class="form-range mt-2" id="kDpRange" min="0" max="500000000" value="50000000" step="1000000">
            <small class="form-text">Minimum DP umumnya 20% dari harga mobil.</small>
          </div>

          <div class="row g-3">
            <div class="col-sm-6">
              <label class="form-label">Tenor</label>
              <select class="form-select" id="kTenor">
                <option value="12">1 Tahun (12 bulan)</option>
                <option value="24">2 Tahun (24 bulan)</option>
                <option value="36" selected>3 Tahun (36 bulan)</option>
                <option value="48">4 Tahun (48 bulan)</option>
                <option value="60">5 Tahun (60 bulan)</option>
              </select>
            </div>
            <div class="col-sm-6">
              <label class="form-label">Bunga per Tahun (%)</label>
              <input type="number" class="form-control" id="kBunga" value="8" min="0" max="30" step="0.5">
            </div>
          </div>

          <div class="alert alert-light border mt-4 mb-0" style="font-size:13px">
            <i class="fa-solid fa-circle-info text-orange me-2"></i>
            Perhitungan menggunakan <strong>metode bunga flat</strong>. Bunga efektif dapat berbeda tergantung leasing.
          </div>
        </div>
      </div>

      <div class="col-lg-5">
        <div class="hasil-simulasi">
          <div class="hasil-label">Estimasi Cicilan / Bulan</div>
          <div class="hasil-utama" id="kHasilCicilan">Rp 0</div>
          <hr>
          <div class="hasil-row"><span>Harga Kendaraan</span><strong id="kHasilHarga">Rp 0</strong></div>
          <div class="hasil-row"><span>Uang Muka (DP)</span><strong id="kHasilDp">Rp 0</strong></div>
          <div class="hasil-row"><span>Jumlah Pembiayaan</span><strong id="kHasilPokok">Rp 0</strong></div>
          <div class="hasil-row"><span>Tenor</span><strong id="kHasilTenor">36 bulan</strong></div>
          <div class="hasil-row"><span>Bunga per Tahun</span><strong id="kHasilBunga">8%</strong></div>
          <div class="hasil-row"><span>Total Bunga</span><strong id="kHasilTotalBunga">Rp 0</strong></div>
          <div class="hasil-row total"><span>Total Pembayaran</span><strong id="kHasilTotal">Rp 0</strong></div>

          <a href="<?= wa_link('Halo, saya ingin mengajukan kredit mobil. Mohon dihubungi untuk informasi lebih lanjut.') ?>"
             target="_blank" rel="noopener" class="btn btn-wa w-100 mt-3">
            <i class="fa-brands fa-whatsapp me-2"></i>Ajukan Kredit Sekarang
          </a>
          <p class="disclaimer mt-3 mb-0">
            <i class="fa-solid fa-triangle-exclamation me-1"></i>
            Hasil simulasi hanya perkiraan. Pengajuan kredit resmi tetap memerlukan verifikasi data.
          </p>
        </div>
      </div>

    </div>
  </div>
</section>

<script>
(function(){
  const pilih  = document.getElementById('pilihMobil');
  const harga  = document.getElementById('kHarga');
  const dp     = document.getElementById('kDp');
  const dpR    = document.getElementById('kDpRange');
  const tenor  = document.getElementById('kTenor');
  const bunga  = document.getElementById('kBunga');

  const fmt = n => 'Rp ' + Math.round(n).toLocaleString('id-ID');

  function hitung(){
    const H = parseFloat(harga.value) || 0;
    const D = Math.min(parseFloat(dp.value) || 0, H);
    const T = parseInt(tenor.value) || 36;
    const B = parseFloat(bunga.value) || 0;
    const pokok = Math.max(H - D, 0);
    const bungaTotal = pokok * (B/100) * (T/12);
    const total = pokok + bungaTotal;
    const cicilan = T ? total / T : 0;

    document.getElementById('kHasilHarga').textContent      = fmt(H);
    document.getElementById('kHasilDp').textContent         = fmt(D);
    document.getElementById('kHasilPokok').textContent      = fmt(pokok);
    document.getElementById('kHasilTenor').textContent      = T + ' bulan';
    document.getElementById('kHasilBunga').textContent      = B + '%';
    document.getElementById('kHasilTotalBunga').textContent = fmt(bungaTotal);
    document.getElementById('kHasilTotal').textContent      = fmt(total);
    document.getElementById('kHasilCicilan').textContent    = fmt(cicilan);
  }

  if (pilih) {
    pilih.addEventListener('change', function(){
      const opt = this.options[this.selectedIndex];
      const h = parseFloat(opt.dataset.harga || 0);
      if (h > 0) {
        harga.value = h;
        dp.value = Math.round(h * 0.2);
        dpR.max = h;
        dpR.value = dp.value;
        hitung();
      }
    });
    if (pilih.value) pilih.dispatchEvent(new Event('change'));
  }

  harga.addEventListener('input', function(){
    dpR.max = Math.max(parseFloat(harga.value)||0, 0);
    hitung();
  });
  dp.addEventListener('input', function(){ dpR.value = dp.value; hitung(); });
  dpR.addEventListener('input', function(){ dp.value = dpR.value; hitung(); });
  tenor.addEventListener('change', hitung);
  bunga.addEventListener('input', hitung);

  hitung();
})();
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>