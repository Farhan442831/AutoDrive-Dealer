<?php
/**
 * Artikel (Customer)
 * Lokasi: artikel.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Artikel & Tips';
$pageDesc  = 'Artikel dan tips seputar mobil bekas dari ' . setting('nama_dealer');

$kategori = trim($_GET['kategori'] ?? '');

$where = "WHERE status = 'publish'";
$params = [];
if ($kategori !== '') {
    $where .= " AND kategori = :kat";
    $params[':kat'] = $kategori;
}

$stmt = $pdo->prepare("SELECT * FROM artikel $where ORDER BY created_at DESC");
$stmt->execute($params);
$artikelList = $stmt->fetchAll();

// Ambil semua kategori
$kategoriList = $pdo->query("
    SELECT DISTINCT kategori FROM artikel WHERE status='publish' ORDER BY kategori
")->fetchAll(PDO::FETCH_COLUMN);

include __DIR__ . '/includes/header.php';
?>

<div class="breadcrumb-bar">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-2">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Home</a></li>
        <li class="breadcrumb-item active">Artikel</li>
      </ol>
    </nav>
    <h1>Artikel & Tips</h1>
    <p class="mb-0" style="color:rgba(255,255,255,.7);font-size:14px">
      Informasi dan panduan seputar dunia mobil bekas.
    </p>
  </div>
</div>

<section class="section">
  <div class="container">

    <?php if ($kategoriList): ?>
      <div class="d-flex flex-wrap justify-content-center gap-2 mb-4">
        <a href="<?= BASE_URL ?>artikel.php"
           class="btn btn-sm <?= $kategori === '' ? 'btn-brand' : 'btn-ghost' ?>">
          Semua
        </a>
        <?php foreach ($kategoriList as $k): ?>
          <a href="?kategori=<?= urlencode($k) ?>"
             class="btn btn-sm <?= $kategori === $k ? 'btn-brand' : 'btn-ghost' ?>">
            <?= e($k) ?>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if ($artikelList): ?>
      <div class="row g-4">
        <?php foreach ($artikelList as $a): ?>
          <div class="col-lg-4 col-md-6 reveal">
            <article class="artikel-card">
              <a href="<?= BASE_URL ?>detail_artikel.php?id=<?= (int)$a['id'] ?>" class="artikel-thumb d-block">
                <img src="<?= img_aset($a['thumbnail'], 'artikel') ?>" alt="<?= e($a['judul']) ?>" loading="lazy">
              </a>
              <div class="artikel-body">
                <span class="artikel-kategori"><?= e($a['kategori']) ?></span>
                <h6>
                  <a href="<?= BASE_URL ?>detail_artikel.php?id=<?= (int)$a['id'] ?>" class="text-dark">
                    <?= e($a['judul']) ?>
                  </a>
                </h6>
                <p><?= e(potong($a['ringkasan'], 130)) ?></p>
                <div class="artikel-meta">
                  <span><i class="fa-regular fa-calendar me-1"></i><?= tanggal_id($a['created_at']) ?></span>
                  <span><i class="fa-regular fa-eye me-1"></i><?= (int)$a['views'] ?>x</span>
                </div>
              </div>
            </article>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="empty-state">
        <i class="fa-regular fa-newspaper"></i>
        <h5>Belum Ada Artikel</h5>
        <p>Artikel akan segera hadir. Silakan cek kembali nanti.</p>
      </div>
    <?php endif; ?>

  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>