<?php
/**
 * Promo (Customer)
 * Lokasi: promo.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Promo & Penawaran';
$pageDesc  = 'Promo dan penawaran spesial dari ' . setting('nama_dealer');

$filter = $_GET['filter'] ?? 'aktif';

if ($filter === 'semua') {
    $promoList = $pdo->query("SELECT * FROM promo ORDER BY tanggal_mulai DESC")->fetchAll();
} else {
    $promoList = $pdo->query("
        SELECT * FROM promo
        WHERE status = 'aktif' AND tanggal_selesai >= CURDATE()
        ORDER BY tanggal_mulai DESC
    ")->fetchAll();
}

include __DIR__ . '/includes/header.php';
?>

<div class="breadcrumb-bar">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-2">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Home</a></li>
        <li class="breadcrumb-item active">Promo</li>
      </ol>
    </nav>
    <h1>Promo & Penawaran Spesial</h1>
    <p class="mb-0" style="color:rgba(255,255,255,.7);font-size:14px">
      Manfaatkan penawaran terbaik sebelum periodenya berakhir.
    </p>
  </div>
</div>

<section class="section">
  <div class="container">

    <div class="d-flex justify-content-center mb-4">
      <div class="btn-group" role="group">
        <a href="?filter=aktif" class="btn <?= $filter !== 'semua' ? 'btn-brand' : 'btn-ghost' ?>">
          <i class="fa-solid fa-fire me-1"></i>Sedang Berjalan
        </a>
        <a href="?filter=semua" class="btn <?= $filter === 'semua' ? 'btn-brand' : 'btn-ghost' ?>">
          <i class="fa-solid fa-list me-1"></i>Semua Promo
        </a>
      </div>
    </div>

    <?php if ($promoList): ?>
      <div class="row g-4">
        <?php foreach ($promoList as $p):
          $sedangBerjalan = $p['status'] === 'aktif' && strtotime($p['tanggal_selesai']) >= strtotime('today');
          $selesai = strtotime($p['tanggal_selesai']) < strtotime('today');
        ?>
          <div class="col-lg-4 col-md-6 reveal">
            <div class="promo-card">
              <div class="promo-thumb" style="position:relative">
                <img src="<?= img_aset($p['gambar'], 'promo') ?>" alt="<?= e($p['judul']) ?>" loading="lazy">
                <?php if ($sedangBerjalan): ?>
                  <span class="badge bg-success" style="position:absolute;top:12px;left:12px;font-size:11.5px;padding:.5em .9em">
                    <i class="fa-solid fa-bolt me-1"></i>Berlangsung
                  </span>
                <?php elseif ($selesai): ?>
                  <span class="badge bg-secondary" style="position:absolute;top:12px;left:12px;font-size:11.5px;padding:.5em .9em">
                    Berakhir
                  </span>
                <?php endif; ?>
              </div>
              <div class="promo-body">
                <span class="promo-periode">
                  <i class="fa-regular fa-calendar"></i>
                  <?= tanggal_id($p['tanggal_mulai']) ?> &ndash; <?= tanggal_id($p['tanggal_selesai']) ?>
                </span>
                <h6><?= e($p['judul']) ?></h6>
                <p><?= e(potong($p['deskripsi'], 130)) ?></p>

                <div class="d-flex gap-2 mt-auto">
                  <button type="button" class="btn btn-ghost flex-grow-1 btn-detail-promo"
                          data-judul="<?= e($p['judul']) ?>"
                          data-gambar="<?= img_aset($p['gambar'], 'promo') ?>"
                          data-deskripsi="<?= e($p['deskripsi']) ?>"
                          data-syarat="<?= e($p['syarat_ketentuan']) ?>"
                          data-mulai="<?= e(tanggal_id($p['tanggal_mulai'])) ?>"
                          data-selesai="<?= e(tanggal_id($p['tanggal_selesai'])) ?>">
                    <i class="fa-solid fa-circle-info me-1"></i>Detail
                  </button>
                  <a href="<?= wa_link('Halo, saya ingin menanyakan promo "' . $p['judul'] . '"') ?>"
                     target="_blank" rel="noopener" class="btn btn-wa">
                    <i class="fa-brands fa-whatsapp"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="empty-state">
        <i class="fa-solid fa-tags"></i>
        <h5>Belum Ada Promo</h5>
        <p>Saat ini belum ada promo yang tersedia. Silakan cek kembali nanti.</p>
        <a href="<?= BASE_URL ?>katalog.php" class="btn btn-brand">
          <i class="fa-solid fa-car me-2"></i>Lihat Katalog
        </a>
      </div>
    <?php endif; ?>

  </div>
</section>

<!-- CTA -->
<section class="section-sm">
  <div class="container">
    <div class="p-4 p-lg-5 rounded-lg" style="background:linear-gradient(120deg,#0f2440,#1b3a66)">
      <div class="row align-items-center g-4">
        <div class="col-lg-8 text-white">
          <h3 class="text-white mb-2">Punya Pertanyaan Seputar Promo?</h3>
          <p class="mb-0" style="color:rgba(255,255,255,.75)">
            Tim kami siap membantu Anda memahami syarat dan ketentuan setiap promo.
          </p>
        </div>
        <div class="col-lg-4 text-lg-end">
          <a href="<?= wa_link('Halo, saya ingin menanyakan tentang promo yang sedang berjalan') ?>"
             target="_blank" rel="noopener" class="btn btn-wa btn-lg w-100">
            <i class="fa-brands fa-whatsapp me-2"></i>Chat Sekarang
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- MODAL DETAIL PROMO -->
<div class="modal fade" id="modalPromo" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="mJudul"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <img id="mGambar" src="" alt="" class="img-fluid rounded mb-3" style="width:100%;max-height:280px;object-fit:cover">
        <div class="d-flex flex-wrap gap-3 mb-3 pb-3" style="border-bottom:1px solid var(--line)">
          <span class="text-muted" style="font-size:13px">
            <i class="fa-regular fa-calendar me-1"></i>
            <strong id="mMulai"></strong> &ndash; <strong id="mSelesai"></strong>
          </span>
        </div>
        <h6 class="mb-2">Deskripsi</h6>
        <p id="mDeskripsi" style="font-size:14px;line-height:1.75"></p>
        <h6 class="mb-2 mt-4">Syarat & Ketentuan</h6>
        <div id="mSyarat" style="background:var(--bg-soft);padding:16px;border-radius:10px;font-size:13.5px;line-height:1.7"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-bs-dismiss="modal">Tutup</button>
        <a href="<?= wa_link('Halo, saya ingin menanyakan promo ini') ?>" target="_blank" rel="noopener"
           class="btn btn-wa" id="mWa">
          <i class="fa-brands fa-whatsapp me-2"></i>Tanya via WhatsApp
        </a>
      </div>
    </div>
  </div>
</div>

<script>
document.querySelectorAll('.btn-detail-promo').forEach(function(btn){
  btn.addEventListener('click', function(){
    const d = this.dataset;
    document.getElementById('mJudul').textContent = d.judul;
    document.getElementById('mGambar').src = d.gambar;
    document.getElementById('mMulai').textContent = d.mulai;
    document.getElementById('mSelesai').textContent = d.selesai;
    document.getElementById('mDeskripsi').textContent = d.deskripsi;
    document.getElementById('mSyarat').innerHTML = (d.syarat || 'Syarat dan ketentuan berlaku.').replace(/\n/g, '<br>');
    document.getElementById('mWa').href = '<?= wa_link('Halo, saya ingin menanyakan promo berikut: ') ?>' + encodeURIComponent(d.judul);
    new bootstrap.Modal(document.getElementById('modalPromo')).show();
  });
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>