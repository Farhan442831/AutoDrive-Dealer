<?php
/**
 * Akun Customer — Profil & Riwayat Pengajuan
 * Lokasi: akun.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

wajib_login();

$user = user_login();
$pageTitle = 'Akun Saya';

// Ambil info lengkap user
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute([':id' => $user['id']]);
$userData = $stmt->fetch();

// Update profil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profil'])) {
    $nama     = trim($_POST['nama'] ?? '');
    $whatsapp = trim($_POST['no_whatsapp'] ?? '');
    $alamat   = trim($_POST['alamat'] ?? '');
    $password = $_POST['password'] ?? '';
    $konfirm  = $_POST['konfirmasi'] ?? '';

    $errors = [];
    if ($nama === '') $errors[] = 'Nama wajib diisi.';
    if ($password !== '' && strlen($password) < 6) $errors[] = 'Password minimal 6 karakter.';
    if ($password !== '' && $password !== $konfirm) $errors[] = 'Konfirmasi password tidak cocok.';

    if (!$errors) {
        if ($password !== '') {
            $upd = $pdo->prepare("UPDATE users SET nama=:n, no_whatsapp=:w, alamat=:a, password=:p WHERE id=:id");
            $upd->execute([
                ':n' => $nama, ':w' => $whatsapp, ':a' => $alamat,
                ':p' => password_hash($password, PASSWORD_DEFAULT), ':id' => $user['id'],
            ]);
        } else {
            $upd = $pdo->prepare("UPDATE users SET nama=:n, no_whatsapp=:w, alamat=:a WHERE id=:id");
            $upd->execute([':n' => $nama, ':w' => $whatsapp, ':a' => $alamat, ':id' => $user['id']]);
        }
        $_SESSION['user']['nama'] = $nama;
        set_flash('success', 'Profil berhasil diperbarui.');
        header('Location: ' . BASE_URL . 'akun.php');
        exit;
    }
    set_flash('danger', implode(' ', $errors));
}

// Riwayat pengajuan
$stmtTd = $pdo->prepare("
    SELECT td.*, m.nama_mobil, mk.nama_merek
    FROM test_drive td
    LEFT JOIN mobil m ON m.id = td.mobil_id
    LEFT JOIN merek mk ON mk.id = m.merek_id
    WHERE td.user_id = :uid
    ORDER BY td.created_at DESC
");
$stmtTd->execute([':uid' => $user['id']]);
$riwayatTd = $stmtTd->fetchAll();

$stmtJm = $pdo->prepare("SELECT * FROM jual_mobil WHERE user_id = :uid ORDER BY created_at DESC");
$stmtJm->execute([':uid' => $user['id']]);
$riwayatJm = $stmtJm->fetchAll();

$stmtTt = $pdo->prepare("
    SELECT tt.*, m.nama_mobil AS target_mobil, mk.nama_merek AS target_merek
    FROM tukar_tambah tt
    LEFT JOIN mobil m ON m.id = tt.mobil_id
    LEFT JOIN merek mk ON mk.id = m.merek_id
    WHERE tt.user_id = :uid
    ORDER BY tt.created_at DESC
");
$stmtTt->execute([':uid' => $user['id']]);
$riwayatTt = $stmtTt->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<div class="breadcrumb-bar">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-2">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Home</a></li>
        <li class="breadcrumb-item active">Akun Saya</li>
      </ol>
    </nav>
    <h1>Akun Saya</h1>
    <p class="mb-0" style="color:rgba(255,255,255,.7);font-size:14px">
      Kelola profil dan lihat riwayat pengajuan Anda.
    </p>
  </div>
</div>

<section class="section">
  <div class="container">
    <div class="row g-4">

      <!-- SIDEBAR -->
      <div class="col-lg-3">
        <div class="detail-box">
          <div class="text-center mb-3 pb-3" style="border-bottom:1px solid var(--line)">
            <div class="testi-avatar mx-auto mb-3" style="width:64px;height:64px;font-size:22px">
              <?= e(inisial($userData['nama'])) ?>
            </div>
            <strong style="font-size:15px"><?= e($userData['nama']) ?></strong><br>
            <small class="text-muted"><?= e($userData['email']) ?></small>
          </div>

          <div class="nav flex-column nav-pills">
            <button class="nav-link active text-start" data-bs-toggle="pill" data-bs-target="#tabProfil">
              <i class="fa-regular fa-user me-2"></i>Profil
            </button>
            <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tabTestDrive">
              <i class="fa-solid fa-car-side me-2"></i>Test Drive
              <?php if (count($riwayatTd)): ?><span class="badge bg-secondary ms-2"><?= count($riwayatTd) ?></span><?php endif; ?>
            </button>
            <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tabJual">
              <i class="fa-solid fa-hand-holding-dollar me-2"></i>Jual Mobil
              <?php if (count($riwayatJm)): ?><span class="badge bg-secondary ms-2"><?= count($riwayatJm) ?></span><?php endif; ?>
            </button>
            <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tabTukar">
              <i class="fa-solid fa-right-left me-2"></i>Tukar Tambah
              <?php if (count($riwayatTt)): ?><span class="badge bg-secondary ms-2"><?= count($riwayatTt) ?></span><?php endif; ?>
            </button>
            <hr class="my-2">
            <a class="nav-link text-start text-danger" href="<?= BASE_URL ?>logout.php">
              <i class="fa-solid fa-arrow-right-from-bracket me-2"></i>Logout
            </a>
          </div>
        </div>
      </div>

      <!-- CONTENT -->
      <div class="col-lg-9">
        <div class="tab-content">

          <!-- PROFIL -->
          <div class="tab-pane fade show active" id="tabProfil">
            <div class="detail-box">
              <h5 class="detail-heading"><i class="fa-regular fa-user"></i> Profil Saya</h5>

              <form method="post">
                <input type="hidden" name="update_profil" value="1">
                <div class="row g-3">
                  <div class="col-md-6">
                    <label class="form-label">Nama Lengkap</label>
                    <input type="text" name="nama" class="form-control" required
                           value="<?= e($userData['nama']) ?>">
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" value="<?= e($userData['email']) ?>" readonly>
                    <small class="form-text">Email tidak dapat diubah.</small>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">Nomor WhatsApp</label>
                    <input type="text" name="no_whatsapp" class="form-control"
                           value="<?= e($userData['no_whatsapp']) ?>">
                  </div>
                  <div class="col-12">
                    <label class="form-label">Alamat</label>
                    <textarea name="alamat" class="form-control" rows="2"><?= e($userData['alamat']) ?></textarea>
                  </div>
                </div>

                <hr class="my-4">
                <h6 class="mb-3" style="font-size:14px">Ubah Password <small class="text-muted">(opsional)</small></h6>

                <div class="row g-3">
                  <div class="col-md-6">
                    <label class="form-label">Password Baru</label>
                    <input type="password" name="password" class="form-control" minlength="6">
                    <small class="form-text">Biarkan kosong jika tidak ingin mengubah.</small>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">Konfirmasi Password</label>
                    <input type="password" name="konfirmasi" class="form-control" minlength="6">
                  </div>
                </div>

                <button type="submit" class="btn btn-brand mt-4">
                  <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Perubahan
                </button>
              </form>
            </div>
          </div>

          <!-- TEST DRIVE -->
          <div class="tab-pane fade" id="tabTestDrive">
            <div class="detail-box">
              <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                <h5 class="detail-heading mb-0"><i class="fa-solid fa-car-side"></i> Riwayat Test Drive</h5>
                <a href="<?= BASE_URL ?>test_drive.php" class="btn btn-brand btn-sm">
                  <i class="fa-solid fa-plus me-1"></i>Ajukan Baru
                </a>
              </div>

              <?php if ($riwayatTd): ?>
                <?php foreach ($riwayatTd as $td): ?>
                  <div class="riwayat-card">
                    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">
                      <div>
                        <strong style="font-size:14.5px">
                          <?= e($td['nama_merek']) ?> <?= e($td['nama_mobil']) ?>
                        </strong><br>
                        <small class="text-muted">
                          <i class="fa-regular fa-calendar me-1"></i><?= tanggal_id($td['tanggal']) ?>
                          &middot; <?= substr($td['jam'], 0, 5) ?> WIB
                        </small>
                      </div>
                      <span class="<?= badge_pengajuan($td['status']) ?>"><?= e($td['status']) ?></span>
                    </div>
                    <?php if ($td['catatan']): ?>
                      <p class="mb-0 text-muted" style="font-size:13px">
                        <i class="fa-regular fa-note-sticky me-1"></i><?= e($td['catatan']) ?>
                      </p>
                    <?php endif; ?>
                  </div>
                <?php endforeach; ?>
              <?php else: ?>
                <div class="empty-state py-4">
                  <i class="fa-solid fa-car-side"></i>
                  <h6 class="mt-2">Belum Ada Pengajuan</h6>
                  <p class="mb-3" style="font-size:13.5px">Anda belum pernah mengajukan test drive.</p>
                  <a href="<?= BASE_URL ?>katalog.php" class="btn btn-brand btn-sm">Lihat Katalog</a>
                </div>
              <?php endif; ?>
            </div>
          </div>

          <!-- JUAL MOBIL -->
          <div class="tab-pane fade" id="tabJual">
            <div class="detail-box">
              <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                <h5 class="detail-heading mb-0"><i class="fa-solid fa-hand-holding-dollar"></i> Riwayat Jual Mobil</h5>
                <a href="<?= BASE_URL ?>jual_mobil.php" class="btn btn-brand btn-sm">
                  <i class="fa-solid fa-plus me-1"></i>Ajukan Baru
                </a>
              </div>

              <?php if ($riwayatJm): ?>
                <?php foreach ($riwayatJm as $jm): ?>
                  <div class="riwayat-card">
                    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">
                      <div>
                        <strong style="font-size:14.5px">
                          <?= e($jm['merek']) ?> <?= e($jm['model']) ?> (<?= (int)$jm['tahun'] ?>)
                        </strong><br>
                        <small class="text-muted">
                          <i class="fa-solid fa-gauge-high me-1"></i><?= km($jm['kilometer']) ?>
                          &middot; <?= e($jm['transmisi']) ?>
                        </small>
                      </div>
                      <span class="<?= badge_pengajuan($jm['status']) ?>"><?= e($jm['status']) ?></span>
                    </div>
                    <small class="text-muted" style="font-size:13px">
                      Harga harapan: <strong><?= rupiah($jm['harga_harapan']) ?></strong>
                    </small>
                  </div>
                <?php endforeach; ?>
              <?php else: ?>
                <div class="empty-state py-4">
                  <i class="fa-solid fa-hand-holding-dollar"></i>
                  <h6 class="mt-2">Belum Ada Pengajuan</h6>
                  <p class="mb-3" style="font-size:13.5px">Anda belum pernah mengajukan jual mobil.</p>
                  <a href="<?= BASE_URL ?>jual_mobil.php" class="btn btn-brand btn-sm">Jual Mobil Sekarang</a>
                </div>
              <?php endif; ?>
            </div>
          </div>

          <!-- TUKAR TAMBAH -->
          <div class="tab-pane fade" id="tabTukar">
            <div class="detail-box">
              <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                <h5 class="detail-heading mb-0"><i class="fa-solid fa-right-left"></i> Riwayat Tukar Tambah</h5>
                <a href="<?= BASE_URL ?>tukar_tambah.php" class="btn btn-brand btn-sm">
                  <i class="fa-solid fa-plus me-1"></i>Ajukan Baru
                </a>
              </div>

              <?php if ($riwayatTt): ?>
                <?php foreach ($riwayatTt as $tt): ?>
                  <div class="riwayat-card">
                    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">
                      <div>
                        <strong style="font-size:14.5px">
                          <?= e($tt['merek']) ?> <?= e($tt['model']) ?> (<?= (int)$tt['tahun'] ?>)
                        </strong><br>
                        <small class="text-muted">
                          Target: <?= e($tt['target_merek']) ?> <?= e($tt['target_mobil'] ?: '-') ?>
                        </small>
                      </div>
                      <span class="<?= badge_pengajuan($tt['status']) ?>"><?= e($tt['status']) ?></span>
                    </div>
                    <small class="text-muted" style="font-size:13px">
                      Harga perkiraan: <strong><?= rupiah($tt['harga_perkiraan']) ?></strong>
                    </small>
                  </div>
                <?php endforeach; ?>
              <?php else: ?>
                <div class="empty-state py-4">
                  <i class="fa-solid fa-right-left"></i>
                  <h6 class="mt-2">Belum Ada Pengajuan</h6>
                  <p class="mb-3" style="font-size:13.5px">Anda belum pernah mengajukan tukar tambah.</p>
                  <a href="<?= BASE_URL ?>tukar_tambah.php" class="btn btn-brand btn-sm">Tukar Tambah Sekarang</a>
                </div>
              <?php endif; ?>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</section>

<style>
.riwayat-card{
  background:var(--bg-soft);
  border:1px solid var(--line);
  border-radius:12px;
  padding:16px;
  margin-bottom:12px;
}
.riwayat-card:last-child{ margin-bottom:0; }

.nav-pills .nav-link{
  color:var(--ink-700);
  font-weight:600;
  font-size:14px;
  border-radius:8px;
  padding:.6rem .9rem;
  margin-bottom:4px;
}
.nav-pills .nav-link:hover{ background:var(--bg-soft); }
.nav-pills .nav-link.active{
  background:var(--orange-500);
  color:#fff;
}
.nav-pills .nav-link.active i{ color:#fff; }

@media (max-width:991.98px){
  .nav-pills{ flex-direction:row !important; overflow-x:auto; gap:6px; padding-bottom:6px; }
  .nav-pills .nav-link{ white-space:nowrap; }
  .nav-pills hr{ display:none; }
}
</style>

<?php include __DIR__ . '/includes/footer.php'; ?>