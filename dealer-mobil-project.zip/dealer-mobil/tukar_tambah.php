<?php
/**
 * Tukar Tambah (Form Customer)
 * Lokasi: tukar_tambah.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/wa_helper.php';

$pageTitle = 'Tukar Tambah';
$pageDesc  = 'Tukar mobil lama Anda dengan unit baru dari ' . setting('nama_dealer');

$user = $_SESSION['user'] ?? null;

// Daftar mobil untuk dipilih (yang ingin dibeli)
$mobilList = $pdo->query("
    SELECT m.id, m.nama_mobil, m.tahun, m.harga, mk.nama_merek
    FROM mobil m JOIN merek mk ON mk.id = m.merek_id
    WHERE m.status IN ('Ready','Booked')
    ORDER BY mk.nama_merek, m.nama_mobil
")->fetchAll();

$errors = [];
$sukses = false;
$notifWaUrl = null;
$namaCustomer = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama            = trim($_POST['nama'] ?? '');
    $whatsapp        = trim($_POST['whatsapp'] ?? '');
    $email           = trim($_POST['email'] ?? '');
    $mobil_id        = (int)($_POST['mobil_id'] ?? 0);   // mobil yang ingin dibeli
    $merek           = trim($_POST['merek'] ?? '');      // mobil lama
    $model           = trim($_POST['model'] ?? '');
    $tahun           = (int)($_POST['tahun'] ?? 0);
    $kilometer       = (int)str_replace(['.', ',', ' '], '', $_POST['kilometer'] ?? '0');
    $transmisi       = $_POST['transmisi'] ?? 'Manual';
    $kondisi         = trim($_POST['kondisi'] ?? '');
    $harga_perkiraan = (int)str_replace(['.', ',', ' '], '', $_POST['harga_perkiraan'] ?? '0');
    $catatan         = trim($_POST['catatan'] ?? '');

    if ($nama === '')                     $errors[] = 'Nama wajib diisi.';
    if ($whatsapp === '')                 $errors[] = 'WhatsApp wajib diisi.';
    elseif (!preg_match('/^[0-9+\-\s]{8,20}$/', $whatsapp)) $errors[] = 'Format WhatsApp tidak valid.';
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Format email tidak valid.';
    if ($mobil_id <= 0)                   $errors[] = 'Pilih mobil yang ingin dibeli.';
    if ($merek === '')                    $errors[] = 'Merek mobil lama wajib diisi.';
    if ($model === '')                    $errors[] = 'Model mobil lama wajib diisi.';
    if ($tahun < 1990 || $tahun > (int)date('Y') + 1) $errors[] = 'Tahun tidak valid.';
    if ($harga_perkiraan <= 0)            $errors[] = 'Harga perkiraan wajib diisi.';

    $foto = null;
    if (!empty($_FILES['foto']['name'])) {
        $up = upload_gambar($_FILES['foto'], 'jual-mobil');
        if ($up['sukses']) $foto = $up['file'];
        elseif ($up['error']) $errors[] = 'Foto kendaraan: ' . $up['error'];
    }

    if (!$errors) {
        $stmt = $pdo->prepare("
            INSERT INTO tukar_tambah
            (mobil_id, user_id, merek, model, tahun, kilometer, transmisi, kondisi,
             harga_perkiraan, foto, nama, whatsapp, email, catatan, status)
            VALUES
            (:mobil_id, :uid, :merek, :model, :tahun, :km, :tr, :kondisi,
             :harga, :foto, :nama, :wa, :email, :catatan, 'Pending')
        ");
        $stmt->execute([
            ':mobil_id' => $mobil_id,
            ':uid'      => $user['id'] ?? null,
            ':merek'    => $merek,
            ':model'    => $model,
            ':tahun'    => $tahun,
            ':km'       => $kilometer,
            ':tr'       => $transmisi,
            ':kondisi'  => $kondisi ?: null,
            ':harga'    => $harga_perkiraan,
            ':foto'     => $foto,
            ':nama'     => $nama,
            ':wa'       => $whatsapp,
            ':email'    => $email ?: null,
            ':catatan'  => $catatan ?: null,
        ]);

        $ttId = (int)$pdo->lastInsertId();

        // Ambil data + nama mobil target
        $stmtN = $pdo->prepare("
            SELECT tt.*, m.nama_mobil AS target_mobil, mk.nama_merek AS target_merek
            FROM tukar_tambah tt
            LEFT JOIN mobil m ON m.id = tt.mobil_id
            LEFT JOIN merek mk ON mk.id = m.merek_id
            WHERE tt.id = :id
        ");
        $stmtN->execute([':id' => $ttId]);
        $ttData = $stmtN->fetch();

        $_SESSION['tt_sukses'] = [
            'nama'  => $nama,
            'notif' => wa_link(wa_notif_admin_tukar_tambah($ttData), wa_admin()),
        ];

        header('Location: ' . BASE_URL . 'tukar_tambah.php?sukses=1');
        exit;
    }
}

if (!empty($_GET['sukses']) && !empty($_SESSION['tt_sukses'])) {
    $sukses = true;
    $notifWaUrl = $_SESSION['tt_sukses']['notif'];
    $namaCustomer = $_SESSION['tt_sukses']['nama'];
    unset($_SESSION['tt_sukses']);
}

include __DIR__ . '/includes/header.php';
?>

<div class="breadcrumb-bar">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-2">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Home</a></li>
        <li class="breadcrumb-item active">Tukar Tambah</li>
      </ol>
    </nav>
    <h1>Tukar Tambah Mobil</h1>
    <p class="mb-0" style="color:rgba(255,255,255,.7);font-size:14px">
      Tukar mobil lama Anda dengan unit baru dari kami.
    </p>
  </div>
</div>

<section class="section">
  <div class="container">
    <div class="row g-4">

      <div class="col-lg-7">
        <?php if ($sukses): ?>
          <div class="detail-box" style="border:2px solid #25d366">
            <div class="text-center mb-4">
              <div style="width:64px;height:64px;border-radius:50%;background:#25d366;color:#fff;display:grid;place-items:center;margin:0 auto 14px;font-size:28px">
                <i class="fa-solid fa-check"></i>
              </div>
              <h3 class="mb-2">Pengajuan Berhasil Dikirim</h3>
              <p class="text-muted mb-0" style="font-size:14.5px">
                Terima kasih, <strong><?= e($namaCustomer) ?></strong>.
                Tim kami akan menghubungi Anda untuk penilaian kendaraan.
              </p>
            </div>

            <div style="background:#f5f7fa;border-radius:12px;padding:20px;text-align:center;margin-bottom:16px">
              <p class="mb-3" style="font-size:14px">
                Kirim notifikasi ke admin agar pengajuan Anda diproses lebih cepat.
              </p>
              <a href="<?= e($notifWaUrl) ?>" target="_blank" rel="noopener" class="btn btn-wa btn-lg">
                <i class="fa-brands fa-whatsapp me-2"></i>Kirim Notifikasi ke Admin
              </a>
            </div>

            <div class="text-center text-muted" style="font-size:13px">
              <a href="<?= BASE_URL ?>katalog.php">Kembali ke katalog</a> &middot;
              <a href="<?= BASE_URL ?>index.php">Halaman utama</a>
            </div>
          </div>
        <?php else: ?>

          <?php if ($errors): ?>
            <div class="alert alert-danger">
              <strong>Periksa kembali data Anda:</strong>
              <ul class="mb-0 mt-2 ps-3">
                <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
              </ul>
            </div>
          <?php endif; ?>

          <div class="detail-box">
            <h5 class="detail-heading"><i class="fa-solid fa-right-left"></i> Form Tukar Tambah</h5>

            <form method="post" enctype="multipart/form-data" novalidate>

              <h6 class="mb-3" style="font-size:14px;color:var(--ink-500)">Mobil Yang Ingin Dibeli</h6>
              <div class="mb-4">
                <select name="mobil_id" class="form-select" required>
                  <option value="">-- Pilih mobil dari katalog --</option>
                  <?php foreach ($mobilList as $m): ?>
                    <option value="<?= (int)$m['id'] ?>" <?= (int)($_POST['mobil_id'] ?? 0) === (int)$m['id'] ? 'selected' : '' ?>>
                      <?= e($m['nama_merek']) ?> <?= e($m['nama_mobil']) ?> (<?= (int)$m['tahun'] ?>) - <?= rupiah($m['harga']) ?>
                    </option>
                  <?php endforeach; ?>
                </select>
              </div>

              <hr class="my-4">

              <h6 class="mb-3" style="font-size:14px;color:var(--ink-500)">Mobil Yang Ingin Ditukar</h6>
              <div class="row g-3 mb-3">
                <div class="col-md-6">
                  <label class="form-label">Merek <span class="text-danger">*</span></label>
                  <input type="text" name="merek" class="form-control" required
                         value="<?= e($_POST['merek'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Model <span class="text-danger">*</span></label>
                  <input type="text" name="model" class="form-control" required
                         value="<?= e($_POST['model'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Tahun <span class="text-danger">*</span></label>
                  <input type="number" name="tahun" class="form-control" required
                         min="1990" max="<?= date('Y') + 1 ?>"
                         value="<?= e($_POST['tahun'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Kilometer</label>
                  <input type="number" name="kilometer" class="form-control" min="0"
                         value="<?= e($_POST['kilometer'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Transmisi</label>
                  <select name="transmisi" class="form-select">
                    <option value="Manual"    <?= ($_POST['transmisi'] ?? '') === 'Manual'    ? 'selected' : '' ?>>Manual</option>
                    <option value="Automatic" <?= ($_POST['transmisi'] ?? '') === 'Automatic' ? 'selected' : '' ?>>Automatic</option>
                  </select>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Harga Perkiraan (Rp) <span class="text-danger">*</span></label>
                  <input type="number" name="harga_perkiraan" class="form-control" required min="0" step="1000000"
                         value="<?= e($_POST['harga_perkiraan'] ?? '') ?>">
                </div>
                <div class="col-12">
                  <label class="form-label">Kondisi Kendaraan</label>
                  <textarea name="kondisi" class="form-control" rows="2"><?= e($_POST['kondisi'] ?? '') ?></textarea>
                </div>
                <div class="col-12">
                  <label class="form-label">Foto Kendaraan</label>
                  <input type="file" name="foto" class="form-control" accept="image/*">
                  <small class="form-text">JPG/PNG/WEBP max 2 MB.</small>
                </div>
              </div>

              <hr class="my-4">

              <h6 class="mb-3" style="font-size:14px;color:var(--ink-500)">Data Diri</h6>
              <div class="row g-3 mb-3">
                <div class="col-md-6">
                  <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                  <input type="text" name="nama" class="form-control" required
                         value="<?= e($_POST['nama'] ?? $user['nama'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">WhatsApp <span class="text-danger">*</span></label>
                  <input type="text" name="whatsapp" class="form-control" required
                         value="<?= e($_POST['whatsapp'] ?? $user['no_whatsapp'] ?? '') ?>">
                </div>
                <div class="col-12">
                  <label class="form-label">Email</label>
                  <input type="email" name="email" class="form-control"
                         value="<?= e($_POST['email'] ?? $user['email'] ?? '') ?>">
                </div>
                <div class="col-12">
                  <label class="form-label">Catatan</label>
                  <textarea name="catatan" class="form-control" rows="2"><?= e($_POST['catatan'] ?? '') ?></textarea>
                </div>
              </div>

              <button type="submit" class="btn btn-brand btn-lg w-100">
                <i class="fa-solid fa-paper-plane me-2"></i>Kirim Pengajuan
              </button>
            </form>
          </div>
        <?php endif; ?>
      </div>

      <div class="col-lg-5">
        <div class="detail-box mb-4">
          <h5 class="detail-heading"><i class="fa-solid fa-circle-info"></i> Keuntungan Tukar Tambah</h5>
          <div class="info-mini">
            <div class="d-flex gap-3 mb-3">
              <i class="fa-solid fa-money-bill-wave"></i>
              <div>
                <strong>Harga Bersaing</strong>
                <p class="mb-0">Kami menilai mobil Anda dengan harga pasaran yang fair.</p>
              </div>
            </div>
            <div class="d-flex gap-3 mb-3">
              <i class="fa-solid fa-file-signature"></i>
              <div>
                <strong>Proses Cepat</strong>
                <p class="mb-0">Dokumen dan pembayaran diproses dalam hitungan hari.</p>
              </div>
            </div>
            <div class="d-flex gap-3">
              <i class="fa-solid fa-car-side"></i>
              <div>
                <strong>Unit Baru Siap Pakai</strong>
                <p class="mb-0">Langsung bawa pulang unit pilihan Anda setelah deal.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="p-4 rounded-lg" style="background:linear-gradient(160deg,#0f2440,#1b3a66);color:#fff">
          <h6 class="text-white mb-2"><i class="fa-brands fa-whatsapp me-2"></i>Butuh Bantuan?</h6>
          <p style="color:rgba(255,255,255,.75);font-size:13.5px">
            Diskusikan kebutuhan tukar tambah Anda dengan tim kami.
          </p>
          <a href="<?= wa_link('Halo, saya ingin menanyakan tukar tambah mobil') ?>"
             target="_blank" rel="noopener" class="btn btn-wa w-100">
            <i class="fa-brands fa-whatsapp me-2"></i>Chat Sekarang
          </a>
        </div>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>