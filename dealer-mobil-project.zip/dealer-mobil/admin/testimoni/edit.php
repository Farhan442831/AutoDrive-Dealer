<?php
/**
 * Testimoni - Edit
 * Lokasi: admin/testimoni/edit.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . BASE_URL . 'admin/testimoni/index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM testimoni WHERE id = :id");
$stmt->execute([':id' => $id]);
$t = $stmt->fetch();
if (!$t) {
    set_flash('danger', 'Testimoni tidak ditemukan.');
    header('Location: ' . BASE_URL . 'admin/testimoni/index.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama      = trim($_POST['nama'] ?? '');
    $kota      = trim($_POST['kota'] ?? '');
    $pekerjaan = trim($_POST['pekerjaan'] ?? '');
    $pesan     = trim($_POST['pesan'] ?? '');
    $rating    = (int)($_POST['rating'] ?? 5);
    $status    = $_POST['status'] ?? 'tampil';

    if ($nama === '')  $errors[] = 'Nama wajib diisi.';
    if ($pesan === '') $errors[] = 'Pesan wajib diisi.';

    if (!$errors) {
        $upd = $pdo->prepare("
            UPDATE testimoni SET nama=:nama, kota=:kota, pekerjaan=:pekerjaan,
                pesan=:pesan, rating=:rating, status=:status
            WHERE id=:id
        ");
        $upd->execute([
            ':nama'      => $nama,
            ':kota'      => $kota ?: null,
            ':pekerjaan' => $pekerjaan ?: null,
            ':pesan'     => $pesan,
            ':rating'    => $rating,
            ':status'    => $status,
            ':id'        => $id,
        ]);
        set_flash('success', 'Testimoni berhasil diperbarui.');
        header('Location: ' . BASE_URL . 'admin/testimoni/edit.php?id=' . $id);
        exit;
    }
}

$pageTitle = 'Edit Testimoni';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Edit Testimoni</h5>
    <small class="text-muted"><?= e($t['nama']) ?></small>
  </div>
  <a href="<?= BASE_URL ?>admin/testimoni/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="panel">
      <div class="panel-head"><h5><i class="fa-solid fa-quote-left text-orange me-2"></i>Data Testimoni</h5></div>
      <div class="panel-body">
        <form method="post">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Nama Pelanggan <span class="text-danger">*</span></label>
              <input type="text" name="nama" class="form-control" required value="<?= e($t['nama']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Kota</label>
              <input type="text" name="kota" class="form-control" value="<?= e($t['kota']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Pekerjaan</label>
              <input type="text" name="pekerjaan" class="form-control" value="<?= e($t['pekerjaan']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Rating</label>
              <select name="rating" class="form-select">
                <?php for ($i = 5; $i >= 1; $i--): ?>
                  <option value="<?= $i ?>" <?= (int)$t['rating'] === $i ? 'selected' : '' ?>>
                    <?= str_repeat('★', $i) ?> (<?= $i ?>)
                  </option>
                <?php endfor; ?>
              </select>
            </div>
            <div class="col-12">
              <label class="form-label">Pesan</label>
              <textarea name="pesan" class="form-control" rows="5" required><?= e($t['pesan']) ?></textarea>
            </div>
            <div class="col-md-6">
              <label class="form-label">Status</label>
              <select name="status" class="form-select">
                <option value="tampil"   <?= $t['status'] === 'tampil'   ? 'selected' : '' ?>>Tampil</option>
                <option value="sembunyi" <?= $t['status'] === 'sembunyi' ? 'selected' : '' ?>>Sembunyikan</option>
              </select>
            </div>
            <div class="col-12 mt-4">
              <button type="submit" class="btn btn-brand btn-lg w-100">
                <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Perubahan
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>