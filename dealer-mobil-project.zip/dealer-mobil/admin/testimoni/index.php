<?php
/**
 * Testimoni - List
 * Lokasi: admin/testimoni/index.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

if (isset($_GET['hapus'])) {
    $hid = (int)$_GET['hapus'];
    $pdo->prepare("DELETE FROM testimoni WHERE id = :id")->execute([':id' => $hid]);
    set_flash('success', 'Testimoni berhasil dihapus.');
    header('Location: ' . BASE_URL . 'admin/testimoni/index.php');
    exit;
}

$pageTitle = 'Testimoni';
require_once __DIR__ . '/../includes/header.php';

$list = $pdo->query("SELECT * FROM testimoni ORDER BY created_at DESC")->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Manajemen Testimoni</h5>
    <small class="text-muted">Total <?= count($list) ?> testimoni</small>
  </div>
  <a href="<?= BASE_URL ?>admin/testimoni/tambah.php" class="btn btn-brand">
    <i class="fa-solid fa-plus me-2"></i>Tambah Testimoni
  </a>
</div>

<div class="panel">
  <div class="panel-body">
    <div class="table-responsive">
      <table class="table table-admin align-middle">
        <thead>
          <tr>
            <th>Nama</th>
            <th>Pekerjaan / Kota</th>
            <th>Rating</th>
            <th>Pesan</th>
            <th>Status</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($list): foreach ($list as $row): ?>
            <tr>
              <td>
                <div class="d-flex align-items-center gap-2">
                  <div class="avatar-mini" style="width:36px;height:36px;font-size:13px">
                    <?= e(inisial($row['nama'])) ?>
                  </div>
                  <strong style="font-size:13.5px"><?= e($row['nama']) ?></strong>
                </div>
              </td>
              <td>
                <small>
                  <?= e($row['pekerjaan'] ?: '-') ?>
                  <?php if ($row['kota']): ?><br><span class="text-muted"><?= e($row['kota']) ?></span><?php endif; ?>
                </small>
              </td>
              <td>
                <span style="color:#f5a623;font-size:13px">
                  <?php for ($i = 1; $i <= 5; $i++): ?>
                    <i class="fa-<?= $i <= (int)$row['rating'] ? 'solid' : 'regular' ?> fa-star"></i>
                  <?php endfor; ?>
                </span>
              </td>
              <td style="max-width:280px"><small><?= e(potong($row['pesan'], 100)) ?></small></td>
              <td>
                <?php if ($row['status'] === 'tampil'): ?>
                  <span class="badge bg-success-subtle text-success-emphasis border border-success-subtle">Tampil</span>
                <?php else: ?>
                  <span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle">Sembunyi</span>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <div class="d-flex gap-1 justify-content-end">
                  <a href="<?= BASE_URL ?>admin/testimoni/edit.php?id=<?= (int)$row['id'] ?>"
                     class="btn btn-sm btn-navy">
                    <i class="fa-solid fa-pen"></i>
                  </a>
                  <a href="?hapus=<?= (int)$row['id'] ?>"
                     class="btn btn-sm btn-danger btn-konfirmasi-hapus"
                     data-msg="Hapus testimoni dari <?= e($row['nama']) ?>?">
                    <i class="fa-solid fa-trash"></i>
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; else: ?>
            <tr><td colspan="6" class="text-center py-5 text-muted">
              <i class="fa-solid fa-quote-left d-block mb-2" style="font-size:32px;opacity:.4"></i>
              Belum ada testimoni. <a href="<?= BASE_URL ?>admin/testimoni/tambah.php">Tambah sekarang</a>
            </td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="modal fade" id="modalHapus" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Konfirmasi Hapus</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body"><p class="mb-0" id="msgHapus"></p></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-bs-dismiss="modal">Batal</button>
        <a href="#" id="linkHapus" class="btn btn-danger">Hapus</a>
      </div>
    </div>
  </div>
</div>

<script>
document.querySelectorAll('.btn-konfirmasi-hapus').forEach(function(el){
  el.addEventListener('click', function(e){
    e.preventDefault();
    document.getElementById('msgHapus').textContent = this.dataset.msg;
    document.getElementById('linkHapus').href = this.href;
    new bootstrap.Modal(document.getElementById('modalHapus')).show();
  });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>