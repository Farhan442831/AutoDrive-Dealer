<?php
/**
 * Pengaturan Website
 * Lokasi: admin/pengaturan/index.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin']); // KHUSUS ADMIN

$errors = [];
$sukses = false;

// Daftar setting yang bisa diubah
$fields = [
    'nama_dealer'      => ['label' => 'Nama Dealer', 'type' => 'text', 'required' => true],
    'tagline'          => ['label' => 'Tagline', 'type' => 'text'],
    'alamat'           => ['label' => 'Alamat Showroom', 'type' => 'textarea'],
    'whatsapp'         => ['label' => 'Nomor WhatsApp', 'type' => 'text', 'help' => 'Format: 6281234567890 (tanpa +, spasi, atau 0 di depan)'],
    'telepon'          => ['label' => 'Telepon', 'type' => 'text'],
    'email'            => ['label' => 'Email', 'type' => 'email'],
    'jam_operasional'  => ['label' => 'Jam Operasional', 'type' => 'text'],
    'maps_embed'       => ['label' => 'Google Maps Embed URL', 'type' => 'textarea', 'help' => 'Dapatkan dari Google Maps → Share → Embed a map'],
    'facebook'         => ['label' => 'Link Facebook', 'type' => 'text'],
    'instagram'        => ['label' => 'Link Instagram', 'type' => 'text'],
    'youtube'          => ['label' => 'Link YouTube', 'type' => 'text'],
    'footer_text'      => ['label' => 'Deskripsi Footer', 'type' => 'textarea'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($fields as $key => $conf) {
        $nilai = trim($_POST[$key] ?? '');
        if (!empty($conf['required']) && $nilai === '') {
            $errors[] = $conf['label'] . ' wajib diisi.';
            continue;
        }
        if ($key === 'whatsapp' && $nilai !== '') {
            $nilai = preg_replace('/[^0-9]/', '', $nilai);
            if (str_starts_with($nilai, '0')) $nilai = '62' . substr($nilai, 1);
        }

        // Update atau insert
        $cek = $pdo->prepare("SELECT id FROM pengaturan WHERE nama_pengaturan = :k");
        $cek->execute([':k' => $key]);
        if ($cek->fetch()) {
            $pdo->prepare("UPDATE pengaturan SET nilai = :v WHERE nama_pengaturan = :k")
                ->execute([':v' => $nilai, ':k' => $key]);
        } else {
            $pdo->prepare("INSERT INTO pengaturan (nama_pengaturan, nilai) VALUES (:k, :v)")
                ->execute([':k' => $key, ':v' => $nilai]);
        }
    }

    if (!$errors) {
        set_flash('success', 'Pengaturan berhasil disimpan.');
        header('Location: ' . BASE_URL . 'admin/pengaturan/index.php');
        exit;
    }
}

$pageTitle = 'Pengaturan';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Pengaturan Website</h5>
    <small class="text-muted">Atur informasi dan kontak dealer</small>
  </div>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<form method="post">
  <div class="row g-4">
    <div class="col-lg-8">
      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-store text-orange me-2"></i>Informasi Dealer</h5></div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Nama Dealer <span class="text-danger">*</span></label>
              <input type="text" name="nama_dealer" class="form-control" required
                     value="<?= e(setting('nama_dealer')) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Tagline</label>
              <input type="text" name="tagline" class="form-control"
                     value="<?= e(setting('tagline')) ?>">
            </div>
            <div class="col-12">
              <label class="form-label">Alamat Showroom</label>
              <textarea name="alamat" class="form-control" rows="2"><?= e(setting('alamat')) ?></textarea>
            </div>
            <div class="col-md-6">
              <label class="form-label">Nomor WhatsApp</label>
              <input type="text" name="whatsapp" class="form-control"
                     value="<?= e(setting('whatsapp')) ?>">
              <small class="form-text">Format: 6281234567890</small>
            </div>
            <div class="col-md-6">
              <label class="form-label">Telepon</label>
              <input type="text" name="telepon" class="form-control"
                     value="<?= e(setting('telepon')) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control"
                     value="<?= e(setting('email')) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Jam Operasional</label>
              <input type="text" name="jam_operasional" class="form-control"
                     value="<?= e(setting('jam_operasional')) ?>">
            </div>
          </div>
        </div>
      </div>

      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-map text-orange me-2"></i>Google Maps</h5></div>
        <div class="panel-body">
          <label class="form-label">Google Maps Embed URL</label>
          <textarea name="maps_embed" class="form-control" rows="3"><?= e(setting('maps_embed')) ?></textarea>
          <small class="form-text">
            Cara dapat: buka Google Maps → cari lokasi → klik Share → Embed a map → Copy HTML → ambil isi <code>src="..."</code>
          </small>
        </div>
      </div>

      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-share-nodes text-orange me-2"></i>Sosial Media</h5></div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-md-4">
              <label class="form-label"><i class="fa-brands fa-facebook text-primary me-1"></i>Facebook</label>
              <input type="text" name="facebook" class="form-control" value="<?= e(setting('facebook')) ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label"><i class="fa-brands fa-instagram text-danger me-1"></i>Instagram</label>
              <input type="text" name="instagram" class="form-control" value="<?= e(setting('instagram')) ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label"><i class="fa-brands fa-youtube text-danger me-1"></i>YouTube</label>
              <input type="text" name="youtube" class="form-control" value="<?= e(setting('youtube')) ?>">
            </div>
          </div>
        </div>
      </div>

      <div class="panel">
        <div class="panel-head"><h5><i class="fa-solid fa-paragraph text-orange me-2"></i>Footer</h5></div>
        <div class="panel-body">
          <label class="form-label">Deskripsi Footer</label>
          <textarea name="footer_text" class="form-control" rows="3"><?= e(setting('footer_text')) ?></textarea>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="panel sticky-top" style="top:90px">
        <div class="panel-head"><h5><i class="fa-solid fa-save text-orange me-2"></i>Aksi</h5></div>
        <div class="panel-body">
          <p class="text-muted mb-3" style="font-size:13.5px">
            Perubahan akan langsung diterapkan di seluruh halaman website.
          </p>
          <button type="submit" class="btn btn-brand btn-lg w-100 mb-2">
            <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Pengaturan
          </button>
          <a href="<?= BASE_URL ?>index.php" target="_blank" class="btn btn-ghost w-100">
            <i class="fa-solid fa-eye me-2"></i>Lihat Website
          </a>

          <div class="alert alert-light border mt-3 mb-0" style="font-size:12.5px">
            <strong class="d-block mb-1"><i class="fa-solid fa-circle-info text-orange me-1"></i> Tips:</strong>
            Nomor WhatsApp yang benar akan memastikan semua tombol chat di website bekerja dengan baik.
          </div>
        </div>
      </div>
    </div>
  </div>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>