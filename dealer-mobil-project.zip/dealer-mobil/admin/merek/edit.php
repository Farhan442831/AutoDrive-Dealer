<?php
/**
 * Merek - Edit
 * Lokasi: admin/merek/edit.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . BASE_URL . 'admin/merek/index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM merek WHERE id = :id");
$stmt->execute([':id' => $id]);
$merek = $stmt->fetch();
if (!$merek) {
    set_flash('danger', 'Merek tidak ditemukan.');
    header('Location: ' . BASE_URL . 'admin/merek/index.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_merek = trim($_POST['nama_merek'] ?? '');
    $slug       = buat_slug($nama_merek);

    if ($nama_merek === '') $errors[] = 'Nama merek wajib diisi.';

    if (!$errors) {
        $cek = $pdo->prepare("SELECT id FROM merek WHERE slug = :slug AND id != :id");
        $cek->execute([':slug' => $slug, ':id' => $id]);
        if ($cek->fetch()) {
            $errors[] = 'Nama merek sudah digunakan merek lain.';
        } else {
            $pdo->prepare("UPDATE merek SET nama_merek = :n, slug = :s WHERE id = :id")
                ->execute([':n' => $nama_merek, ':s' => $slug, ':id' => $id]);
            set_flash('success', 'Merek berhasil diperbarui.');
            header('Location: ' . BASE_URL . 'admin/merek/index.php');
            exit;
        }
    }
}

$pageTitle = 'Edit Merek';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Edit Merek</h5>
    <small class="text-muted"><?= e($merek['nama_merek']) ?></small>
  </div>
  <a href="<?= BASE_URL ?>admin/merek/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<div class="row justify-content-center">
  <div class="col-lg-6">
    <div class="panel">
      <div class="panel-head"><h5><i class="fa-solid fa-trademark text-orange me-2"></i>Data Merek</h5></div>
      <div class="panel-body">
        <form method="post">
          <div class="mb-3">
            <label class="form-label">Nama Merek <span class="text-danger">*</span></label>
            <input type="text" name="nama_merek" class="form-control" required
                   value="<?= e($merek['nama_merek']) ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Slug saat ini</label>
            <input type="text" class="form-control" value="<?= e($merek['slug']) ?>" readonly>
            <small class="form-text">Slug akan otomatis berubah jika nama merek diubah.</small>
          </div>
          <button type="submit" class="btn btn-brand w-100">
            <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Perubahan
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>