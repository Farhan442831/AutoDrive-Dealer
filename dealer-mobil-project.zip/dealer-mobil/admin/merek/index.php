<?php
/**
 * Merek - List
 * Lokasi: admin/merek/index.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin']);

if (isset($_GET['hapus'])) {
    $hid = (int)$_GET['hapus'];
    // Cek apakah masih dipakai mobil
    $cek = $pdo->prepare("SELECT COUNT(*) FROM mobil WHERE merek_id = :id");
    $cek->execute([':id' => $hid]);
    if ((int)$cek->fetchColumn() > 0) {
        set_flash('danger', 'Merek tidak dapat dihapus karena masih digunakan oleh mobil.');
    } else {
        $pdo->prepare("DELETE FROM merek WHERE id = :id")->execute([':id' => $hid]);
        set_flash('success', 'Merek berhasil dihapus.');
    }
    header('Location: ' . BASE_URL . 'admin/merek/index.php');
    exit;
}

$pageTitle = 'Merek Mobil';
require_once __DIR__ . '/../includes/header.php';

$list = $pdo->query("
    SELECT mk.*, (SELECT COUNT(*) FROM mobil WHERE merek_id = mk.id) AS jumlah_mobil
    FROM merek mk
    ORDER BY mk.nama_merek ASC
")->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Merek Mobil</h5>
    <small class="text-muted">Total <?= count($list) ?> merek</small>
  </div>
  <a href="<?= BASE_URL ?>admin/merek/tambah.php" class="btn btn-brand">
    <i class="fa-solid fa-plus me-2"></i>Tambah Merek
  </a>
</div>

<div class="panel">
  <div class="panel-body">
    <div class="table-responsive">
      <table class="table table-admin align-middle">
        <thead>
          <tr>
            <th>#</th>
            <th>Nama Merek</th>
            <th>Slug</th>
            <th>Jumlah Mobil</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($list): foreach ($list as $i => $row): ?>
            <tr>
              <td><?= $i + 1 ?></td>
              <td><strong style="font-size:13.5px"><?= e($row['nama_merek']) ?></strong></td>
              <td><code style="font-size:12.5px"><?= e($row['slug']) ?></code></td>
              <td>
                <span class="badge bg-navy text-white" style="background:var(--navy-700)">
                  <?= (int)$row['jumlah_mobil'] ?> unit
                </span>
              </td>
              <td class="text-end">
                <div class="d-flex gap-1 justify-content-end">
                  <a href="<?= BASE_URL ?>admin/merek/edit.php?id=<?= (int)$row['id'] ?>"
                     class="btn btn-sm btn-navy">
                    <i class="fa-solid fa-pen"></i>
                  </a>
                  <a href="?hapus=<?= (int)$row['id'] ?>"
                     class="btn btn-sm btn-danger btn-konfirmasi-hapus"
                     data-msg="Hapus merek '<?= e($row['nama_merek']) ?>'?">
                    <i class="fa-solid fa-trash"></i>
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; else: ?>
            <tr><td colspan="5" class="text-center py-5 text-muted">
              <i class="fa-solid fa-trademark d-block mb-2" style="font-size:32px;opacity:.4"></i>
              Belum ada merek. <a href="<?= BASE_URL ?>admin/merek/tambah.php">Tambah sekarang</a>
            </td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="modal fade" id="modalHapus" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Konfirmasi Hapus</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body"><p class="mb-0" id="msgHapus"></p></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-bs-dismiss="modal">Batal</button>
        <a href="#" id="linkHapus" class="btn btn-danger">Hapus</a>
      </div>
    </div>
  </div>
</div>

<script>
document.querySelectorAll('.btn-konfirmasi-hapus').forEach(function(el){
  el.addEventListener('click', function(e){
    e.preventDefault();
    document.getElementById('msgHapus').textContent = this.dataset.msg;
    document.getElementById('linkHapus').href = this.href;
    new bootstrap.Modal(document.getElementById('modalHapus')).show();
  });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>