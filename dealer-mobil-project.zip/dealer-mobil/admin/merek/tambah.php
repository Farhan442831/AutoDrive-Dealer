<?php
/**
 * Merek - Tambah
 * Lokasi: admin/merek/tambah.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin']);

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_merek = trim($_POST['nama_merek'] ?? '');
    $slug       = buat_slug($nama_merek);

    if ($nama_merek === '') $errors[] = 'Nama merek wajib diisi.';

    if (!$errors) {
        $cek = $pdo->prepare("SELECT id FROM merek WHERE slug = :slug");
        $cek->execute([':slug' => $slug]);
        if ($cek->fetch()) {
            $errors[] = 'Merek sudah ada.';
        } else {
            $pdo->prepare("INSERT INTO merek (nama_merek, slug) VALUES (:n, :s)")
                ->execute([':n' => $nama_merek, ':s' => $slug]);
            set_flash('success', 'Merek berhasil ditambahkan.');
            header('Location: ' . BASE_URL . 'admin/merek/index.php');
            exit;
        }
    }
}

$pageTitle = 'Tambah Merek';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Tambah Merek Baru</h5>
    <small class="text-muted">Slug akan dibuat otomatis dari nama merek</small>
  </div>
  <a href="<?= BASE_URL ?>admin/merek/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<div class="row justify-content-center">
  <div class="col-lg-6">
    <div class="panel">
      <div class="panel-head"><h5><i class="fa-solid fa-trademark text-orange me-2"></i>Data Merek</h5></div>
      <div class="panel-body">
        <form method="post">
          <div class="mb-3">
            <label class="form-label">Nama Merek <span class="text-danger">*</span></label>
            <input type="text" name="nama_merek" class="form-control" required autofocus
                   placeholder="Contoh: Toyota, Honda, Mitsubishi"
                   value="<?= e($_POST['nama_merek'] ?? '') ?>">
            <small class="form-text">Nama harus unik, tidak boleh sama dengan yang sudah ada.</small>
          </div>
          <button type="submit" class="btn btn-brand w-100">
            <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Merek
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>