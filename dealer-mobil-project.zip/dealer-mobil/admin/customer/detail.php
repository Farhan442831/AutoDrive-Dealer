<?php
/**
 * Customer - Detail + Riwayat
 * Lokasi: admin/customer/detail.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . BASE_URL . 'admin/customer/index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id AND role = 'customer'");
$stmt->execute([':id' => $id]);
$customer = $stmt->fetch();
if (!$customer) {
    set_flash('danger', 'Customer tidak ditemukan.');
    header('Location: ' . BASE_URL . 'admin/customer/index.php');
    exit;
}

// Riwayat
$stmtTd = $pdo->prepare("
    SELECT td.*, m.nama_mobil, mk.nama_merek
    FROM test_drive td
    LEFT JOIN mobil m ON m.id = td.mobil_id
    LEFT JOIN merek mk ON mk.id = m.merek_id
    WHERE td.user_id = :uid ORDER BY td.created_at DESC
");
$stmtTd->execute([':uid' => $id]);
$riwayatTd = $stmtTd->fetchAll();

$stmtJm = $pdo->prepare("SELECT * FROM jual_mobil WHERE user_id = :uid ORDER BY created_at DESC");
$stmtJm->execute([':uid' => $id]);
$riwayatJm = $stmtJm->fetchAll();

$stmtTt = $pdo->prepare("
    SELECT tt.*, m.nama_mobil AS target_mobil, mk.nama_merek AS target_merek
    FROM tukar_tambah tt
    LEFT JOIN mobil m ON m.id = tt.mobil_id
    LEFT JOIN merek mk ON mk.id = m.merek_id
    WHERE tt.user_id = :uid ORDER BY tt.created_at DESC
");
$stmtTt->execute([':uid' => $id]);
$riwayatTt = $stmtTt->fetchAll();

$pageTitle = 'Detail Customer';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Detail Customer</h5>
    <small class="text-muted"><?= e($customer['nama']) ?></small>
  </div>
  <a href="<?= BASE_URL ?>admin/customer/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<div class="row g-4">
  <div class="col-lg-4">
    <div class="panel mb-4">
      <div class="panel-body text-center">
        <div class="testi-avatar mx-auto mb-3" style="width:80px;height:80px;font-size:28px">
          <?= e(inisial($customer['nama'])) ?>
        </div>
        <h5 class="mb-1"><?= e($customer['nama']) ?></h5>
        <small class="text-muted d-block mb-3"><?= e($customer['email']) ?></small>
        <span class="badge bg-primary-subtle text-primary-emphasis border border-primary-subtle">
          Customer
        </span>
      </div>
    </div>

    <div class="panel">
      <div class="panel-head"><h5><i class="fa-regular fa-user text-orange me-2"></i>Informasi</h5></div>
      <div class="panel-body">
        <div class="d-flex flex-column gap-3" style="font-size:13.5px">
          <div>
            <small class="text-muted d-block">WhatsApp</small>
            <?php if ($customer['no_whatsapp']): ?>
              <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $customer['no_whatsapp']) ?>"
                 target="_blank" class="text-success fw-bold">
                <i class="fa-brands fa-whatsapp"></i> <?= e($customer['no_whatsapp']) ?>
              </a>
            <?php else: ?>
              <span class="text-muted">-</span>
            <?php endif; ?>
          </div>
          <div>
            <small class="text-muted d-block">Alamat</small>
            <span><?= e($customer['alamat'] ?: '-') ?></span>
          </div>
          <div>
            <small class="text-muted d-block">Terdaftar</small>
            <span><?= tanggal_id($customer['created_at'], true) ?></span>
          </div>
        </div>

        <?php if ($customer['no_whatsapp']): ?>
          <a href="<?= wa_link('Halo ' . $customer['nama'] . ', terima kasih telah menjadi pelanggan ' . setting('nama_dealer'), $customer['no_whatsapp']) ?>"
             target="_blank" rel="noopener" class="btn btn-wa w-100 mt-4">
            <i class="fa-brands fa-whatsapp me-2"></i>Chat Customer
          </a>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="col-lg-8">
    <!-- TEST DRIVE -->
    <div class="panel mb-4">
      <div class="panel-head">
        <h5><i class="fa-solid fa-car-side text-orange me-2"></i>Riwayat Test Drive</h5>
        <span class="badge bg-secondary"><?= count($riwayatTd) ?></span>
      </div>
      <div class="table-responsive">
        <table class="table table-admin">
          <thead><tr><th>Mobil</th><th>Jadwal</th><th>Status</th></tr></thead>
          <tbody>
            <?php if ($riwayatTd): foreach ($riwayatTd as $td): ?>
              <tr>
                <td><small><?= e($td['nama_merek']) ?> <?= e($td['nama_mobil']) ?></small></td>
                <td><small><?= tanggal_id($td['tanggal']) ?> · <?= substr($td['jam'], 0, 5) ?></small></td>
                <td><span class="<?= badge_pengajuan($td['status']) ?>"><?= e($td['status']) ?></span></td>
              </tr>
            <?php endforeach; else: ?>
              <tr><td colspan="3" class="text-center text-muted py-4">Belum ada pengajuan test drive.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- JUAL MOBIL -->
    <div class="panel mb-4">
      <div class="panel-head">
        <h5><i class="fa-solid fa-hand-holding-dollar text-orange me-2"></i>Riwayat Jual Mobil</h5>
        <span class="badge bg-secondary"><?= count($riwayatJm) ?></span>
      </div>
      <div class="table-responsive">
        <table class="table table-admin">
          <thead><tr><th>Kendaraan</th><th>Harga Harapan</th><th>Status</th></tr></thead>
          <tbody>
            <?php if ($riwayatJm): foreach ($riwayatJm as $jm): ?>
              <tr>
                <td><small><strong><?= e($jm['merek']) ?> <?= e($jm['model']) ?></strong> (<?= (int)$jm['tahun'] ?>)</small></td>
                <td><small><?= rupiah($jm['harga_harapan']) ?></small></td>
                <td><span class="<?= badge_pengajuan($jm['status']) ?>"><?= e($jm['status']) ?></span></td>
              </tr>
            <?php endforeach; else: ?>
              <tr><td colspan="3" class="text-center text-muted py-4">Belum ada pengajuan jual mobil.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- TUKAR TAMBAH -->
    <div class="panel">
      <div class="panel-head">
        <h5><i class="fa-solid fa-right-left text-orange me-2"></i>Riwayat Tukar Tambah</h5>
        <span class="badge bg-secondary"><?= count($riwayatTt) ?></span>
      </div>
      <div class="table-responsive">
        <table class="table table-admin">
          <thead><tr><th>Kendaraan</th><th>Target</th><th>Status</th></tr></thead>
          <tbody>
            <?php if ($riwayatTt): foreach ($riwayatTt as $tt): ?>
              <tr>
                <td><small><strong><?= e($tt['merek']) ?> <?= e($tt['model']) ?></strong> (<?= (int)$tt['tahun'] ?>)</small></td>
                <td><small><?= e($tt['target_merek']) ?> <?= e($tt['target_mobil'] ?: '-') ?></small></td>
                <td><span class="<?= badge_pengajuan($tt['status']) ?>"><?= e($tt['status']) ?></span></td>
              </tr>
            <?php endforeach; else: ?>
              <tr><td colspan="3" class="text-center text-muted py-4">Belum ada pengajuan tukar tambah.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>