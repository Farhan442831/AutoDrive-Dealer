<?php
/**
 * Customer - List
 * Lokasi: admin/customer/index.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

if (isset($_GET['hapus'])) {
    $hid = (int)$_GET['hapus'];
    $pdo->prepare("DELETE FROM users WHERE id = :id AND role = 'customer'")->execute([':id' => $hid]);
    set_flash('success', 'Customer berhasil dihapus.');
    header('Location: ' . BASE_URL . 'admin/customer/index.php');
    exit;
}

$pageTitle = 'Customer';
require_once __DIR__ . '/../includes/header.php';

$q = trim($_GET['q'] ?? '');
$where = "WHERE role = 'customer'";
$params = [];
if ($q !== '') {
    $where .= " AND (nama LIKE :q OR email LIKE :q OR no_whatsapp LIKE :q)";
    $params[':q'] = '%' . $q . '%';
}

$stmt = $pdo->prepare("
    SELECT u.*,
        (SELECT COUNT(*) FROM test_drive WHERE user_id = u.id) AS total_td,
        (SELECT COUNT(*) FROM jual_mobil WHERE user_id = u.id) AS total_jm,
        (SELECT COUNT(*) FROM tukar_tambah WHERE user_id = u.id) AS total_tt
    FROM users u
    $where
    ORDER BY u.created_at DESC
");
$stmt->execute($params);
$list = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Data Customer</h5>
    <small class="text-muted">Total <?= count($list) ?> customer</small>
  </div>
</div>

<div class="panel">
  <div class="panel-body">

    <form method="get" class="filter-bar">
      <input type="text" name="q" class="form-control" placeholder="Cari nama / email / WA..."
             value="<?= e($q) ?>" style="min-width:280px">
      <button type="submit" class="btn btn-navy"><i class="fa-solid fa-search me-1"></i>Cari</button>
      <a href="<?= BASE_URL ?>admin/customer/index.php" class="btn btn-ghost">Reset</a>
    </form>

    <div class="table-responsive">
      <table class="table table-admin align-middle">
        <thead>
          <tr>
            <th>Customer</th>
            <th>Kontak</th>
            <th>Pengajuan</th>
            <th>Terdaftar</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($list): foreach ($list as $row): ?>
            <tr>
              <td>
                <div class="d-flex align-items-center gap-2">
                  <div class="avatar-mini" style="width:36px;height:36px;font-size:13px">
                    <?= e(inisial($row['nama'])) ?>
                  </div>
                  <div>
                    <strong style="font-size:13.5px"><?= e($row['nama']) ?></strong><br>
                    <small class="text-muted"><?= e($row['email']) ?></small>
                  </div>
                </div>
              </td>
              <td>
                <?php if ($row['no_whatsapp']): ?>
                  <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $row['no_whatsapp']) ?>"
                     target="_blank" class="text-success" style="font-size:12.5px">
                    <i class="fa-brands fa-whatsapp"></i> <?= e($row['no_whatsapp']) ?>
                  </a>
                <?php else: ?>
                  <small class="text-muted">-</small>
                <?php endif; ?>
              </td>
              <td>
                <div class="d-flex gap-1 flex-wrap">
                  <?php if ($row['total_td']): ?>
                    <span class="badge bg-info-subtle text-info-emphasis" style="font-size:11px">
                      TD: <?= $row['total_td'] ?>
                    </span>
                  <?php endif; ?>
                  <?php if ($row['total_jm']): ?>
                    <span class="badge bg-warning-subtle text-warning-emphasis" style="font-size:11px">
                      JM: <?= $row['total_jm'] ?>
                    </span>
                  <?php endif; ?>
                  <?php if ($row['total_tt']): ?>
                    <span class="badge bg-success-subtle text-success-emphasis" style="font-size:11px">
                      TT: <?= $row['total_tt'] ?>
                    </span>
                  <?php endif; ?>
                  <?php if (!$row['total_td'] && !$row['total_jm'] && !$row['total_tt']): ?>
                    <small class="text-muted">-</small>
                  <?php endif; ?>
                </div>
              </td>
              <td><small><?= tanggal_id($row['created_at']) ?></small></td>
              <td class="text-end">
                <a href="<?= BASE_URL ?>admin/customer/detail.php?id=<?= (int)$row['id'] ?>"
                   class="btn btn-sm btn-navy" title="Detail">
                  <i class="fa-solid fa-eye"></i>
                </a>
              </td>
            </tr>
          <?php endforeach; else: ?>
            <tr><td colspan="5" class="text-center py-5 text-muted">
              <i class="fa-solid fa-users d-block mb-2" style="font-size:32px;opacity:.4"></i>
              Belum ada customer terdaftar.
            </td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>