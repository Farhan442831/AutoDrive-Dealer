<?php
/**
 * Artikel - Hapus
 * Lokasi: admin/artikel/hapus.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('danger', 'ID tidak valid.');
    header('Location: ' . BASE_URL . 'admin/artikel/index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT thumbnail, judul FROM artikel WHERE id = :id");
$stmt->execute([':id' => $id]);
$artikel = $stmt->fetch();

if (!$artikel) {
    set_flash('danger', 'Artikel tidak ditemukan.');
    header('Location: ' . BASE_URL . 'admin/artikel/index.php');
    exit;
}

if ($artikel['thumbnail']) hapus_gambar($artikel['thumbnail'], 'artikel');
$pdo->prepare("DELETE FROM artikel WHERE id = :id")->execute([':id' => $id]);

set_flash('success', 'Artikel "' . $artikel['judul'] . '" berhasil dihapus.');
header('Location: ' . BASE_URL . 'admin/artikel/index.php');
exit;