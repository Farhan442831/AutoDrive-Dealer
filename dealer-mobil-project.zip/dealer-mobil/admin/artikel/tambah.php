<?php
/**
 * Artikel - Tambah
 * Lokasi: admin/artikel/tambah.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul    = trim($_POST['judul'] ?? '');
    $kategori = trim($_POST['kategori'] ?? 'Tips');
    $ringkasan= trim($_POST['ringkasan'] ?? '');
    $isi      = trim($_POST['isi'] ?? '');
    $penulis  = trim($_POST['penulis'] ?? 'Admin');
    $status   = $_POST['status'] ?? 'draft';
    $slug     = buat_slug($judul);

    if ($judul === '')  $errors[] = 'Judul wajib diisi.';
    if ($kategori === '') $errors[] = 'Kategori wajib diisi.';
    if ($isi === '') $errors[] = 'Isi artikel wajib diisi.';
    if (!in_array($status, ['publish','draft'], true)) $errors[] = 'Status tidak valid.';

    $cekslug = $pdo->prepare("SELECT id FROM artikel WHERE slug = :slug");
    $cekslug->execute([':slug' => $slug]);
    if ($cekslug->fetch()) $slug .= '-' . time();

    $thumbnail = null;
    if (!empty($_FILES['thumbnail']['name'])) {
        $up = upload_gambar($_FILES['thumbnail'], 'artikel');
        if ($up['sukses']) $thumbnail = $up['file'];
        elseif ($up['error']) $errors[] = 'Thumbnail: ' . $up['error'];
    }

    if (!$errors) {
        $stmt = $pdo->prepare("
            INSERT INTO artikel (judul, slug, kategori, thumbnail, ringkasan, isi, penulis, status)
            VALUES (:judul, :slug, :kategori, :thumb, :ringkasan, :isi, :penulis, :status)
        ");
        $stmt->execute([
            ':judul'      => $judul,
            ':slug'       => $slug,
            ':kategori'   => $kategori,
            ':thumb'      => $thumbnail,
            ':ringkasan'  => $ringkasan ?: null,
            ':isi'        => $isi,
            ':penulis'    => $penulis,
            ':status'     => $status,
        ]);
        set_flash('success', 'Artikel berhasil ditambahkan.');
        header('Location: ' . BASE_URL . 'admin/artikel/index.php');
        exit;
    }
}

$pageTitle = 'Tulis Artikel';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Tulis Artikel Baru</h5>
    <small class="text-muted">Bagikan informasi dan tips kepada pelanggan</small>
  </div>
  <a href="<?= BASE_URL ?>admin/artikel/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
  <div class="row g-4">
    <div class="col-lg-8">
      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-regular fa-newspaper text-orange me-2"></i>Konten Artikel</h5></div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Judul Artikel <span class="text-danger">*</span></label>
              <input type="text" name="judul" class="form-control" required
                     value="<?= e($_POST['judul'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Kategori <span class="text-danger">*</span></label>
              <input type="text" name="kategori" class="form-control" required
                     placeholder="Tips Membeli, Perawatan, dll."
                     value="<?= e($_POST['kategori'] ?? 'Tips') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Penulis</label>
              <input type="text" name="penulis" class="form-control"
                     value="<?= e($_POST['penulis'] ?? ($user['nama'] ?? 'Admin')) ?>">
            </div>
            <div class="col-12">
              <label class="form-label">Ringkasan (untuk preview)</label>
              <textarea name="ringkasan" class="form-control" rows="2"
                        placeholder="Ringkasan singkat artikel max 300 karakter"><?= e($_POST['ringkasan'] ?? '') ?></textarea>
            </div>
            <div class="col-12">
              <label class="form-label">Isi Artikel <span class="text-danger">*</span></label>
              <textarea name="isi" class="form-control" rows="14" required
                        placeholder="Tulis isi artikel di sini..."><?= e($_POST['isi'] ?? '') ?></textarea>
              <small class="form-text">Gunakan Enter dua kali untuk membuat paragraf baru.</small>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-image text-orange me-2"></i>Thumbnail</h5></div>
        <div class="panel-body">
          <input type="file" name="thumbnail" class="form-control" accept="image/*">
          <small class="form-text">JPG/PNG/WEBP max 2 MB. Rasio ideal 16:10.</small>
        </div>
      </div>

      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-gear text-orange me-2"></i>Publikasi</h5></div>
        <div class="panel-body">
          <label class="form-label">Status</label>
          <select name="status" class="form-select">
            <option value="draft"   <?= ($_POST['status'] ?? 'draft') === 'draft'   ? 'selected' : '' ?>>Draft (simpan dulu)</option>
            <option value="publish" <?= ($_POST['status'] ?? '') === 'publish' ? 'selected' : '' ?>>Publish (tampil)</option>
          </select>
        </div>
      </div>

      <div class="panel">
        <div class="panel-body d-grid gap-2">
          <button type="submit" class="btn btn-brand btn-lg">
            <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Artikel
          </button>
          <a href="<?= BASE_URL ?>admin/artikel/index.php" class="btn btn-ghost">Batal</a>
        </div>
      </div>
    </div>
  </div>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>