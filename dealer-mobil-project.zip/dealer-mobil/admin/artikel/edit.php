<?php
/**
 * Artikel - Edit
 * Lokasi: admin/artikel/edit.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('danger', 'ID tidak valid.');
    header('Location: ' . BASE_URL . 'admin/artikel/index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM artikel WHERE id = :id");
$stmt->execute([':id' => $id]);
$artikel = $stmt->fetch();
if (!$artikel) {
    set_flash('danger', 'Artikel tidak ditemukan.');
    header('Location: ' . BASE_URL . 'admin/artikel/index.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul    = trim($_POST['judul'] ?? '');
    $kategori = trim($_POST['kategori'] ?? '');
    $ringkasan= trim($_POST['ringkasan'] ?? '');
    $isi      = trim($_POST['isi'] ?? '');
    $penulis  = trim($_POST['penulis'] ?? 'Admin');
    $status   = $_POST['status'] ?? 'draft';

    if ($judul === '') $errors[] = 'Judul wajib diisi.';
    if ($kategori === '') $errors[] = 'Kategori wajib diisi.';
    if ($isi === '') $errors[] = 'Isi artikel wajib diisi.';

    $thumbnail = $artikel['thumbnail'];
    if (!empty($_FILES['thumbnail']['name'])) {
        $up = upload_gambar($_FILES['thumbnail'], 'artikel');
        if ($up['sukses']) {
            if ($artikel['thumbnail']) hapus_gambar($artikel['thumbnail'], 'artikel');
            $thumbnail = $up['file'];
        } elseif ($up['error']) {
            $errors[] = 'Thumbnail: ' . $up['error'];
        }
    }

    if (!$errors) {
        $upd = $pdo->prepare("
            UPDATE artikel SET judul=:judul, kategori=:kategori, thumbnail=:thumb,
                ringkasan=:ringkasan, isi=:isi, penulis=:penulis, status=:status
            WHERE id=:id
        ");
        $upd->execute([
            ':judul'     => $judul,
            ':kategori'  => $kategori,
            ':thumb'     => $thumbnail,
            ':ringkasan' => $ringkasan ?: null,
            ':isi'       => $isi,
            ':penulis'   => $penulis,
            ':status'    => $status,
            ':id'        => $id,
        ]);
        set_flash('success', 'Artikel berhasil diperbarui.');
        header('Location: ' . BASE_URL . 'admin/artikel/edit.php?id=' . $id);
        exit;
    }
}

$pageTitle = 'Edit Artikel';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Edit Artikel</h5>
    <small class="text-muted"><?= e($artikel['judul']) ?></small>
  </div>
  <a href="<?= BASE_URL ?>admin/artikel/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
  <div class="row g-4">
    <div class="col-lg-8">
      <div class="panel">
        <div class="panel-head"><h5><i class="fa-regular fa-newspaper text-orange me-2"></i>Konten Artikel</h5></div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Judul Artikel <span class="text-danger">*</span></label>
              <input type="text" name="judul" class="form-control" required value="<?= e($artikel['judul']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Kategori <span class="text-danger">*</span></label>
              <input type="text" name="kategori" class="form-control" required value="<?= e($artikel['kategori']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Penulis</label>
              <input type="text" name="penulis" class="form-control" value="<?= e($artikel['penulis']) ?>">
            </div>
            <div class="col-12">
              <label class="form-label">Ringkasan</label>
              <textarea name="ringkasan" class="form-control" rows="2"><?= e($artikel['ringkasan']) ?></textarea>
            </div>
            <div class="col-12">
              <label class="form-label">Isi Artikel <span class="text-danger">*</span></label>
              <textarea name="isi" class="form-control" rows="14" required><?= e($artikel['isi']) ?></textarea>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-image text-orange me-2"></i>Thumbnail</h5></div>
        <div class="panel-body">
          <img src="<?= img_aset($artikel['thumbnail'], 'artikel') ?>" class="img-fluid rounded mb-3"
               style="aspect-ratio:16/10;object-fit:cover">
          <input type="file" name="thumbnail" class="form-control" accept="image/*">
          <small class="form-text">Kosongkan jika tidak ingin mengganti.</small>
        </div>
      </div>

      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-gear text-orange me-2"></i>Publikasi</h5></div>
        <div class="panel-body">
          <label class="form-label">Status</label>
          <select name="status" class="form-select">
            <option value="draft"   <?= $artikel['status'] === 'draft'   ? 'selected' : '' ?>>Draft</option>
            <option value="publish" <?= $artikel['status'] === 'publish' ? 'selected' : '' ?>>Publish</option>
          </select>
          <div class="mt-3 text-muted" style="font-size:12.5px">
            <i class="fa-regular fa-eye me-1"></i><?= (int)$artikel['views'] ?>x dibaca
          </div>
        </div>
      </div>

      <div class="panel">
        <div class="panel-body d-grid gap-2">
          <button type="submit" class="btn btn-brand btn-lg">
            <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Perubahan
          </button>
          <a href="<?= BASE_URL ?>admin/artikel/index.php" class="btn btn-ghost">Batal</a>
        </div>
      </div>
    </div>
  </div>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>