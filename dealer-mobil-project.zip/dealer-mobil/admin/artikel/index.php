<?php
/**
 * Artikel - List
 * Lokasi: admin/artikel/index.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

if (isset($_GET['hapus'])) {
    $hid = (int)$_GET['hapus'];
    $stmt = $pdo->prepare("SELECT thumbnail FROM artikel WHERE id = :id");
    $stmt->execute([':id' => $hid]);
    $row = $stmt->fetch();
    if ($row && $row['thumbnail']) hapus_gambar($row['thumbnail'], 'artikel');

    $pdo->prepare("DELETE FROM artikel WHERE id = :id")->execute([':id' => $hid]);
    set_flash('success', 'Artikel berhasil dihapus.');
    header('Location: ' . BASE_URL . 'admin/artikel/index.php');
    exit;
}

$pageTitle = 'Artikel';
require_once __DIR__ . '/../includes/header.php';

$filterKat = trim($_GET['kategori'] ?? '');
$where = '';
$params = [];
if ($filterKat !== '') {
    $where = 'WHERE kategori = :kat';
    $params[':kat'] = $filterKat;
}

$stmt = $pdo->prepare("SELECT * FROM artikel $where ORDER BY created_at DESC");
$stmt->execute($params);
$list = $stmt->fetchAll();

$kategoriList = $pdo->query("SELECT DISTINCT kategori FROM artikel ORDER BY kategori")->fetchAll(PDO::FETCH_COLUMN);
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Manajemen Artikel</h5>
    <small class="text-muted">Total <?= count($list) ?> artikel</small>
  </div>
  <a href="<?= BASE_URL ?>admin/artikel/tambah.php" class="btn btn-brand">
    <i class="fa-solid fa-plus me-2"></i>Tulis Artikel
  </a>
</div>

<div class="panel">
  <div class="panel-body">

    <?php if ($kategoriList): ?>
      <form method="get" class="filter-bar">
        <select name="kategori" class="form-select">
          <option value="">Semua Kategori</option>
          <?php foreach ($kategoriList as $k): ?>
            <option value="<?= e($k) ?>" <?= $filterKat === $k ? 'selected' : '' ?>><?= e($k) ?></option>
          <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-navy"><i class="fa-solid fa-filter me-1"></i>Filter</button>
        <a href="<?= BASE_URL ?>admin/artikel/index.php" class="btn btn-ghost">Reset</a>
      </form>
    <?php endif; ?>

    <div class="table-responsive">
      <table class="table table-admin align-middle">
        <thead>
          <tr>
            <th>Thumbnail</th>
            <th>Judul</th>
            <th>Kategori</th>
            <th>Status</th>
            <th>Views</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($list): foreach ($list as $row): ?>
            <tr>
              <td>
                <img src="<?= img_aset($row['thumbnail'], 'artikel') ?>" class="thumb" alt="">
              </td>
              <td>
                <strong style="font-size:13.5px"><?= e($row['judul']) ?></strong><br>
                <small class="text-muted"><?= tanggal_id($row['created_at']) ?> · <?= e($row['penulis']) ?></small>
              </td>
              <td><small><?= e($row['kategori']) ?></small></td>
              <td>
                <?php if ($row['status'] === 'publish'): ?>
                  <span class="badge bg-success-subtle text-success-emphasis border border-success-subtle">Publish</span>
                <?php else: ?>
                  <span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle">Draft</span>
                <?php endif; ?>
              </td>
              <td><small><?= (int)$row['views'] ?>x</small></td>
              <td class="text-end">
                <div class="d-flex gap-1 justify-content-end">
                  <a href="<?= BASE_URL ?>detail_artikel.php?id=<?= (int)$row['id'] ?>" target="_blank"
                     class="btn btn-sm btn-ghost" title="Lihat">
                    <i class="fa-solid fa-eye"></i>
                  </a>
                  <a href="<?= BASE_URL ?>admin/artikel/edit.php?id=<?= (int)$row['id'] ?>"
                     class="btn btn-sm btn-navy" title="Edit">
                    <i class="fa-solid fa-pen"></i>
                  </a>
                  <a href="?hapus=<?= (int)$row['id'] ?>"
                     class="btn btn-sm btn-danger btn-konfirmasi-hapus"
                     data-msg="Hapus artikel '<?= e($row['judul']) ?>'?">
                    <i class="fa-solid fa-trash"></i>
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; else: ?>
            <tr><td colspan="6" class="text-center py-5 text-muted">
              <i class="fa-regular fa-newspaper d-block mb-2" style="font-size:32px;opacity:.4"></i>
              Belum ada artikel. <a href="<?= BASE_URL ?>admin/artikel/tambah.php">Tulis sekarang</a>
            </td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- MODAL HAPUS -->
<div class="modal fade" id="modalHapus" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Konfirmasi Hapus</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body"><p class="mb-0" id="msgHapus"></p></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-bs-dismiss="modal">Batal</button>
        <a href="#" id="linkHapus" class="btn btn-danger">Hapus</a>
      </div>
    </div>
  </div>
</div>

<script>
document.querySelectorAll('.btn-konfirmasi-hapus').forEach(function(el){
  el.addEventListener('click', function(e){
    e.preventDefault();
    document.getElementById('msgHapus').textContent = this.dataset.msg;
    document.getElementById('linkHapus').href = this.href;
    new bootstrap.Modal(document.getElementById('modalHapus')).show();
  });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>