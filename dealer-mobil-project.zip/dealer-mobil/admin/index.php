<?php
/**
 * Dashboard Admin
 * Lokasi: admin/index.php
 */
$pageTitle = 'Dashboard';
require_once __DIR__ . '/includes/header.php';

// Statistik
$totalMobil     = (int)$pdo->query("SELECT COUNT(*) FROM mobil")->fetchColumn();
$mobilReady     = (int)$pdo->query("SELECT COUNT(*) FROM mobil WHERE status='Ready'")->fetchColumn();
$mobilTerjual   = (int)$pdo->query("SELECT COUNT(*) FROM mobil WHERE status='Sold Out'")->fetchColumn();
$totalCustomer  = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='customer'")->fetchColumn();
$tdPending      = (int)$pdo->query("SELECT COUNT(*) FROM test_drive WHERE status='Pending'")->fetchColumn();
$jmPending      = (int)$pdo->query("SELECT COUNT(*) FROM jual_mobil WHERE status='Pending'")->fetchColumn();
$ttPending      = (int)$pdo->query("SELECT COUNT(*) FROM tukar_tambah WHERE status='Pending'")->fetchColumn();
$totalPromo     = (int)$pdo->query("SELECT COUNT(*) FROM promo WHERE status='aktif'")->fetchColumn();
$totalArtikel   = (int)$pdo->query("SELECT COUNT(*) FROM artikel WHERE status='publish'")->fetchColumn();

// Statistik mobil berdasarkan merek
$statMerek = $pdo->query("
    SELECT mk.nama_merek, COUNT(m.id) AS jumlah
    FROM merek mk
    LEFT JOIN mobil m ON m.merek_id = mk.id
    GROUP BY mk.id, mk.nama_merek
    ORDER BY jumlah DESC
")->fetchAll();

// Test drive terbaru
$tdTerbaru = $pdo->query("
    SELECT td.*, m.nama_mobil, mk.nama_merek
    FROM test_drive td
    LEFT JOIN mobil m ON m.id = td.mobil_id
    LEFT JOIN merek mk ON mk.id = m.merek_id
    ORDER BY td.created_at DESC LIMIT 5
")->fetchAll();

// Jual mobil terbaru
$jmTerbaru = $pdo->query("
    SELECT * FROM jual_mobil ORDER BY created_at DESC LIMIT 5
")->fetchAll();

// Total nilai stok
$totalNilaiStok = (int)$pdo->query("SELECT COALESCE(SUM(harga),0) FROM mobil WHERE status='Ready'")->fetchColumn();
?>

<!-- STAT CARDS -->
<div class="row g-3 mb-4">
  <div class="col-xl-3 col-lg-6 col-md-6">
    <div class="stat-card">
      <div class="stat-head">
        <div class="stat-icon navy"><i class="fa-solid fa-car"></i></div>
      </div>
      <div class="stat-label">Total Mobil</div>
      <div class="stat-value"><?= number_format($totalMobil) ?></div>
      <div class="stat-foot">Semua unit di database</div>
    </div>
  </div>

  <div class="col-xl-3 col-lg-6 col-md-6">
    <div class="stat-card">
      <div class="stat-head">
        <div class="stat-icon green"><i class="fa-solid fa-circle-check"></i></div>
      </div>
      <div class="stat-label">Mobil Ready</div>
      <div class="stat-value"><?= number_format($mobilReady) ?></div>
      <div class="stat-foot">Siap dijual</div>
    </div>
  </div>

  <div class="col-xl-3 col-lg-6 col-md-6">
    <div class="stat-card">
      <div class="stat-head">
        <div class="stat-icon orange"><i class="fa-solid fa-handshake"></i></div>
      </div>
      <div class="stat-label">Mobil Terjual</div>
      <div class="stat-value"><?= number_format($mobilTerjual) ?></div>
      <div class="stat-foot">Total unit terjual</div>
    </div>
  </div>

  <div class="col-xl-3 col-lg-6 col-md-6">
    <div class="stat-card">
      <div class="stat-head">
        <div class="stat-icon blue"><i class="fa-solid fa-users"></i></div>
      </div>
      <div class="stat-label">Total Customer</div>
      <div class="stat-value"><?= number_format($totalCustomer) ?></div>
      <div class="stat-foot">Customer terdaftar</div>
    </div>
  </div>

  <div class="col-xl-3 col-lg-6 col-md-6">
    <div class="stat-card">
      <div class="stat-head">
        <div class="stat-icon purple"><i class="fa-solid fa-car-side"></i></div>
      </div>
      <div class="stat-label">Test Drive Pending</div>
      <div class="stat-value"><?= number_format($tdPending) ?></div>
      <div class="stat-foot"><a href="<?= BASE_URL ?>admin/test-drive/index.php">Lihat pengajuan &rarr;</a></div>
    </div>
  </div>

  <div class="col-xl-3 col-lg-6 col-md-6">
    <div class="stat-card">
      <div class="stat-head">
        <div class="stat-icon teal"><i class="fa-solid fa-hand-holding-dollar"></i></div>
      </div>
      <div class="stat-label">Jual Mobil Pending</div>
      <div class="stat-value"><?= number_format($jmPending) ?></div>
      <div class="stat-foot"><a href="<?= BASE_URL ?>admin/jual-mobil/index.php">Lihat pengajuan &rarr;</a></div>
    </div>
  </div>

  <div class="col-xl-3 col-lg-6 col-md-6">
    <div class="stat-card">
      <div class="stat-head">
        <div class="stat-icon red"><i class="fa-solid fa-right-left"></i></div>
      </div>
      <div class="stat-label">Tukar Tambah Pending</div>
      <div class="stat-value"><?= number_format($ttPending) ?></div>
      <div class="stat-foot"><a href="<?= BASE_URL ?>admin/tukar-tambah/index.php">Lihat pengajuan &rarr;</a></div>
    </div>
  </div>

  <div class="col-xl-3 col-lg-6 col-md-6">
    <div class="stat-card">
      <div class="stat-head">
        <div class="stat-icon navy"><i class="fa-solid fa-sack-dollar"></i></div>
      </div>
      <div class="stat-label">Nilai Stok Ready</div>
      <div class="stat-value" style="font-size:18px"><?= rupiah($totalNilaiStok) ?></div>
      <div class="stat-foot">Estimasi total nilai</div>
    </div>
  </div>
</div>

<!-- CHART & STATISTIK -->
<div class="row g-4 mb-4">
  <div class="col-lg-8">
    <div class="panel">
      <div class="panel-head">
        <h5><i class="fa-solid fa-chart-column text-orange me-2"></i>Statistik Mobil per Merek</h5>
        <a href="<?= BASE_URL ?>admin/mobil/index.php" class="btn btn-sm btn-ghost">
          Kelola Mobil <i class="fa-solid fa-arrow-right ms-1"></i>
        </a>
      </div>
      <div class="panel-body">
        <?php
        $maxJumlah = !empty($statMerek) ? max(array_column($statMerek, 'jumlah')) : 1;
        if ($maxJumlah < 1) $maxJumlah = 1;
        foreach ($statMerek as $sm):
          $pct = ($sm['jumlah'] / $maxJumlah) * 100;
        ?>
          <div class="d-flex align-items-center gap-3 mb-3">
            <div style="width:100px;font-size:13.5px;font-weight:600;color:var(--ink-700)">
              <?= e($sm['nama_merek']) ?>
            </div>
            <div class="flex-grow-1" style="background:var(--bg-soft);height:22px;border-radius:8px;overflow:hidden">
              <div style="height:100%;width:<?= $pct ?>%;background:linear-gradient(90deg,#f97316,#fb923c);border-radius:8px;transition:width .8s ease"></div>
            </div>
            <div style="width:40px;text-align:right;font-weight:700;font-size:13.5px;color:var(--ink-900)">
              <?= (int)$sm['jumlah'] ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="panel h-100">
      <div class="panel-head">
        <h5><i class="fa-solid fa-tags text-orange me-2"></i>Ringkasan Konten</h5>
      </div>
      <div class="panel-body">
        <div class="d-flex justify-content-between align-items-center mb-3 pb-3" style="border-bottom:1px solid var(--line)">
          <div>
            <div style="font-size:13.5px;font-weight:600;color:var(--ink-900)">Promo Aktif</div>
            <small class="text-muted">Sedang berjalan</small>
          </div>
          <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle"
                style="font-size:14px;padding:.5em 1em"><?= $totalPromo ?></span>
        </div>
        <div class="d-flex justify-content-between align-items-center mb-3 pb-3" style="border-bottom:1px solid var(--line)">
          <div>
            <div style="font-size:13.5px;font-weight:600;color:var(--ink-900)">Artikel Publish</div>
            <small class="text-muted">Tampil di website</small>
          </div>
          <span class="badge bg-info-subtle text-info-emphasis border border-info-subtle"
                style="font-size:14px;padding:.5em 1em"><?= $totalArtikel ?></span>
        </div>
        <div class="d-flex flex-wrap gap-2 mt-3">
          <a href="<?= BASE_URL ?>admin/promo/index.php" class="btn btn-ghost btn-sm flex-grow-1">
            <i class="fa-solid fa-plus me-1"></i>Promo
          </a>
          <a href="<?= BASE_URL ?>admin/artikel/index.php" class="btn btn-ghost btn-sm flex-grow-1">
            <i class="fa-solid fa-plus me-1"></i>Artikel
          </a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- PENGAJUAN TERBARU -->
<div class="row g-4">
  <div class="col-lg-6">
    <div class="panel">
      <div class="panel-head">
        <h5><i class="fa-solid fa-car-side text-orange me-2"></i>Test Drive Terbaru</h5>
        <a href="<?= BASE_URL ?>admin/test-drive/index.php" class="btn btn-sm btn-ghost">Semua</a>
      </div>
      <div class="table-responsive">
        <table class="table table-admin">
          <thead>
            <tr><th>Nama</th><th>Mobil</th><th>Tanggal</th><th>Status</th></tr>
          </thead>
          <tbody>
            <?php if ($tdTerbaru): foreach ($tdTerbaru as $td): ?>
              <tr>
                <td>
                  <strong style="font-size:13px"><?= e($td['nama']) ?></strong><br>
                  <small class="text-muted"><?= e($td['whatsapp']) ?></small>
                </td>
                <td>
                  <?php if ($td['nama_mobil']): ?>
                    <small><?= e($td['nama_merek']) ?> <?= e($td['nama_mobil']) ?></small>
                  <?php else: ?>
                    <small class="text-muted">-</small>
                  <?php endif; ?>
                </td>
                <td><small><?= tanggal_id($td['tanggal']) ?></small></td>
                <td><span class="<?= badge_pengajuan($td['status']) ?>"><?= e($td['status']) ?></span></td>
              </tr>
            <?php endforeach; else: ?>
              <tr><td colspan="4" class="text-center text-muted py-4">Belum ada pengajuan test drive.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="panel">
      <div class="panel-head">
        <h5><i class="fa-solid fa-hand-holding-dollar text-orange me-2"></i>Jual Mobil Terbaru</h5>
        <a href="<?= BASE_URL ?>admin/jual-mobil/index.php" class="btn btn-sm btn-ghost">Semua</a>
      </div>
      <div class="table-responsive">
        <table class="table table-admin">
          <thead>
            <tr><th>Nama</th><th>Mobil</th><th>Harga Harapan</th><th>Status</th></tr>
          </thead>
          <tbody>
            <?php if ($jmTerbaru): foreach ($jmTerbaru as $jm): ?>
              <tr>
                <td>
                  <strong style="font-size:13px"><?= e($jm['nama']) ?></strong><br>
                  <small class="text-muted"><?= e($jm['whatsapp']) ?></small>
                </td>
                <td>
                  <small><?= e($jm['merek']) ?> <?= e($jm['model']) ?><br>
                  <span class="text-muted"><?= (int)$jm['tahun'] ?></span></small>
                </td>
                <td><small><?= rupiah($jm['harga_harapan']) ?></small></td>
                <td><span class="<?= badge_pengajuan($jm['status']) ?>"><?= e($jm['status']) ?></span></td>
              </tr>
            <?php endforeach; else: ?>
              <tr><td colspan="4" class="text-center text-muted py-4">Belum ada pengajuan jual mobil.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>