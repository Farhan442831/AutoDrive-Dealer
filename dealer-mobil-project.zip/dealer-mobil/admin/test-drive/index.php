<?php
/**
 * Test Drive - Kelola
 * Lokasi: admin/test-drive/index.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/wa_helper.php';

wajib_role(['admin', 'sales']);

// Proses update status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $tid    = (int)$_POST['id'];
    $status = $_POST['status'] ?? '';
    $valid  = ['Pending','Diproses','Disetujui','Selesai','Ditolak'];
    if ($tid > 0 && in_array($status, $valid, true)) {
        $pdo->prepare("UPDATE test_drive SET status = :s WHERE id = :id")
            ->execute([':s' => $status, ':id' => $tid]);
        set_flash('success', 'Status pengajuan berhasil diperbarui menjadi ' . $status . '.');
    }
    header('Location: ' . BASE_URL . 'admin/test-drive/index.php');
    exit;
}

// Proses hapus
if (isset($_GET['hapus'])) {
    $hid = (int)$_GET['hapus'];
    $pdo->prepare("DELETE FROM test_drive WHERE id = :id")->execute([':id' => $hid]);
    set_flash('success', 'Data pengajuan dihapus.');
    header('Location: ' . BASE_URL . 'admin/test-drive/index.php');
    exit;
}

$pageTitle = 'Test Drive';
require_once __DIR__ . '/../includes/header.php';

// Filter
$status = trim($_GET['status'] ?? '');
$where = '';
$params = [];
if (in_array($status, ['Pending','Diproses','Disetujui','Selesai','Ditolak'], true)) {
    $where = 'WHERE td.status = :s';
    $params[':s'] = $status;
}

$stmt = $pdo->prepare("
    SELECT td.*, m.nama_mobil, mk.nama_merek
    FROM test_drive td
    LEFT JOIN mobil m ON m.id = td.mobil_id
    LEFT JOIN merek mk ON mk.id = m.merek_id
    $where
    ORDER BY td.created_at DESC
");
$stmt->execute($params);
$list = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Pengajuan Test Drive</h5>
    <small class="text-muted">Total <?= count($list) ?> pengajuan</small>
  </div>
  <a href="<?= BASE_URL ?>test_drive.php" target="_blank" class="btn btn-ghost">
    <i class="fa-solid fa-external-link-alt me-1"></i>Lihat Form Customer
  </a>
</div>

<div class="panel">
  <div class="panel-body">

    <form method="get" class="filter-bar">
      <select name="status" class="form-select">
        <option value="">Semua Status</option>
        <?php foreach (['Pending','Diproses','Disetujui','Selesai','Ditolak'] as $s): ?>
          <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= $s ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn btn-navy"><i class="fa-solid fa-filter me-1"></i>Filter</button>
      <a href="<?= BASE_URL ?>admin/test-drive/index.php" class="btn btn-ghost">Reset</a>
    </form>

    <div class="table-responsive">
      <table class="table table-admin align-middle">
        <thead>
          <tr>
            <th>Nama</th>
            <th>WhatsApp</th>
            <th>Mobil</th>
            <th>Jadwal</th>
            <th>Status</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($list): foreach ($list as $row): ?>
            <tr>
              <td>
                <strong style="font-size:13.5px"><?= e($row['nama']) ?></strong><br>
                <small class="text-muted"><?= e($row['email'] ?: '-') ?></small>
              </td>
              <td>
                <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $row['whatsapp']) ?>"
                   target="_blank" class="text-success" style="font-size:13px">
                  <i class="fa-brands fa-whatsapp"></i> <?= e($row['whatsapp']) ?>
                </a>
              </td>
              <td>
                <?php if ($row['nama_mobil']): ?>
                  <small><?= e($row['nama_merek']) ?> <?= e($row['nama_mobil']) ?></small>
                <?php else: ?>
                  <small class="text-muted">-</small>
                <?php endif; ?>
              </td>
              <td>
                <small><strong><?= tanggal_id($row['tanggal']) ?></strong><br>
                <?= substr($row['jam'], 0, 5) ?> WIB</small>
              </td>
              <td>
                <?php
                $kelasStatus = match ($row['status']) {
                    'Pending'   => 'st-pending',
                    'Diproses'  => 'st-diproses',
                    'Disetujui' => 'st-disetujui',
                    'Selesai'   => 'st-selesai',
                    'Ditolak'   => 'st-ditolak',
                    default     => '',
                };
                ?>
                <form method="post" class="d-inline">
                  <input type="hidden" name="update_status" value="1">
                  <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                  <select name="status"
                          class="select-status <?= $kelasStatus ?>"
                          style="min-width:130px"
                          onchange="this.form.submit()">
                    <?php foreach (['Pending','Diproses','Disetujui','Selesai','Ditolak'] as $s): ?>
                      <option value="<?= $s ?>" <?= $row['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
                    <?php endforeach; ?>
                  </select>
                </form>
              </td>
              <td class="text-end">
                <div class="dropdown d-inline-block">
                  <button class="btn btn-sm btn-wa dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fa-brands fa-whatsapp"></i> Balas
                  </button>
                  <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                    <li><h6 class="dropdown-header">Kirim pesan status:</h6></li>
                    <?php foreach (['Pending','Diproses','Disetujui','Selesai','Ditolak'] as $s): ?>
                      <li>
                        <a class="dropdown-item" target="_blank"
                           href="<?= wa_link(wa_template_test_drive($row, $s), $row['whatsapp']) ?>">
                          <?= $s ?>
                        </a>
                      </li>
                    <?php endforeach; ?>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                      <a class="dropdown-item text-danger"
                         href="?hapus=<?= (int)$row['id'] ?>"
                         onclick="return confirm('Hapus pengajuan dari <?= e($row['nama']) ?>?')">
                        <i class="fa-solid fa-trash me-2"></i>Hapus Data
                      </a>
                    </li>
                  </ul>
                </div>
              </td>
            </tr>
          <?php endforeach; else: ?>
            <tr><td colspan="6" class="text-center py-5 text-muted">
              <i class="fa-solid fa-inbox d-block mb-2" style="font-size:32px;opacity:.4"></i>
              Belum ada pengajuan test drive.
            </td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>