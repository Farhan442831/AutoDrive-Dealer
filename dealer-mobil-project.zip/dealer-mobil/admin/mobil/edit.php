<?php
/**
 * Data Mobil - Edit
 * Lokasi: admin/mobil/edit.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('danger', 'ID mobil tidak valid.');
    header('Location: ' . BASE_URL . 'admin/mobil/index.php');
    exit;
}

// Ambil data mobil
$stmt = $pdo->prepare("SELECT * FROM mobil WHERE id = :id");
$stmt->execute([':id' => $id]);
$mobil = $stmt->fetch();

if (!$mobil) {
    set_flash('danger', 'Mobil tidak ditemukan.');
    header('Location: ' . BASE_URL . 'admin/mobil/index.php');
    exit;
}

$errors = [];

// ================= PROSES POST (SEBELUM HTML) =================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Hapus foto gallery yang dicentang
    $hapusGaleri = $_POST['hapus_galeri'] ?? [];
    if ($hapusGaleri) {
        foreach ($hapusGaleri as $gid) {
            $gid = (int)$gid;
            $stmtH = $pdo->prepare("SELECT foto FROM mobil_gallery WHERE id = :id AND mobil_id = :mid");
            $stmtH->execute([':id' => $gid, ':mid' => $id]);
            $row = $stmtH->fetch();
            if ($row) {
                hapus_gambar($row['foto'], 'mobil');
                $pdo->prepare("DELETE FROM mobil_gallery WHERE id = :id")->execute([':id' => $gid]);
            }
        }
        set_flash('success', 'Foto galeri terpilih telah dihapus.');
        header('Location: ' . BASE_URL . 'admin/mobil/edit.php?id=' . $id);
        exit;
    }

    $nama_mobil      = trim($_POST['nama_mobil'] ?? '');
    $merek_id        = (int)($_POST['merek_id'] ?? 0);
    $model           = trim($_POST['model'] ?? '');
    $tahun           = (int)($_POST['tahun'] ?? 0);
    $harga           = (int)str_replace(['.', ',', ' '], '', $_POST['harga'] ?? '0');
    $kilometer       = (int)str_replace(['.', ',', ' '], '', $_POST['kilometer'] ?? '0');
    $transmisi       = $_POST['transmisi'] ?? 'Manual';
    $bahan_bakar     = $_POST['bahan_bakar'] ?? 'Bensin';
    $warna           = trim($_POST['warna'] ?? '');
    $kapasitas_mesin = trim($_POST['kapasitas_mesin'] ?? '');
    $nomor_polisi    = trim($_POST['nomor_polisi'] ?? '');
    $lokasi          = trim($_POST['lokasi'] ?? '');
    $deskripsi       = trim($_POST['deskripsi'] ?? '');
    $status          = $_POST['status'] ?? 'Ready';
    $unggulan        = isset($_POST['unggulan']) ? 1 : 0;

    if ($nama_mobil === '')  $errors[] = 'Nama mobil wajib diisi.';
    if ($merek_id <= 0)      $errors[] = 'Pilih merek mobil.';
    if ($harga <= 0)         $errors[] = 'Harga wajib diisi.';

    // Upload foto utama baru (opsional)
    $fotoUtama = $mobil['foto_utama'];
    if (!empty($_FILES['foto_utama']['name'])) {
        $up = upload_gambar($_FILES['foto_utama'], 'mobil');
        if ($up['sukses']) {
            hapus_gambar($mobil['foto_utama'], 'mobil');
            $fotoUtama = $up['file'];
        } elseif ($up['error']) {
            $errors[] = 'Foto utama: ' . $up['error'];
        }
    }

    if (!$errors) {
        $upd = $pdo->prepare("
            UPDATE mobil SET
              merek_id = :merek_id, nama_mobil = :nama_mobil, model = :model,
              tahun = :tahun, harga = :harga, kilometer = :kilometer,
              transmisi = :transmisi, bahan_bakar = :bahan_bakar,
              warna = :warna, kapasitas_mesin = :kapasitas_mesin,
              nomor_polisi = :nomor_polisi, lokasi = :lokasi,
              foto_utama = :foto_utama, deskripsi = :deskripsi,
              status = :status, unggulan = :unggulan
            WHERE id = :id
        ");
        $upd->execute([
            ':merek_id'        => $merek_id,
            ':nama_mobil'      => $nama_mobil,
            ':model'           => $model,
            ':tahun'           => $tahun,
            ':harga'           => $harga,
            ':kilometer'       => $kilometer,
            ':transmisi'       => $transmisi,
            ':bahan_bakar'     => $bahan_bakar,
            ':warna'           => $warna ?: null,
            ':kapasitas_mesin' => $kapasitas_mesin ?: null,
            ':nomor_polisi'    => $nomor_polisi ?: null,
            ':lokasi'          => $lokasi ?: null,
            ':foto_utama'      => $fotoUtama,
            ':deskripsi'       => $deskripsi ?: null,
            ':status'          => $status,
            ':unggulan'        => $unggulan,
            ':id'              => $id,
        ]);

        // Upload gallery tambahan
        if (!empty($_FILES['gallery']['name'][0])) {
            $total = count($_FILES['gallery']['name']);
            for ($i = 0; $i < $total; $i++) {
                if ($_FILES['gallery']['error'][$i] !== UPLOAD_ERR_OK) continue;
                $single = [
                    'name'     => $_FILES['gallery']['name'][$i],
                    'type'     => $_FILES['gallery']['type'][$i],
                    'tmp_name' => $_FILES['gallery']['tmp_name'][$i],
                    'error'    => $_FILES['gallery']['error'][$i],
                    'size'     => $_FILES['gallery']['size'][$i],
                ];
                $up = upload_gambar($single, 'mobil');
                if ($up['sukses']) {
                    $pdo->prepare("INSERT INTO mobil_gallery (mobil_id, foto, urutan) VALUES (:id, :f, :u)")
                        ->execute([':id' => $id, ':f' => $up['file'], ':u' => 100 + $i]);
                }
            }
        }

        set_flash('success', 'Data mobil berhasil diperbarui.');
        header('Location: ' . BASE_URL . 'admin/mobil/edit.php?id=' . $id);
        exit;
    }
}
// ================= END PROSES POST =================

// Refresh data mobil & gallery setelah POST/redirect selesai
$stmt = $pdo->prepare("SELECT * FROM mobil WHERE id = :id");
$stmt->execute([':id' => $id]);
$mobil = $stmt->fetch();

$stmtG = $pdo->prepare("SELECT * FROM mobil_gallery WHERE mobil_id = :id ORDER BY urutan ASC");
$stmtG->execute([':id' => $id]);
$gallery = $stmtG->fetchAll();

$merekList = $pdo->query("SELECT * FROM merek ORDER BY nama_merek")->fetchAll();

$pageTitle = 'Edit Mobil';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Edit Mobil</h5>
    <small class="text-muted"><?= e($mobil['nama_mobil']) ?></small>
  </div>
  <a href="<?= BASE_URL ?>admin/mobil/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
  <div class="row g-4">
    <div class="col-lg-8">
      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-car text-orange me-2"></i>Informasi Mobil</h5></div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Nama Mobil <span class="text-danger">*</span></label>
              <input type="text" name="nama_mobil" class="form-control" required
                     value="<?= e($mobil['nama_mobil']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Merek <span class="text-danger">*</span></label>
              <select name="merek_id" class="form-select" required>
                <?php foreach ($merekList as $mk): ?>
                  <option value="<?= (int)$mk['id'] ?>" <?= (int)$mobil['merek_id'] === (int)$mk['id'] ? 'selected' : '' ?>>
                    <?= e($mk['nama_merek']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Model</label>
              <input type="text" name="model" class="form-control"
                     value="<?= e($mobil['model']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Tahun <span class="text-danger">*</span></label>
              <input type="number" name="tahun" class="form-control" required
                     min="1990" max="<?= date('Y') + 1 ?>"
                     value="<?= (int)$mobil['tahun'] ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Harga (Rp) <span class="text-danger">*</span></label>
              <input type="number" name="harga" class="form-control" required min="0" step="1000000"
                     value="<?= (int)$mobil['harga'] ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Kilometer</label>
              <input type="number" name="kilometer" class="form-control" min="0"
                     value="<?= (int)$mobil['kilometer'] ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Transmisi</label>
              <select name="transmisi" class="form-select">
                <option value="Manual"    <?= $mobil['transmisi'] === 'Manual' ? 'selected' : '' ?>>Manual</option>
                <option value="Automatic" <?= $mobil['transmisi'] === 'Automatic' ? 'selected' : '' ?>>Automatic</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Bahan Bakar</label>
              <select name="bahan_bakar" class="form-select">
                <?php foreach (['Bensin','Diesel','Hybrid','Listrik'] as $bb): ?>
                  <option value="<?= $bb ?>" <?= $mobil['bahan_bakar'] === $bb ? 'selected' : '' ?>><?= $bb ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Warna</label>
              <input type="text" name="warna" class="form-control" value="<?= e($mobil['warna']) ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label">Kapasitas Mesin</label>
              <input type="text" name="kapasitas_mesin" class="form-control" value="<?= e($mobil['kapasitas_mesin']) ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label">Nomor Polisi</label>
              <input type="text" name="nomor_polisi" class="form-control" value="<?= e($mobil['nomor_polisi']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Lokasi</label>
              <input type="text" name="lokasi" class="form-control" value="<?= e($mobil['lokasi']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Status</label>
              <select name="status" class="form-select">
                <?php foreach (['Ready','Booked','Sold Out'] as $st): ?>
                  <option value="<?= $st ?>" <?= $mobil['status'] === $st ? 'selected' : '' ?>><?= $st ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-12">
              <label class="form-label">Deskripsi</label>
              <textarea name="deskripsi" class="form-control" rows="5"><?= e($mobil['deskripsi']) ?></textarea>
            </div>
            <div class="col-12">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="unggulan" id="unggulan" value="1"
                       <?= $mobil['unggulan'] ? 'checked' : '' ?>>
                <label class="form-check-label" for="unggulan">
                  Tandai sebagai <strong>Mobil Unggulan</strong>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-image text-orange me-2"></i>Foto Utama</h5></div>
        <div class="panel-body">
          <img src="<?= img_mobil($mobil['foto_utama']) ?>" class="img-fluid rounded mb-3"
               style="aspect-ratio:16/11;object-fit:cover">
          <label class="form-label">Ganti Foto Utama (opsional)</label>
          <input type="file" name="foto_utama" class="form-control" accept="image/*">
          <small class="form-text">Biarkan kosong jika tidak ingin mengganti.</small>
        </div>
      </div>

      <?php if ($gallery): ?>
      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-images text-orange me-2"></i>Galeri Foto</h5></div>
        <div class="panel-body">
          <div class="row g-2">
            <?php foreach ($gallery as $g): ?>
              <div class="col-6">
                <div class="galeri-item">
                  <img src="<?= img_mobil($g['foto']) ?>" alt="Foto">
                  <label class="galeri-check">
                    <input type="checkbox" name="hapus_galeri[]" value="<?= (int)$g['id'] ?>">
                    <span>Hapus</span>
                  </label>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
          <small class="form-text d-block mt-2">
            Centang foto lalu klik <strong>Simpan</strong> untuk menghapus.
          </small>
        </div>
      </div>
      <?php endif; ?>

      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-plus text-orange me-2"></i>Tambah Galeri</h5></div>
        <div class="panel-body">
          <input type="file" name="gallery[]" class="form-control" accept="image/*" multiple>
          <small class="form-text">Bisa pilih banyak foto sekaligus.</small>
        </div>
      </div>

      <div class="panel">
        <div class="panel-body d-grid gap-2">
          <button type="submit" class="btn btn-brand btn-lg">
            <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Perubahan
          </button>
          <a href="<?= BASE_URL ?>admin/mobil/index.php" class="btn btn-ghost">Batal</a>
        </div>
      </div>
    </div>
  </div>
</form>

<style>
.galeri-item{ position:relative; border-radius:10px; overflow:hidden; border:1px solid var(--line); }
.galeri-item img{ width:100%; aspect-ratio:4/3; object-fit:cover; display:block; }
.galeri-check{ position:absolute; top:6px; right:6px; background:rgba(255,255,255,.92);
  padding:3px 8px; border-radius:6px; font-size:11.5px; display:flex; gap:5px; align-items:center; cursor:pointer; }
.galeri-check input{ margin:0; }
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>