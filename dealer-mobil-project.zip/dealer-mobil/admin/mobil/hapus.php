<?php
/**
 * Data Mobil - Hapus
 * Lokasi: admin/mobil/hapus.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin']); // hanya admin

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('danger', 'ID mobil tidak valid.');
    header('Location: ' . BASE_URL . 'admin/mobil/index.php');
    exit;
}

// Ambil mobil
$stmt = $pdo->prepare("SELECT foto_utama, nama_mobil FROM mobil WHERE id = :id");
$stmt->execute([':id' => $id]);
$mobil = $stmt->fetch();

if (!$mobil) {
    set_flash('danger', 'Mobil tidak ditemukan.');
    header('Location: ' . BASE_URL . 'admin/mobil/index.php');
    exit;
}

// Hapus foto gallery dari disk
$stmtG = $pdo->prepare("SELECT foto FROM mobil_gallery WHERE mobil_id = :id");
$stmtG->execute([':id' => $id]);
foreach ($stmtG->fetchAll() as $g) {
    hapus_gambar($g['foto'], 'mobil');
}

// Hapus foto utama
hapus_gambar($mobil['foto_utama'], 'mobil');

// Hapus data mobil (foreign key otomatis hapus gallery & inspeksi)
$pdo->prepare("DELETE FROM mobil WHERE id = :id")->execute([':id' => $id]);

set_flash('success', 'Mobil "' . $mobil['nama_mobil'] . '" berhasil dihapus.');
header('Location: ' . BASE_URL . 'admin/mobil/index.php');
exit;