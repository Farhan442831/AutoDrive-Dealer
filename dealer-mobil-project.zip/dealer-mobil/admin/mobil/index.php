<?php
/**
 * Data Mobil - List
 * Lokasi: admin/mobil/index.php
 */
$pageTitle = 'Data Mobil';
require_once __DIR__ . '/../includes/header.php';

// Filter
$q         = trim($_GET['q'] ?? '');
$merek_id  = trim($_GET['merek_id'] ?? '');
$status    = trim($_GET['status'] ?? '');

$where = [];
$params = [];
if ($q !== '') {
    $where[] = '(m.nama_mobil LIKE :q OR m.model LIKE :q)';
    $params[':q'] = '%' . $q . '%';
}
if ($merek_id !== '' && ctype_digit($merek_id)) {
    $where[] = 'm.merek_id = :merek_id';
    $params[':merek_id'] = (int)$merek_id;
}
if (in_array($status, ['Ready','Booked','Sold Out'], true)) {
    $where[] = 'm.status = :status';
    $params[':status'] = $status;
}

$sql = "SELECT m.*, mk.nama_merek FROM mobil m
        JOIN merek mk ON mk.id = m.merek_id"
     . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
     . " ORDER BY m.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$mobilList = $stmt->fetchAll();

$merekList = $pdo->query("SELECT * FROM merek ORDER BY nama_merek")->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Manajemen Data Mobil</h5>
    <small class="text-muted">Total <?= count($mobilList) ?> unit ditemukan</small>
  </div>
  <a href="<?= BASE_URL ?>admin/mobil/tambah.php" class="btn btn-brand">
    <i class="fa-solid fa-plus me-2"></i>Tambah Mobil
  </a>
</div>

<div class="panel">
  <div class="panel-body">

    <!-- FILTER -->
    <form method="get" class="filter-bar">
      <input type="text" name="q" class="form-control" placeholder="Cari nama mobil / model..."
             value="<?= e($q) ?>">
      <select name="merek_id" class="form-select">
        <option value="">Semua Merek</option>
        <?php foreach ($merekList as $mk): ?>
          <option value="<?= (int)$mk['id'] ?>" <?= $merek_id == $mk['id'] ? 'selected' : '' ?>>
            <?= e($mk['nama_merek']) ?>
          </option>
        <?php endforeach; ?>
      </select>
      <select name="status" class="form-select">
        <option value="">Semua Status</option>
        <?php foreach (['Ready','Booked','Sold Out'] as $st): ?>
          <option value="<?= $st ?>" <?= $status === $st ? 'selected' : '' ?>><?= $st ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn btn-navy"><i class="fa-solid fa-filter me-1"></i>Filter</button>
      <a href="<?= BASE_URL ?>admin/mobil/index.php" class="btn btn-ghost">Reset</a>
    </form>

    <!-- TABEL -->
    <div class="table-responsive">
      <table class="table table-admin align-middle">
        <thead>
          <tr>
            <th>Foto</th>
            <th>Nama Mobil</th>
            <th>Merek</th>
            <th>Tahun</th>
            <th>Harga</th>
            <th>KM</th>
            <th>Status</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($mobilList): foreach ($mobilList as $m): ?>
            <tr>
              <td>
                <img src="<?= img_mobil($m['foto_utama']) ?>" class="thumb"
                     alt="<?= e($m['nama_mobil']) ?>">
              </td>
              <td>
                <strong style="font-size:13.5px"><?= e($m['nama_mobil']) ?></strong><br>
                <small class="text-muted"><?= e($m['model']) ?>
                  <?= $m['unggulan'] ? ' · <i class="fa-solid fa-star text-warning"></i>' : '' ?>
                </small>
              </td>
              <td><small><?= e($m['nama_merek']) ?></small></td>
              <td><small><?= (int)$m['tahun'] ?></small></td>
              <td><small><strong><?= rupiah($m['harga']) ?></strong></small></td>
              <td><small><?= km($m['kilometer']) ?></small></td>
              <td><span class="<?= badge_mobil($m['status']) ?>"><?= e($m['status']) ?></span></td>
              <td class="text-end">
                <div class="d-flex gap-1 justify-content-end">
                  <a href="<?= BASE_URL ?>detail_mobil.php?id=<?= (int)$m['id'] ?>"
                     target="_blank" class="btn btn-sm btn-ghost" title="Lihat">
                    <i class="fa-solid fa-eye"></i>
                  </a>
                  <a href="<?= BASE_URL ?>admin/mobil/edit.php?id=<?= (int)$m['id'] ?>"
                     class="btn btn-sm btn-navy" title="Edit">
                    <i class="fa-solid fa-pen"></i>
                  </a>
                  <a href="<?= BASE_URL ?>admin/mobil/hapus.php?id=<?= (int)$m['id'] ?>"
                     class="btn btn-sm btn-danger btn-hapus" title="Hapus"
                     data-nama="<?= e($m['nama_mobil']) ?>">
                    <i class="fa-solid fa-trash"></i>
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; else: ?>
            <tr>
              <td colspan="8" class="text-center py-5 text-muted">
                <i class="fa-solid fa-car-burst mb-2" style="font-size:32px;display:block;opacity:.4"></i>
                Belum ada data mobil. <a href="<?= BASE_URL ?>admin/mobil/tambah.php">Tambah sekarang</a>
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

  </div>
</div>

<!-- Modal Konfirmasi Hapus -->
<div class="modal fade" id="modalHapus" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Konfirmasi Hapus</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p class="mb-0">Yakin ingin menghapus mobil <strong id="namaHapus"></strong>?
        Tindakan ini tidak dapat dibatalkan.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-bs-dismiss="modal">Batal</button>
        <a href="#" id="linkHapus" class="btn btn-danger">
          <i class="fa-solid fa-trash me-1"></i>Hapus
        </a>
      </div>
    </div>
  </div>
</div>

<script>
document.querySelectorAll('.btn-hapus').forEach(function(el){
  el.addEventListener('click', function(e){
    e.preventDefault();
    document.getElementById('namaHapus').textContent = this.dataset.nama;
    document.getElementById('linkHapus').href = this.href;
    new bootstrap.Modal(document.getElementById('modalHapus')).show();
  });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>