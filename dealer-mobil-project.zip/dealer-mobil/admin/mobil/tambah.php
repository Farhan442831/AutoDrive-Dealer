<?php
/**
 * Data Mobil - Tambah
 * Lokasi: admin/mobil/tambah.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

$errors = [];

// ================= PROSES POST (SEBELUM HTML) =================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_mobil      = trim($_POST['nama_mobil'] ?? '');
    $merek_id        = (int)($_POST['merek_id'] ?? 0);
    $model           = trim($_POST['model'] ?? '');
    $tahun           = (int)($_POST['tahun'] ?? 0);
    $harga           = (int)str_replace(['.', ',', ' '], '', $_POST['harga'] ?? '0');
    $kilometer       = (int)str_replace(['.', ',', ' '], '', $_POST['kilometer'] ?? '0');
    $transmisi       = $_POST['transmisi'] ?? 'Manual';
    $bahan_bakar     = $_POST['bahan_bakar'] ?? 'Bensin';
    $warna           = trim($_POST['warna'] ?? '');
    $kapasitas_mesin = trim($_POST['kapasitas_mesin'] ?? '');
    $nomor_polisi    = trim($_POST['nomor_polisi'] ?? '');
    $lokasi          = trim($_POST['lokasi'] ?? '');
    $deskripsi       = trim($_POST['deskripsi'] ?? '');
    $status          = $_POST['status'] ?? 'Ready';
    $unggulan        = isset($_POST['unggulan']) ? 1 : 0;

    if ($nama_mobil === '')                     $errors[] = 'Nama mobil wajib diisi.';
    if ($merek_id <= 0)                          $errors[] = 'Pilih merek mobil.';
    if ($tahun < 1990 || $tahun > (int)date('Y') + 1) $errors[] = 'Tahun tidak valid.';
    if ($harga <= 0)                             $errors[] = 'Harga wajib diisi.';
    if (!in_array($transmisi, ['Manual','Automatic'], true))     $errors[] = 'Transmisi tidak valid.';
    if (!in_array($bahan_bakar, ['Bensin','Diesel','Hybrid','Listrik'], true)) $errors[] = 'Bahan bakar tidak valid.';
    if (!in_array($status, ['Ready','Booked','Sold Out'], true)) $errors[] = 'Status tidak valid.';

    // Upload foto utama
    $fotoUtama = null;
    if (!empty($_FILES['foto_utama']['name'])) {
        $up = upload_gambar($_FILES['foto_utama'], 'mobil');
        if ($up['sukses']) {
            $fotoUtama = $up['file'];
        } elseif ($up['error']) {
            $errors[] = 'Foto utama: ' . $up['error'];
        }
    }

    if (!$errors) {
        $stmt = $pdo->prepare("
            INSERT INTO mobil
            (merek_id, nama_mobil, model, tahun, harga, kilometer, transmisi, bahan_bakar,
             warna, kapasitas_mesin, nomor_polisi, lokasi, foto_utama, deskripsi, status, unggulan)
            VALUES
            (:merek_id, :nama_mobil, :model, :tahun, :harga, :kilometer, :transmisi, :bahan_bakar,
             :warna, :kapasitas_mesin, :nomor_polisi, :lokasi, :foto_utama, :deskripsi, :status, :unggulan)
        ");
        $stmt->execute([
            ':merek_id'        => $merek_id,
            ':nama_mobil'      => $nama_mobil,
            ':model'           => $model,
            ':tahun'           => $tahun,
            ':harga'           => $harga,
            ':kilometer'       => $kilometer,
            ':transmisi'       => $transmisi,
            ':bahan_bakar'     => $bahan_bakar,
            ':warna'           => $warna ?: null,
            ':kapasitas_mesin' => $kapasitas_mesin ?: null,
            ':nomor_polisi'    => $nomor_polisi ?: null,
            ':lokasi'          => $lokasi ?: null,
            ':foto_utama'      => $fotoUtama,
            ':deskripsi'       => $deskripsi ?: null,
            ':status'          => $status,
            ':unggulan'        => $unggulan,
        ]);

        $mobilId = (int)$pdo->lastInsertId();

        // Upload gallery (multiple)
        if (!empty($_FILES['gallery']['name'][0])) {
            $total = count($_FILES['gallery']['name']);
            for ($i = 0; $i < $total; $i++) {
                if ($_FILES['gallery']['error'][$i] !== UPLOAD_ERR_OK) continue;
                $single = [
                    'name'     => $_FILES['gallery']['name'][$i],
                    'type'     => $_FILES['gallery']['type'][$i],
                    'tmp_name' => $_FILES['gallery']['tmp_name'][$i],
                    'error'    => $_FILES['gallery']['error'][$i],
                    'size'     => $_FILES['gallery']['size'][$i],
                ];
                $up = upload_gambar($single, 'mobil');
                if ($up['sukses']) {
                    $pdo->prepare("INSERT INTO mobil_gallery (mobil_id, foto, urutan) VALUES (:id, :foto, :ur)")
                        ->execute([':id' => $mobilId, ':foto' => $up['file'], ':ur' => $i]);
                }
            }
        }

        set_flash('success', 'Mobil berhasil ditambahkan.');
        header('Location: ' . BASE_URL . 'admin/mobil/index.php');
        exit;
    }
}
// ================= END PROSES POST =================

// Baru include header setelah logika selesai
$pageTitle = 'Tambah Mobil';
require_once __DIR__ . '/../includes/header.php';

$merekList = $pdo->query("SELECT * FROM merek ORDER BY nama_merek")->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Tambah Mobil Baru</h5>
    <small class="text-muted">Isi data mobil dengan lengkap dan benar</small>
  </div>
  <a href="<?= BASE_URL ?>admin/mobil/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <strong><i class="fa-solid fa-circle-exclamation me-2"></i>Periksa kembali data Anda:</strong>
    <ul class="mb-0 mt-2 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
  <div class="row g-4">

    <div class="col-lg-8">
      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-car text-orange me-2"></i>Informasi Mobil</h5></div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Nama Mobil <span class="text-danger">*</span></label>
              <input type="text" name="nama_mobil" class="form-control" required
                     placeholder="Contoh: Toyota Avanza 1.3 G CVT"
                     value="<?= e($_POST['nama_mobil'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Merek <span class="text-danger">*</span></label>
              <select name="merek_id" class="form-select" required>
                <option value="">-- Pilih merek --</option>
                <?php foreach ($merekList as $mk): ?>
                  <option value="<?= (int)$mk['id'] ?>"
                    <?= (int)($_POST['merek_id'] ?? 0) === (int)$mk['id'] ? 'selected' : '' ?>>
                    <?= e($mk['nama_merek']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Model</label>
              <input type="text" name="model" class="form-control"
                     placeholder="Contoh: Avanza"
                     value="<?= e($_POST['model'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Tahun <span class="text-danger">*</span></label>
              <input type="number" name="tahun" class="form-control" required
                     min="1990" max="<?= date('Y') + 1 ?>"
                     value="<?= e($_POST['tahun'] ?? date('Y')) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Harga (Rp) <span class="text-danger">*</span></label>
              <input type="number" name="harga" class="form-control" required min="0" step="1000000"
                     placeholder="185000000"
                     value="<?= e($_POST['harga'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Kilometer</label>
              <input type="number" name="kilometer" class="form-control" min="0"
                     placeholder="45000"
                     value="<?= e($_POST['kilometer'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Transmisi <span class="text-danger">*</span></label>
              <select name="transmisi" class="form-select" required>
                <option value="Manual"    <?= ($_POST['transmisi'] ?? '') === 'Manual'    ? 'selected' : '' ?>>Manual</option>
                <option value="Automatic" <?= ($_POST['transmisi'] ?? '') === 'Automatic' ? 'selected' : '' ?>>Automatic</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Bahan Bakar <span class="text-danger">*</span></label>
              <select name="bahan_bakar" class="form-select" required>
                <?php foreach (['Bensin','Diesel','Hybrid','Listrik'] as $bb): ?>
                  <option value="<?= $bb ?>" <?= ($_POST['bahan_bakar'] ?? '') === $bb ? 'selected' : '' ?>><?= $bb ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Warna</label>
              <input type="text" name="warna" class="form-control"
                     value="<?= e($_POST['warna'] ?? '') ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label">Kapasitas Mesin</label>
              <input type="text" name="kapasitas_mesin" class="form-control"
                     placeholder="1.5L"
                     value="<?= e($_POST['kapasitas_mesin'] ?? '') ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label">Nomor Polisi</label>
              <input type="text" name="nomor_polisi" class="form-control"
                     placeholder="B 1234 ABC"
                     value="<?= e($_POST['nomor_polisi'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Lokasi</label>
              <input type="text" name="lokasi" class="form-control"
                     placeholder="Jakarta Selatan"
                     value="<?= e($_POST['lokasi'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Status <span class="text-danger">*</span></label>
              <select name="status" class="form-select" required>
                <?php foreach (['Ready','Booked','Sold Out'] as $st): ?>
                  <option value="<?= $st ?>" <?= ($_POST['status'] ?? '') === $st ? 'selected' : '' ?>><?= $st ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-12">
              <label class="form-label">Deskripsi Kendaraan</label>
              <textarea name="deskripsi" class="form-control" rows="5"
                        placeholder="Ceritakan kondisi mobil, riwayat servis, dll."><?= e($_POST['deskripsi'] ?? '') ?></textarea>
            </div>
            <div class="col-12">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="unggulan" id="unggulan" value="1"
                       <?= !empty($_POST['unggulan']) ? 'checked' : '' ?>>
                <label class="form-check-label" for="unggulan">
                  Tandai sebagai <strong>Mobil Unggulan</strong> (tampil di homepage)
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-image text-orange me-2"></i>Foto Mobil</h5></div>
        <div class="panel-body">
          <label class="form-label">Foto Utama</label>
          <input type="file" name="foto_utama" class="form-control" accept="image/*">
          <small class="form-text">JPG/PNG/WEBP max 2 MB. Rasio ideal 16:11.</small>

          <div class="divider my-3"></div>

          <label class="form-label">Foto Galeri (bisa pilih banyak)</label>
          <input type="file" name="gallery[]" class="form-control" accept="image/*" multiple>
          <small class="form-text">Pilih beberapa foto sekaligus (tahan Ctrl). Maks 2 MB per foto.</small>
        </div>
      </div>

      <div class="panel">
        <div class="panel-body d-grid gap-2">
          <button type="submit" class="btn btn-brand btn-lg">
            <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Data Mobil
          </button>
          <a href="<?= BASE_URL ?>admin/mobil/index.php" class="btn btn-ghost">Batal</a>
        </div>
      </div>
    </div>

  </div>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>