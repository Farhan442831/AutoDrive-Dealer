<?php
/**
 * User & Role - List
 * Lokasi: admin/users/index.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin']); // KHUSUS ADMIN

if (isset($_GET['hapus'])) {
    $hid = (int)$_GET['hapus'];
    if ($hid === (int)user_login()['id']) {
        set_flash('danger', 'Anda tidak dapat menghapus akun sendiri.');
    } else {
        $pdo->prepare("DELETE FROM users WHERE id = :id")->execute([':id' => $hid]);
        set_flash('success', 'User berhasil dihapus.');
    }
    header('Location: ' . BASE_URL . 'admin/users/index.php');
    exit;
}

$pageTitle = 'User & Role';
require_once __DIR__ . '/../includes/header.php';

$filterRole = trim($_GET['role'] ?? '');
$where = '';
$params = [];
if (in_array($filterRole, ['admin','sales','customer'], true)) {
    $where = 'WHERE role = :role';
    $params[':role'] = $filterRole;
}

$stmt = $pdo->prepare("SELECT * FROM users $where ORDER BY role, nama");
$stmt->execute($params);
$list = $stmt->fetchAll();

$totalAdmin    = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
$totalSales    = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='sales'")->fetchColumn();
$totalCustomer = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='customer'")->fetchColumn();
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">User &amp; Role</h5>
    <small class="text-muted">Total <?= count($list) ?> user</small>
  </div>
  <a href="<?= BASE_URL ?>admin/users/tambah.php" class="btn btn-brand">
    <i class="fa-solid fa-plus me-2"></i>Tambah User
  </a>
</div>

<div class="row g-3 mb-4">
  <div class="col-md-4">
    <div class="stat-card">
      <div class="stat-head">
        <div class="stat-icon navy"><i class="fa-solid fa-user-shield"></i></div>
      </div>
      <div class="stat-label">Total Admin</div>
      <div class="stat-value"><?= $totalAdmin ?></div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="stat-card">
      <div class="stat-head">
        <div class="stat-icon orange"><i class="fa-solid fa-user-tie"></i></div>
      </div>
      <div class="stat-label">Total Sales</div>
      <div class="stat-value"><?= $totalSales ?></div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="stat-card">
      <div class="stat-head">
        <div class="stat-icon blue"><i class="fa-solid fa-users"></i></div>
      </div>
      <div class="stat-label">Total Customer</div>
      <div class="stat-value"><?= $totalCustomer ?></div>
    </div>
  </div>
</div>

<div class="panel">
  <div class="panel-body">

    <form method="get" class="filter-bar">
      <select name="role" class="form-select">
        <option value="">Semua Role</option>
        <option value="admin"    <?= $filterRole === 'admin'    ? 'selected' : '' ?>>Admin</option>
        <option value="sales"    <?= $filterRole === 'sales'    ? 'selected' : '' ?>>Sales</option>
        <option value="customer" <?= $filterRole === 'customer' ? 'selected' : '' ?>>Customer</option>
      </select>
      <button type="submit" class="btn btn-navy"><i class="fa-solid fa-filter me-1"></i>Filter</button>
      <a href="<?= BASE_URL ?>admin/users/index.php" class="btn btn-ghost">Reset</a>
    </form>

    <div class="table-responsive">
      <table class="table table-admin align-middle">
        <thead>
          <tr>
            <th>User</th>
            <th>WhatsApp</th>
            <th>Role</th>
            <th>Status</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($list): foreach ($list as $row):
            $badgeRole = match($row['role']) {
              'admin'  => 'bg-danger-subtle text-danger-emphasis border border-danger-subtle',
              'sales'  => 'bg-warning-subtle text-warning-emphasis border border-warning-subtle',
              default  => 'bg-primary-subtle text-primary-emphasis border border-primary-subtle',
            };
          ?>
            <tr>
              <td>
                <div class="d-flex align-items-center gap-2">
                  <div class="avatar-mini" style="width:36px;height:36px;font-size:13px">
                    <?= e(inisial($row['nama'])) ?>
                  </div>
                  <div>
                    <strong style="font-size:13.5px"><?= e($row['nama']) ?></strong><br>
                    <small class="text-muted"><?= e($row['email']) ?></small>
                  </div>
                </div>
              </td>
              <td><small><?= e($row['no_whatsapp'] ?: '-') ?></small></td>
              <td>
                <span class="badge <?= $badgeRole ?>" style="text-transform:capitalize">
                  <?= e($row['role']) ?>
                </span>
              </td>
              <td>
                <?php if ($row['status'] === 'aktif'): ?>
                  <span class="badge bg-success-subtle text-success-emphasis border border-success-subtle">Aktif</span>
                <?php else: ?>
                  <span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle">Nonaktif</span>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <div class="d-flex gap-1 justify-content-end">
                  <a href="<?= BASE_URL ?>admin/users/edit.php?id=<?= (int)$row['id'] ?>"
                     class="btn btn-sm btn-navy">
                    <i class="fa-solid fa-pen"></i>
                  </a>
                  <?php if ((int)$row['id'] !== (int)user_login()['id']): ?>
                    <a href="?hapus=<?= (int)$row['id'] ?>"
                       class="btn btn-sm btn-danger btn-konfirmasi-hapus"
                       data-msg="Hapus user '<?= e($row['nama']) ?>'?">
                      <i class="fa-solid fa-trash"></i>
                    </a>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; else: ?>
            <tr><td colspan="5" class="text-center py-5 text-muted">Belum ada user.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- MODAL HAPUS -->
<div class="modal fade" id="modalHapus" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Konfirmasi Hapus</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body"><p class="mb-0" id="msgHapus"></p></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-bs-dismiss="modal">Batal</button>
        <a href="#" id="linkHapus" class="btn btn-danger">Hapus</a>
      </div>
    </div>
  </div>
</div>

<script>
document.querySelectorAll('.btn-konfirmasi-hapus').forEach(function(el){
  el.addEventListener('click', function(e){
    e.preventDefault();
    document.getElementById('msgHapus').textContent = this.dataset.msg;
    document.getElementById('linkHapus').href = this.href;
    new bootstrap.Modal(document.getElementById('modalHapus')).show();
  });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?> 