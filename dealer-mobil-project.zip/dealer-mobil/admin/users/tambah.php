<?php
/**
 * User - Tambah
 * Lokasi: admin/users/tambah.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin']);

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama     = trim($_POST['nama'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $whatsapp = trim($_POST['no_whatsapp'] ?? '');
    $password = $_POST['password'] ?? '';
    $role     = $_POST['role'] ?? 'sales';
    $status   = $_POST['status'] ?? 'aktif';

    if ($nama === '')     $errors[] = 'Nama wajib diisi.';
    if ($email === '')    $errors[] = 'Email wajib diisi.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Format email tidak valid.';
    if (strlen($password) < 6) $errors[] = 'Password minimal 6 karakter.';
    if (!in_array($role, ['admin','sales','customer'], true)) $errors[] = 'Role tidak valid.';
    if (!in_array($status, ['aktif','nonaktif'], true)) $errors[] = 'Status tidak valid.';

    if (!$errors) {
        $cek = $pdo->prepare("SELECT id FROM users WHERE email = :email");
        $cek->execute([':email' => $email]);
        if ($cek->fetch()) {
            $errors[] = 'Email sudah terdaftar.';
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO users (nama, email, password, no_whatsapp, role, status)
                VALUES (:nama, :email, :pass, :wa, :role, :status)
            ");
            $stmt->execute([
                ':nama'   => $nama,
                ':email'  => $email,
                ':pass'   => password_hash($password, PASSWORD_DEFAULT),
                ':wa'     => $whatsapp ?: null,
                ':role'   => $role,
                ':status' => $status,
            ]);
            set_flash('success', 'User berhasil ditambahkan.');
            header('Location: ' . BASE_URL . 'admin/users/index.php');
            exit;
        }
    }
}

$pageTitle = 'Tambah User';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Tambah User Baru</h5>
    <small class="text-muted">Buat akun admin, sales, atau customer</small>
  </div>
  <a href="<?= BASE_URL ?>admin/users/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="panel">
      <div class="panel-head"><h5><i class="fa-solid fa-user-plus text-orange me-2"></i>Data User</h5></div>
      <div class="panel-body">
        <form method="post">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
              <input type="text" name="nama" class="form-control" required
                     value="<?= e($_POST['nama'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Email <span class="text-danger">*</span></label>
              <input type="email" name="email" class="form-control" required
                     value="<?= e($_POST['email'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Nomor WhatsApp</label>
              <input type="text" name="no_whatsapp" class="form-control"
                     value="<?= e($_POST['no_whatsapp'] ?? '') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Password <span class="text-danger">*</span></label>
              <input type="password" name="password" class="form-control" required minlength="6">
              <small class="form-text">Minimal 6 karakter.</small>
            </div>
            <div class="col-md-6">
              <label class="form-label">Role <span class="text-danger">*</span></label>
              <select name="role" class="form-select" required>
                <option value="admin"    <?= ($_POST['role'] ?? '') === 'admin'    ? 'selected' : '' ?>>Admin (akses penuh)</option>
                <option value="sales"    <?= ($_POST['role'] ?? 'sales') === 'sales' ? 'selected' : '' ?>>Sales (kelola pengajuan)</option>
                <option value="customer" <?= ($_POST['role'] ?? '') === 'customer' ? 'selected' : '' ?>>Customer</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Status <span class="text-danger">*</span></label>
              <select name="status" class="form-select">
                <option value="aktif"    <?= ($_POST['status'] ?? 'aktif') === 'aktif'    ? 'selected' : '' ?>>Aktif</option>
                <option value="nonaktif" <?= ($_POST['status'] ?? '') === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option>
              </select>
            </div>
            <div class="col-12">
              <button type="submit" class="btn btn-brand w-100">
                <i class="fa-solid fa-floppy-disk me-2"></i>Simpan User
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>