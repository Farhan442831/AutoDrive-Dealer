<?php
/**
 * User - Edit
 * Lokasi: admin/users/edit.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . BASE_URL . 'admin/users/index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute([':id' => $id]);
$userEdit = $stmt->fetch();
if (!$userEdit) {
    set_flash('danger', 'User tidak ditemukan.');
    header('Location: ' . BASE_URL . 'admin/users/index.php');
    exit;
}

$errors = [];
$isSelf = $id === (int)user_login()['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama     = trim($_POST['nama'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $whatsapp = trim($_POST['no_whatsapp'] ?? '');
    $password = $_POST['password'] ?? '';
    $role     = $_POST['role'] ?? 'sales';
    $status   = $_POST['status'] ?? 'aktif';

    if ($nama === '')  $errors[] = 'Nama wajib diisi.';
    if ($email === '') $errors[] = 'Email wajib diisi.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Format email tidak valid.';
    if ($password !== '' && strlen($password) < 6) $errors[] = 'Password minimal 6 karakter.';
    if (!$isSelf && !in_array($role, ['admin','sales','customer'], true)) $errors[] = 'Role tidak valid.';

    // Cek email duplikat
    if (!$errors) {
        $cek = $pdo->prepare("SELECT id FROM users WHERE email = :email AND id != :id");
        $cek->execute([':email' => $email, ':id' => $id]);
        if ($cek->fetch()) $errors[] = 'Email sudah digunakan user lain.';
    }

    if (!$errors) {
        if ($password !== '') {
            $sql = "UPDATE users SET nama=:n, email=:e, no_whatsapp=:w, password=:p, status=:s";
            $params = [':n'=>$nama, ':e'=>$email, ':w'=>$whatsapp ?: null, ':p'=>password_hash($password, PASSWORD_DEFAULT), ':s'=>$status];
        } else {
            $sql = "UPDATE users SET nama=:n, email=:e, no_whatsapp=:w, status=:s";
            $params = [':n'=>$nama, ':e'=>$email, ':w'=>$whatsapp ?: null, ':s'=>$status];
        }
        if (!$isSelf) {
            $sql .= ", role=:r";
            $params[':r'] = $role;
        }
        $sql .= " WHERE id=:id";
        $params[':id'] = $id;
        $pdo->prepare($sql)->execute($params);

        set_flash('success', 'User berhasil diperbarui.');
        header('Location: ' . BASE_URL . 'admin/users/edit.php?id=' . $id);
        exit;
    }
}

$pageTitle = 'Edit User';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Edit User</h5>
    <small class="text-muted"><?= e($userEdit['nama']) ?></small>
  </div>
  <a href="<?= BASE_URL ?>admin/users/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<?php if ($isSelf): ?>
  <div class="alert alert-info">
    <i class="fa-solid fa-circle-info me-2"></i>Anda sedang mengedit akun sendiri. Role tidak dapat diubah.
  </div>
<?php endif; ?>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<div class="row justify-content-center">
  <div class="col-lg-8">
    <div class="panel">
      <div class="panel-head"><h5><i class="fa-solid fa-user-pen text-orange me-2"></i>Data User</h5></div>
      <div class="panel-body">
        <form method="post">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Nama Lengkap</label>
              <input type="text" name="nama" class="form-control" required value="<?= e($userEdit['nama']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control" required value="<?= e($userEdit['email']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Nomor WhatsApp</label>
              <input type="text" name="no_whatsapp" class="form-control" value="<?= e($userEdit['no_whatsapp']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Password Baru <small class="text-muted">(opsional)</small></label>
              <input type="password" name="password" class="form-control" minlength="6">
              <small class="form-text">Kosongkan jika tidak ingin mengganti.</small>
            </div>
            <div class="col-md-6">
              <label class="form-label">Role</label>
              <select name="role" class="form-select" <?= $isSelf ? 'disabled' : '' ?>>
                <option value="admin"    <?= $userEdit['role'] === 'admin'    ? 'selected' : '' ?>>Admin</option>
                <option value="sales"    <?= $userEdit['role'] === 'sales'    ? 'selected' : '' ?>>Sales</option>
                <option value="customer" <?= $userEdit['role'] === 'customer' ? 'selected' : '' ?>>Customer</option>
              </select>
              <?php if ($isSelf): ?>
                <input type="hidden" name="role" value="<?= e($userEdit['role']) ?>">
              <?php endif; ?>
            </div>
            <div class="col-md-6">
              <label class="form-label">Status</label>
              <select name="status" class="form-select">
                <option value="aktif"    <?= $userEdit['status'] === 'aktif'    ? 'selected' : '' ?>>Aktif</option>
                <option value="nonaktif" <?= $userEdit['status'] === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option>
              </select>
            </div>
            <div class="col-12">
              <button type="submit" class="btn btn-brand w-100">
                <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Perubahan
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>