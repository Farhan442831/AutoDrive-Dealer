<?php
/**
 * Promo - Edit
 * Lokasi: admin/promo/edit.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('danger', 'ID tidak valid.');
    header('Location: ' . BASE_URL . 'admin/promo/index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM promo WHERE id = :id");
$stmt->execute([':id' => $id]);
$promo = $stmt->fetch();
if (!$promo) {
    set_flash('danger', 'Promo tidak ditemukan.');
    header('Location: ' . BASE_URL . 'admin/promo/index.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul    = trim($_POST['judul'] ?? '');
    $deskripsi= trim($_POST['deskripsi'] ?? '');
    $syarat   = trim($_POST['syarat_ketentuan'] ?? '');
    $mulai    = $_POST['tanggal_mulai'] ?? '';
    $selesai  = $_POST['tanggal_selesai'] ?? '';
    $status   = $_POST['status'] ?? 'aktif';

    if ($judul === '')  $errors[] = 'Judul wajib diisi.';
    if ($mulai === '' || $selesai === '') $errors[] = 'Tanggal wajib diisi.';
    if ($mulai && $selesai && strtotime($selesai) < strtotime($mulai)) $errors[] = 'Tanggal selesai tidak boleh sebelum tanggal mulai.';

    // Ganti gambar
    $gambar = $promo['gambar'];
    if (!empty($_FILES['gambar']['name'])) {
        $up = upload_gambar($_FILES['gambar'], 'promo');
        if ($up['sukses']) {
            if ($promo['gambar']) hapus_gambar($promo['gambar'], 'promo');
            $gambar = $up['file'];
        } elseif ($up['error']) {
            $errors[] = 'Gambar: ' . $up['error'];
        }
    }

    if (!$errors) {
        $upd = $pdo->prepare("
            UPDATE promo SET judul=:judul, gambar=:gambar, deskripsi=:deskripsi,
                syarat_ketentuan=:syarat, tanggal_mulai=:mulai, tanggal_selesai=:selesai,
                status=:status
            WHERE id=:id
        ");
        $upd->execute([
            ':judul'   => $judul,
            ':gambar'  => $gambar,
            ':deskripsi' => $deskripsi ?: null,
            ':syarat'  => $syarat ?: null,
            ':mulai'   => $mulai,
            ':selesai' => $selesai,
            ':status'  => $status,
            ':id'      => $id,
        ]);
        set_flash('success', 'Promo berhasil diperbarui.');
        header('Location: ' . BASE_URL . 'admin/promo/edit.php?id=' . $id);
        exit;
    }
}

$pageTitle = 'Edit Promo';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Edit Promo</h5>
    <small class="text-muted"><?= e($promo['judul']) ?></small>
  </div>
  <a href="<?= BASE_URL ?>admin/promo/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
  <div class="row g-4">
    <div class="col-lg-8">
      <div class="panel">
        <div class="panel-head"><h5><i class="fa-solid fa-tags text-orange me-2"></i>Informasi Promo</h5></div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Judul Promo <span class="text-danger">*</span></label>
              <input type="text" name="judul" class="form-control" required value="<?= e($promo['judul']) ?>">
            </div>
            <div class="col-12">
              <label class="form-label">Deskripsi</label>
              <textarea name="deskripsi" class="form-control" rows="4"><?= e($promo['deskripsi']) ?></textarea>
            </div>
            <div class="col-12">
              <label class="form-label">Syarat &amp; Ketentuan</label>
              <textarea name="syarat_ketentuan" class="form-control" rows="4"><?= e($promo['syarat_ketentuan']) ?></textarea>
            </div>
            <div class="col-md-6">
              <label class="form-label">Tanggal Mulai <span class="text-danger">*</span></label>
              <input type="date" name="tanggal_mulai" class="form-control" required value="<?= e($promo['tanggal_mulai']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Tanggal Selesai <span class="text-danger">*</span></label>
              <input type="date" name="tanggal_selesai" class="form-control" required value="<?= e($promo['tanggal_selesai']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Status</label>
              <select name="status" class="form-select">
                <option value="aktif"    <?= $promo['status'] === 'aktif'    ? 'selected' : '' ?>>Aktif</option>
                <option value="nonaktif" <?= $promo['status'] === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-image text-orange me-2"></i>Gambar Promo</h5></div>
        <div class="panel-body">
          <img src="<?= img_aset($promo['gambar'], 'promo') ?>" class="img-fluid rounded mb-3"
               style="aspect-ratio:16/9;object-fit:cover">
          <input type="file" name="gambar" class="form-control" accept="image/*">
          <small class="form-text">Kosongkan jika tidak ingin mengganti.</small>
        </div>
      </div>

      <div class="panel">
        <div class="panel-body d-grid gap-2">
          <button type="submit" class="btn btn-brand btn-lg">
            <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Perubahan
          </button>
          <a href="<?= BASE_URL ?>admin/promo/index.php" class="btn btn-ghost">Batal</a>
        </div>
      </div>
    </div>
  </div>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>