<?php
/**
 * Promo - Hapus
 * Lokasi: admin/promo/hapus.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    set_flash('danger', 'ID tidak valid.');
    header('Location: ' . BASE_URL . 'admin/promo/index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT gambar, judul FROM promo WHERE id = :id");
$stmt->execute([':id' => $id]);
$promo = $stmt->fetch();

if (!$promo) {
    set_flash('danger', 'Promo tidak ditemukan.');
    header('Location: ' . BASE_URL . 'admin/promo/index.php');
    exit;
}

if ($promo['gambar']) hapus_gambar($promo['gambar'], 'promo');
$pdo->prepare("DELETE FROM promo WHERE id = :id")->execute([':id' => $id]);

set_flash('success', 'Promo "' . $promo['judul'] . '" berhasil dihapus.');
header('Location: ' . BASE_URL . 'admin/promo/index.php');
exit;