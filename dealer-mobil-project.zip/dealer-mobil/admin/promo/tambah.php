<?php
/**
 * Promo - Tambah
 * Lokasi: admin/promo/tambah.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul      = trim($_POST['judul'] ?? '');
    $deskripsi  = trim($_POST['deskripsi'] ?? '');
    $syarat     = trim($_POST['syarat_ketentuan'] ?? '');
    $mulai      = $_POST['tanggal_mulai'] ?? '';
    $selesai    = $_POST['tanggal_selesai'] ?? '';
    $status     = $_POST['status'] ?? 'aktif';
    $slug       = buat_slug($judul);

    if ($judul === '')  $errors[] = 'Judul wajib diisi.';
    if ($mulai === '')  $errors[] = 'Tanggal mulai wajib diisi.';
    if ($selesai === '') $errors[] = 'Tanggal selesai wajib diisi.';
    if ($mulai && $selesai && strtotime($selesai) < strtotime($mulai)) $errors[] = 'Tanggal selesai tidak boleh sebelum tanggal mulai.';
    if (!in_array($status, ['aktif','nonaktif'], true)) $errors[] = 'Status tidak valid.';

    // Cek slug unik
    $cekslug = $pdo->prepare("SELECT id FROM promo WHERE slug = :slug");
    $cekslug->execute([':slug' => $slug]);
    if ($cekslug->fetch()) {
        $slug .= '-' . time();
    }

    // Upload gambar
    $gambar = null;
    if (!empty($_FILES['gambar']['name'])) {
        $up = upload_gambar($_FILES['gambar'], 'promo');
        if ($up['sukses']) $gambar = $up['file'];
        elseif ($up['error']) $errors[] = 'Gambar: ' . $up['error'];
    }

    if (!$errors) {
        $stmt = $pdo->prepare("
            INSERT INTO promo (judul, slug, gambar, deskripsi, syarat_ketentuan, tanggal_mulai, tanggal_selesai, status)
            VALUES (:judul, :slug, :gambar, :deskripsi, :syarat, :mulai, :selesai, :status)
        ");
        $stmt->execute([
            ':judul'   => $judul,
            ':slug'    => $slug,
            ':gambar'  => $gambar,
            ':deskripsi' => $deskripsi ?: null,
            ':syarat'  => $syarat ?: null,
            ':mulai'   => $mulai,
            ':selesai' => $selesai,
            ':status'  => $status,
        ]);
        set_flash('success', 'Promo berhasil ditambahkan.');
        header('Location: ' . BASE_URL . 'admin/promo/index.php');
        exit;
    }
}

$pageTitle = 'Tambah Promo';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Tambah Promo Baru</h5>
    <small class="text-muted">Buat penawaran spesial untuk pelanggan</small>
  </div>
  <a href="<?= BASE_URL ?>admin/promo/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
  <div class="row g-4">
    <div class="col-lg-8">
      <div class="panel">
        <div class="panel-head"><h5><i class="fa-solid fa-tags text-orange me-2"></i>Informasi Promo</h5></div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Judul Promo <span class="text-danger">*</span></label>
              <input type="text" name="judul" class="form-control" required
                     placeholder="Contoh: DP Ringan Mulai 10 Persen"
                     value="<?= e($_POST['judul'] ?? '') ?>">
            </div>
            <div class="col-12">
              <label class="form-label">Deskripsi</label>
              <textarea name="deskripsi" class="form-control" rows="4"
                        placeholder="Jelaskan isi promo secara singkat..."><?= e($_POST['deskripsi'] ?? '') ?></textarea>
            </div>
            <div class="col-12">
              <label class="form-label">Syarat &amp; Ketentuan</label>
              <textarea name="syarat_ketentuan" class="form-control" rows="4"
                        placeholder="Tuliskan syarat dan ketentuan promo..."><?= e($_POST['syarat_ketentuan'] ?? '') ?></textarea>
            </div>
            <div class="col-md-6">
              <label class="form-label">Tanggal Mulai <span class="text-danger">*</span></label>
              <input type="date" name="tanggal_mulai" class="form-control" required
                     value="<?= e($_POST['tanggal_mulai'] ?? date('Y-m-d')) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Tanggal Selesai <span class="text-danger">*</span></label>
              <input type="date" name="tanggal_selesai" class="form-control" required
                     value="<?= e($_POST['tanggal_selesai'] ?? date('Y-m-d', strtotime('+30 days'))) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Status <span class="text-danger">*</span></label>
              <select name="status" class="form-select">
                <option value="aktif"    <?= ($_POST['status'] ?? 'aktif') === 'aktif'    ? 'selected' : '' ?>>Aktif</option>
                <option value="nonaktif" <?= ($_POST['status'] ?? '') === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-image text-orange me-2"></i>Gambar Promo</h5></div>
        <div class="panel-body">
          <input type="file" name="gambar" class="form-control" accept="image/*">
          <small class="form-text">JPG/PNG/WEBP max 2 MB. Rasio ideal 16:9.</small>
        </div>
      </div>

      <div class="panel">
        <div class="panel-body d-grid gap-2">
          <button type="submit" class="btn btn-brand btn-lg">
            <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Promo
          </button>
          <a href="<?= BASE_URL ?>admin/promo/index.php" class="btn btn-ghost">Batal</a>
        </div>
      </div>
    </div>
  </div>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>