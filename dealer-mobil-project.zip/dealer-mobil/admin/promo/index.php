<?php
/**
 * Promo - List
 * Lokasi: admin/promo/index.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

// Hapus
if (isset($_GET['hapus'])) {
    $hid = (int)$_GET['hapus'];
    $stmt = $pdo->prepare("SELECT gambar FROM promo WHERE id = :id");
    $stmt->execute([':id' => $hid]);
    $row = $stmt->fetch();
    if ($row && $row['gambar']) hapus_gambar($row['gambar'], 'promo');

    $pdo->prepare("DELETE FROM promo WHERE id = :id")->execute([':id' => $hid]);
    set_flash('success', 'Promo berhasil dihapus.');
    header('Location: ' . BASE_URL . 'admin/promo/index.php');
    exit;
}

$pageTitle = 'Promo';
require_once __DIR__ . '/../includes/header.php';

$list = $pdo->query("SELECT * FROM promo ORDER BY created_at DESC")->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Manajemen Promo</h5>
    <small class="text-muted">Total <?= count($list) ?> promo</small>
  </div>
  <a href="<?= BASE_URL ?>admin/promo/tambah.php" class="btn btn-brand">
    <i class="fa-solid fa-plus me-2"></i>Tambah Promo
  </a>
</div>

<div class="panel">
  <div class="panel-body">
    <div class="table-responsive">
      <table class="table table-admin align-middle">
        <thead>
          <tr>
            <th>Gambar</th>
            <th>Judul</th>
            <th>Periode</th>
            <th>Status</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($list): foreach ($list as $row):
            $aktif = $row['status'] === 'aktif' && strtotime($row['tanggal_selesai']) >= strtotime('today');
          ?>
            <tr>
              <td>
                <img src="<?= img_aset($row['gambar'], 'promo') ?>" class="thumb" alt="">
              </td>
              <td>
                <strong style="font-size:13.5px"><?= e($row['judul']) ?></strong><br>
                <small class="text-muted"><?= e(potong($row['deskripsi'], 80)) ?></small>
              </td>
              <td>
                <small>
                  <?= tanggal_id($row['tanggal_mulai']) ?><br>
                  s/d <?= tanggal_id($row['tanggal_selesai']) ?>
                </small>
              </td>
              <td>
                <?php if ($aktif): ?>
                  <span class="badge bg-success-subtle text-success-emphasis border border-success-subtle">Aktif</span>
                <?php elseif ($row['status'] === 'nonaktif'): ?>
                  <span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle">Nonaktif</span>
                <?php else: ?>
                  <span class="badge bg-warning-subtle text-warning-emphasis border border-warning-subtle">Berakhir</span>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <div class="d-flex gap-1 justify-content-end">
                  <a href="<?= BASE_URL ?>admin/promo/edit.php?id=<?= (int)$row['id'] ?>"
                     class="btn btn-sm btn-navy" title="Edit">
                    <i class="fa-solid fa-pen"></i>
                  </a>
                  <a href="?hapus=<?= (int)$row['id'] ?>"
                     class="btn btn-sm btn-danger btn-konfirmasi-hapus"
                     data-msg="Hapus promo '<?= e($row['judul']) ?>'?">
                    <i class="fa-solid fa-trash"></i>
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; else: ?>
            <tr><td colspan="5" class="text-center py-5 text-muted">
              <i class="fa-solid fa-tags d-block mb-2" style="font-size:32px;opacity:.4"></i>
              Belum ada promo. <a href="<?= BASE_URL ?>admin/promo/tambah.php">Tambah sekarang</a>
            </td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- MODAL HAPUS -->
<div class="modal fade" id="modalHapus" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Konfirmasi Hapus</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body"><p class="mb-0" id="msgHapus"></p></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-bs-dismiss="modal">Batal</button>
        <a href="#" id="linkHapus" class="btn btn-danger">Hapus</a>
      </div>
    </div>
  </div>
</div>

<script>
document.querySelectorAll('.btn-konfirmasi-hapus').forEach(function(el){
  el.addEventListener('click', function(e){
    e.preventDefault();
    document.getElementById('msgHapus').textContent = this.dataset.msg;
    document.getElementById('linkHapus').href = this.href;
    new bootstrap.Modal(document.getElementById('modalHapus')).show();
  });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>