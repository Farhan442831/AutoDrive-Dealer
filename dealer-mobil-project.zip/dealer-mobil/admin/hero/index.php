<?php
/**
 * Hero Slides - List
 * Lokasi: admin/hero/index.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin']);

if (isset($_GET['hapus'])) {
    $hid = (int)$_GET['hapus'];
    $stmt = $pdo->prepare("SELECT gambar FROM hero_slides WHERE id = :id");
    $stmt->execute([':id' => $hid]);
    $row = $stmt->fetch();
    if ($row && $row['gambar']) hapus_gambar($row['gambar'], 'hero');

    $pdo->prepare("DELETE FROM hero_slides WHERE id = :id")->execute([':id' => $hid]);
    set_flash('success', 'Slide berhasil dihapus.');
    header('Location: ' . BASE_URL . 'admin/hero/index.php');
    exit;
}

// Toggle status cepat
if (isset($_GET['toggle'])) {
    $tid = (int)$_GET['toggle'];
    $pdo->prepare("UPDATE hero_slides SET status = IF(status='aktif','nonaktif','aktif') WHERE id = :id")
        ->execute([':id' => $tid]);
    set_flash('success', 'Status slide diperbarui.');
    header('Location: ' . BASE_URL . 'admin/hero/index.php');
    exit;
}

$pageTitle = 'Hero Slides';
require_once __DIR__ . '/../includes/header.php';

$list = $pdo->query("SELECT * FROM hero_slides ORDER BY urutan ASC, id ASC")->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Hero Slides Beranda</h5>
    <small class="text-muted">Total <?= count($list) ?> slide &middot; Kelola gambar carousel di homepage</small>
  </div>
  <a href="<?= BASE_URL ?>admin/hero/tambah.php" class="btn btn-brand">
    <i class="fa-solid fa-plus me-2"></i>Tambah Slide
  </a>
</div>

<div class="panel">
  <div class="panel-body">
    <div class="table-responsive">
      <table class="table table-admin align-middle">
        <thead>
          <tr>
            <th style="width:60px">Urutan</th>
            <th>Preview</th>
            <th>Judul</th>
            <th>Tombol</th>
            <th>Status</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($list): foreach ($list as $row): ?>
            <tr>
              <td>
                <span class="badge bg-navy text-white" style="background:var(--navy-700);min-width:32px">
                  #<?= (int)$row['urutan'] ?>
                </span>
              </td>
              <td>
                <img src="<?= img_aset($row['gambar'], 'hero') ?>" 
                     style="width:120px;height:68px;object-fit:cover;border-radius:8px;background:var(--bg-soft)"
                     alt="">
              </td>
              <td>
                <strong style="font-size:13.5px"><?= e(potong($row['judul'], 60)) ?></strong><br>
                <?php if ($row['badge_text']): ?>
                  <small class="text-muted"><i class="fa-solid fa-tag me-1"></i><?= e($row['badge_text']) ?></small>
                <?php endif; ?>
              </td>
              <td>
                <small>
                  <strong><?= e($row['tombol_text']) ?></strong><br>
                  <span class="text-muted"><?= e($row['tombol_link']) ?></span>
                </small>
              </td>
              <td>
                <?php if ($row['status'] === 'aktif'): ?>
                  <span class="badge bg-success-subtle text-success-emphasis border border-success-subtle">Aktif</span>
                <?php else: ?>
                  <span class="badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle">Nonaktif</span>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <div class="d-flex gap-1 justify-content-end">
                  <a href="?toggle=<?= (int)$row['id'] ?>"
                     class="btn btn-sm btn-ghost" title="Toggle Status">
                    <i class="fa-solid fa-<?= $row['status'] === 'aktif' ? 'eye-slash' : 'eye' ?>"></i>
                  </a>
                  <a href="<?= BASE_URL ?>admin/hero/edit.php?id=<?= (int)$row['id'] ?>"
                     class="btn btn-sm btn-navy">
                    <i class="fa-solid fa-pen"></i>
                  </a>
                  <a href="?hapus=<?= (int)$row['id'] ?>"
                     class="btn btn-sm btn-danger btn-konfirmasi-hapus"
                     data-msg="Hapus slide ini?">
                    <i class="fa-solid fa-trash"></i>
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; else: ?>
            <tr><td colspan="6" class="text-center py-5 text-muted">
              <i class="fa-solid fa-image d-block mb-2" style="font-size:32px;opacity:.4"></i>
              Belum ada slide. <a href="<?= BASE_URL ?>admin/hero/tambah.php">Tambah sekarang</a>
            </td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="modal fade" id="modalHapus" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Konfirmasi Hapus</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body"><p class="mb-0" id="msgHapus"></p></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-bs-dismiss="modal">Batal</button>
        <a href="#" id="linkHapus" class="btn btn-danger">Hapus</a>
      </div>
    </div>
  </div>
</div>

<script>
document.querySelectorAll('.btn-konfirmasi-hapus').forEach(function(el){
  el.addEventListener('click', function(e){
    e.preventDefault();
    document.getElementById('msgHapus').textContent = this.dataset.msg;
    document.getElementById('linkHapus').href = this.href;
    new bootstrap.Modal(document.getElementById('modalHapus')).show();
  });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>