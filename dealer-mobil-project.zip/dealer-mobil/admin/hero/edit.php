<?php
/**
 * Hero Slides - Edit
 * Lokasi: admin/hero/edit.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . BASE_URL . 'admin/hero/index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM hero_slides WHERE id = :id");
$stmt->execute([':id' => $id]);
$slide = $stmt->fetch();
if (!$slide) {
    set_flash('danger', 'Slide tidak ditemukan.');
    header('Location: ' . BASE_URL . 'admin/hero/index.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul       = trim($_POST['judul'] ?? '');
    $subjudul    = trim($_POST['subjudul'] ?? '');
    $badge_text  = trim($_POST['badge_text'] ?? '');
    $tombol_text = trim($_POST['tombol_text'] ?? 'Lihat Katalog');
    $tombol_link = trim($_POST['tombol_link'] ?? 'katalog.php');
    $urutan      = (int)($_POST['urutan'] ?? 0);
    $status      = $_POST['status'] ?? 'aktif';

    if ($judul === '') $errors[] = 'Judul wajib diisi.';

    $gambar = $slide['gambar'];
    if (!empty($_FILES['gambar']['name'])) {
        $up = upload_gambar($_FILES['gambar'], 'hero', 3);
        if ($up['sukses']) {
            if ($slide['gambar']) hapus_gambar($slide['gambar'], 'hero');
            $gambar = $up['file'];
        } elseif ($up['error']) {
            $errors[] = 'Gambar: ' . $up['error'];
        }
    }

    if (!$errors) {
        $upd = $pdo->prepare("
            UPDATE hero_slides SET 
                judul=:j, subjudul=:s, gambar=:g, badge_text=:b,
                tombol_text=:tt, tombol_link=:tl, urutan=:u, status=:st
            WHERE id=:id
        ");
        $upd->execute([
            ':j'  => $judul,
            ':s'  => $subjudul ?: null,
            ':g'  => $gambar,
            ':b'  => $badge_text ?: null,
            ':tt' => $tombol_text,
            ':tl' => $tombol_link,
            ':u'  => $urutan,
            ':st' => $status,
            ':id' => $id,
        ]);
        set_flash('success', 'Slide berhasil diperbarui.');
        header('Location: ' . BASE_URL . 'admin/hero/edit.php?id=' . $id);
        exit;
    }
}

$pageTitle = 'Edit Hero Slide';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Edit Slide</h5>
    <small class="text-muted"><?= e(potong($slide['judul'], 60)) ?></small>
  </div>
  <a href="<?= BASE_URL ?>admin/hero/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
  <div class="row g-4">
    <div class="col-lg-8">
      <div class="panel">
        <div class="panel-head"><h5><i class="fa-solid fa-image text-orange me-2"></i>Konten Slide</h5></div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Judul Utama <span class="text-danger">*</span></label>
              <input type="text" name="judul" class="form-control" required maxlength="200"
                     value="<?= e($slide['judul']) ?>">
            </div>
            <div class="col-12">
              <label class="form-label">Subjudul / Deskripsi</label>
              <textarea name="subjudul" class="form-control" rows="3" maxlength="300"><?= e($slide['subjudul']) ?></textarea>
            </div>
            <div class="col-md-6">
              <label class="form-label">Badge Text</label>
              <input type="text" name="badge_text" class="form-control" maxlength="100"
                     value="<?= e($slide['badge_text']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Urutan Tampil</label>
              <input type="number" name="urutan" class="form-control" min="0"
                     value="<?= (int)$slide['urutan'] ?>">
            </div>
          </div>
        </div>
      </div>

      <div class="panel mt-4">
        <div class="panel-head"><h5><i class="fa-solid fa-link text-orange me-2"></i>Tombol CTA</h5></div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Teks Tombol</label>
              <input type="text" name="tombol_text" class="form-control" maxlength="50"
                     value="<?= e($slide['tombol_text']) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Link Tujuan</label>
              <input type="text" name="tombol_link" class="form-control" maxlength="200"
                     value="<?= e($slide['tombol_link']) ?>">
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-image text-orange me-2"></i>Gambar Background</h5></div>
        <div class="panel-body">
          <img src="<?= img_aset($slide['gambar'], 'hero') ?>" 
               class="img-fluid rounded mb-3" 
               style="aspect-ratio:16/9;object-fit:cover;width:100%">
          <input type="file" name="gambar" class="form-control" accept="image/*">
          <small class="form-text">Kosongkan jika tidak ingin mengganti.</small>
        </div>
      </div>

      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-eye text-orange me-2"></i>Status</h5></div>
        <div class="panel-body">
          <select name="status" class="form-select">
            <option value="aktif"    <?= $slide['status'] === 'aktif'    ? 'selected' : '' ?>>Aktif</option>
            <option value="nonaktif" <?= $slide['status'] === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option>
          </select>
        </div>
      </div>

      <div class="panel">
        <div class="panel-body d-grid gap-2">
          <button type="submit" class="btn btn-brand btn-lg">
            <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Perubahan
          </button>
          <a href="<?= BASE_URL ?>admin/hero/index.php" class="btn btn-ghost">Batal</a>
        </div>
      </div>
    </div>
  </div>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>