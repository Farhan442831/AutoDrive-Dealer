<?php
/**
 * Hero Slides - Tambah
 * Lokasi: admin/hero/tambah.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin']);

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul       = trim($_POST['judul'] ?? '');
    $subjudul    = trim($_POST['subjudul'] ?? '');
    $badge_text  = trim($_POST['badge_text'] ?? '');
    $tombol_text = trim($_POST['tombol_text'] ?? 'Lihat Katalog');
    $tombol_link = trim($_POST['tombol_link'] ?? 'katalog.php');
    $urutan      = (int)($_POST['urutan'] ?? 0);
    $status      = $_POST['status'] ?? 'aktif';

    if ($judul === '') $errors[] = 'Judul wajib diisi.';
    if (empty($_FILES['gambar']['name'])) $errors[] = 'Gambar wajib diunggah.';

    // Upload gambar (wajib untuk tambah)
    $gambar = null;
    if (!empty($_FILES['gambar']['name'])) {
        $up = upload_gambar($_FILES['gambar'], 'hero', 3);
        if ($up['sukses']) $gambar = $up['file'];
        elseif ($up['error']) $errors[] = 'Gambar: ' . $up['error'];
    }

    if (!$errors) {
        $stmt = $pdo->prepare("
            INSERT INTO hero_slides 
            (judul, subjudul, gambar, badge_text, tombol_text, tombol_link, urutan, status)
            VALUES (:j, :s, :g, :b, :tt, :tl, :u, :st)
        ");
        $stmt->execute([
            ':j'  => $judul,
            ':s'  => $subjudul ?: null,
            ':g'  => $gambar,
            ':b'  => $badge_text ?: null,
            ':tt' => $tombol_text,
            ':tl' => $tombol_link,
            ':u'  => $urutan,
            ':st' => $status,
        ]);
        set_flash('success', 'Slide berhasil ditambahkan.');
        header('Location: ' . BASE_URL . 'admin/hero/index.php');
        exit;
    }
}

$pageTitle = 'Tambah Hero Slide';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Tambah Slide Baru</h5>
    <small class="text-muted">Slide akan muncul di carousel homepage</small>
  </div>
  <a href="<?= BASE_URL ?>admin/hero/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
  <div class="row g-4">
    <div class="col-lg-8">
      <div class="panel">
        <div class="panel-head"><h5><i class="fa-solid fa-image text-orange me-2"></i>Konten Slide</h5></div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-12">
              <label class="form-label">Judul Utama <span class="text-danger">*</span></label>
              <input type="text" name="judul" class="form-control" required maxlength="200"
                     placeholder="Contoh: Temukan Mobil Bekas Berkualitas dengan Harga Terpercaya"
                     value="<?= e($_POST['judul'] ?? '') ?>">
              <small class="form-text">Teks besar yang muncul di hero section.</small>
            </div>
            <div class="col-12">
              <label class="form-label">Subjudul / Deskripsi</label>
              <textarea name="subjudul" class="form-control" rows="3" maxlength="300"
                        placeholder="Deskripsi singkat di bawah judul..."><?= e($_POST['subjudul'] ?? '') ?></textarea>
            </div>
            <div class="col-md-6">
              <label class="form-label">Badge Text (opsional)</label>
              <input type="text" name="badge_text" class="form-control" maxlength="100"
                     placeholder="Inspeksi 150 Titik · Garansi Mesin"
                     value="<?= e($_POST['badge_text'] ?? '') ?>">
              <small class="form-text">Teks kecil di atas judul.</small>
            </div>
            <div class="col-md-6">
              <label class="form-label">Urutan Tampil</label>
              <input type="number" name="urutan" class="form-control" min="0"
                     value="<?= e($_POST['urutan'] ?? 1) ?>">
              <small class="form-text">Angka lebih kecil tampil lebih awal.</small>
            </div>
          </div>
        </div>
      </div>

      <div class="panel mt-4">
        <div class="panel-head"><h5><i class="fa-solid fa-link text-orange me-2"></i>Tombol CTA</h5></div>
        <div class="panel-body">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label">Teks Tombol</label>
              <input type="text" name="tombol_text" class="form-control" maxlength="50"
                     value="<?= e($_POST['tombol_text'] ?? 'Lihat Katalog') ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Link Tujuan</label>
              <input type="text" name="tombol_link" class="form-control" maxlength="200"
                     placeholder="katalog.php"
                     value="<?= e($_POST['tombol_link'] ?? 'katalog.php') ?>">
              <small class="form-text">Contoh: katalog.php, promo.php, kontak.php</small>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-upload text-orange me-2"></i>Gambar Background</h5></div>
        <div class="panel-body">
          <input type="file" name="gambar" class="form-control" accept="image/*" required>
          <small class="form-text">
            JPG/PNG/WEBP max 3 MB. <strong>Rasio disarankan 16:9</strong> atau lebih lebar 
            (min 1920×1080 px) untuk tampilan optimal di semua layar.
          </small>
        </div>
      </div>

      <div class="panel mb-4">
        <div class="panel-head"><h5><i class="fa-solid fa-eye text-orange me-2"></i>Status</h5></div>
        <div class="panel-body">
          <select name="status" class="form-select">
            <option value="aktif"    <?= ($_POST['status'] ?? 'aktif') === 'aktif'    ? 'selected' : '' ?>>Aktif (tampil di homepage)</option>
            <option value="nonaktif" <?= ($_POST['status'] ?? '') === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option>
          </select>
        </div>
      </div>

      <div class="panel">
        <div class="panel-body d-grid gap-2">
          <button type="submit" class="btn btn-brand btn-lg">
            <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Slide
          </button>
          <a href="<?= BASE_URL ?>admin/hero/index.php" class="btn btn-ghost">Batal</a>
        </div>
      </div>
    </div>
  </div>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>