<?php
/**
 * Hero Slides - Hapus
 * Lokasi: admin/hero/hapus.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin']);

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: ' . BASE_URL . 'admin/hero/index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT gambar FROM hero_slides WHERE id = :id");
$stmt->execute([':id' => $id]);
$row = $stmt->fetch();

if ($row) {
    if ($row['gambar']) hapus_gambar($row['gambar'], 'hero');
    $pdo->prepare("DELETE FROM hero_slides WHERE id = :id")->execute([':id' => $id]);
    set_flash('success', 'Slide berhasil dihapus.');
} else {
    set_flash('danger', 'Slide tidak ditemukan.');
}

header('Location: ' . BASE_URL . 'admin/hero/index.php');
exit;