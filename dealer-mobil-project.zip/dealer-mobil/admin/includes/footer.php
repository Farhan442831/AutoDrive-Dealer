<?php
/**
 * Footer Admin
 * Lokasi: admin/includes/footer.php
 */
?>
  </div><!-- /.admin-content -->
</div><!-- /.admin-main -->

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/polish.js"></script>
<script>
/* Toggle sidebar mobile */
(function(){
  const btn = document.getElementById('toggleSidebar');
  const sidebar = document.getElementById('adminSidebar');
  const overlay = document.getElementById('sidebarOverlay');
  if (btn && sidebar) {
    btn.addEventListener('click', function(){
      sidebar.classList.toggle('show');
      overlay.classList.toggle('show');
    });
    overlay.addEventListener('click', function(){
      sidebar.classList.remove('show');
      overlay.classList.remove('show');
    });
  }
})();
</script>
<?php if (isset($extraJs)) echo $extraJs; ?>
</body>
</html>