<?php
/**
 * Header Admin
 * Lokasi: admin/includes/header.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

// Wajib login sebagai admin/sales
wajib_role(['admin', 'sales']);

$user = user_login();
$pageTitle = $pageTitle ?? 'Dashboard';
$current = basename($_SERVER['PHP_SELF']);
$currentDir = basename(dirname($_SERVER['PHP_SELF']));

// Ambil logo admin
$logoAdmin = '';
if (setting('logo')) {
    $pathLogo = UPLOAD_PATH . 'logo/' . setting('logo');
    if (is_file($pathLogo)) {
        $logoAdmin = UPLOAD_URL . 'logo/' . rawurlencode(setting('logo'));
    }
}
if (!$logoAdmin) $logoAdmin = BASE_URL . 'assets/images/logo.svg';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title><?= e($pageTitle) ?> | Admin <?= e(setting('nama_dealer')) ?></title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link href="<?= BASE_URL ?>assets/css/style.css" rel="stylesheet">
<link href="<?= BASE_URL ?>assets/css/admin.css" rel="stylesheet">
<link href="<?= BASE_URL ?>assets/css/polish.css" rel="stylesheet">
</head>
<body class="admin-body">

<!-- SIDEBAR -->
<aside class="admin-sidebar" id="adminSidebar">
  <div class="sidebar-brand">
    <img src="<?= $logoAdmin ?>"
         alt="<?= e(setting('nama_dealer')) ?>"
         class="sidebar-logo">
  </div>

  <nav class="sidebar-nav">
    <div class="nav-section">Utama</div>
    <a href="<?= BASE_URL ?>admin/index.php" class="nav-item <?= $current === 'index.php' && $currentDir === 'admin' ? 'active' : '' ?>">
      <i class="fa-solid fa-gauge-high"></i> <span>Dashboard</span>
    </a>
    <a href="<?= BASE_URL ?>admin/mobil/index.php" class="nav-item <?= $currentDir === 'mobil' ? 'active' : '' ?>">
      <i class="fa-solid fa-car"></i> <span>Data Mobil</span>
    </a>
    <a href="<?= BASE_URL ?>admin/inspeksi/index.php" class="nav-item <?= $currentDir === 'inspeksi' ? 'active' : '' ?>">
      <i class="fa-solid fa-clipboard-check"></i> <span>Inspeksi</span>
    </a>
    <a href="<?= BASE_URL ?>admin/customer/index.php" class="nav-item <?= $currentDir === 'customer' ? 'active' : '' ?>">
      <i class="fa-solid fa-users"></i> <span>Customer</span>
    </a>

    <div class="nav-section">Pengajuan</div>
    <a href="<?= BASE_URL ?>admin/test-drive/index.php" class="nav-item <?= $currentDir === 'test-drive' ? 'active' : '' ?>">
      <i class="fa-solid fa-car-side"></i> <span>Test Drive</span>
      <?php
      $c = (int)$pdo->query("SELECT COUNT(*) FROM test_drive WHERE status='Pending'")->fetchColumn();
      if ($c): ?><span class="badge-count"><?= $c ?></span><?php endif; ?>
    </a>
    <a href="<?= BASE_URL ?>admin/jual-mobil/index.php" class="nav-item <?= $currentDir === 'jual-mobil' ? 'active' : '' ?>">
      <i class="fa-solid fa-hand-holding-dollar"></i> <span>Jual Mobil</span>
      <?php
      $c = (int)$pdo->query("SELECT COUNT(*) FROM jual_mobil WHERE status='Pending'")->fetchColumn();
      if ($c): ?><span class="badge-count"><?= $c ?></span><?php endif; ?>
    </a>
    <a href="<?= BASE_URL ?>admin/tukar-tambah/index.php" class="nav-item <?= $currentDir === 'tukar-tambah' ? 'active' : '' ?>">
      <i class="fa-solid fa-right-left"></i> <span>Tukar Tambah</span>
      <?php
      $c = (int)$pdo->query("SELECT COUNT(*) FROM tukar_tambah WHERE status='Pending'")->fetchColumn();
      if ($c): ?><span class="badge-count"><?= $c ?></span><?php endif; ?>
    </a>

    <div class="nav-section">Konten</div>
    <a href="<?= BASE_URL ?>admin/hero/index.php" class="nav-item <?= $currentDir === 'hero' ? 'active' : '' ?>">
      <i class="fa-solid fa-images"></i> <span>Hero Slides</span>
    </a>
    <a href="<?= BASE_URL ?>admin/promo/index.php" class="nav-item <?= $currentDir === 'promo' ? 'active' : '' ?>">
      <i class="fa-solid fa-tags"></i> <span>Promo</span>
    </a>
    <a href="<?= BASE_URL ?>admin/artikel/index.php" class="nav-item <?= $currentDir === 'artikel' ? 'active' : '' ?>">
      <i class="fa-regular fa-newspaper"></i> <span>Artikel</span>
    </a>
    <a href="<?= BASE_URL ?>admin/testimoni/index.php" class="nav-item <?= $currentDir === 'testimoni' ? 'active' : '' ?>">
      <i class="fa-solid fa-quote-left"></i> <span>Testimoni</span>
    </a>
    <a href="<?= BASE_URL ?>admin/merek/index.php" class="nav-item <?= $currentDir === 'merek' ? 'active' : '' ?>">
      <i class="fa-solid fa-trademark"></i> <span>Merek Mobil</span>
    </a>
    <a href="<?= BASE_URL ?>admin/kontak/index.php" class="nav-item <?= $currentDir === 'kontak' ? 'active' : '' ?>">
      <i class="fa-regular fa-envelope"></i> <span>Kontak Masuk</span>
      <?php
      $c = (int)$pdo->query("SELECT COUNT(*) FROM kontak WHERE status='baru'")->fetchColumn();
      if ($c): ?><span class="badge-count"><?= $c ?></span><?php endif; ?>
    </a>

    <div class="nav-section">Sistem</div>
    <a href="<?= BASE_URL ?>admin/users/index.php" class="nav-item <?= $currentDir === 'users' ? 'active' : '' ?>">
      <i class="fa-solid fa-user-shield"></i> <span>User &amp; Role</span>
    </a>
    <a href="<?= BASE_URL ?>admin/laporan/index.php" class="nav-item <?= $currentDir === 'laporan' ? 'active' : '' ?>">
      <i class="fa-solid fa-chart-line"></i> <span>Laporan</span>
    </a>
    <a href="<?= BASE_URL ?>admin/pengaturan/index.php" class="nav-item <?= $currentDir === 'pengaturan' ? 'active' : '' ?>">
      <i class="fa-solid fa-gear"></i> <span>Pengaturan</span>
    </a>
    <a href="<?= BASE_URL ?>logout.php" class="nav-item nav-logout">
      <i class="fa-solid fa-arrow-right-from-bracket"></i> <span>Logout</span>
    </a>
  </nav>
</aside>

<!-- MAIN CONTENT -->
<div class="admin-main">
  <header class="admin-topbar">
    <button class="btn-toggle-sidebar" id="toggleSidebar" aria-label="Toggle Menu">
      <i class="fa-solid fa-bars"></i>
    </button>
    <div class="topbar-title">
      <h1><?= e($pageTitle) ?></h1>
    </div>
    <div class="topbar-actions">
      <a href="<?= BASE_URL ?>index.php" target="_blank" class="btn-topbar" title="Lihat Website">
        <i class="fa-solid fa-globe"></i>
      </a>
      <div class="dropdown">
        <button class="btn-user dropdown-toggle" data-bs-toggle="dropdown">
          <span class="avatar-mini"><?= e(inisial($user['nama'])) ?></span>
          <span class="user-name d-none d-md-inline"><?= e($user['nama']) ?></span>
        </button>
        <ul class="dropdown-menu dropdown-menu-end shadow-sm">
          <li><a class="dropdown-item" href="#"><i class="fa-regular fa-user me-2"></i>Profil</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>logout.php">
            <i class="fa-solid fa-arrow-right-from-bracket me-2"></i>Logout</a></li>
        </ul>
      </div>
    </div>
  </header>

  <div class="admin-content">
    <?php if ($flash = tampil_flash()): ?>
      <?= $flash ?>
    <?php endif; ?>