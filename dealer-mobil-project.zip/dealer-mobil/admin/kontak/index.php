<?php
/**
 * Kontak Masuk - List & Kelola
 * Lokasi: admin/kontak/index.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

// Update status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $kid    = (int)$_POST['id'];
    $status = $_POST['status'] ?? '';
    $valid  = ['baru','dibaca','dibalas'];
    if ($kid > 0 && in_array($status, $valid, true)) {
        $pdo->prepare("UPDATE kontak SET status = :s WHERE id = :id")
            ->execute([':s' => $status, ':id' => $kid]);
        set_flash('success', 'Status pesan diperbarui menjadi ' . $status . '.');
    }
    header('Location: ' . BASE_URL . 'admin/kontak/index.php');
    exit;
}

// Hapus
if (isset($_GET['hapus'])) {
    $hid = (int)$_GET['hapus'];
    $pdo->prepare("DELETE FROM kontak WHERE id = :id")->execute([':id' => $hid]);
    set_flash('success', 'Pesan berhasil dihapus.');
    header('Location: ' . BASE_URL . 'admin/kontak/index.php');
    exit;
}

$pageTitle = 'Kontak Masuk';
require_once __DIR__ . '/../includes/header.php';

// Filter
$status = trim($_GET['status'] ?? '');
$where = '';
$params = [];
if (in_array($status, ['baru','dibaca','dibalas'], true)) {
    $where = 'WHERE status = :s';
    $params[':s'] = $status;
}

$stmt = $pdo->prepare("SELECT * FROM kontak $where ORDER BY created_at DESC");
$stmt->execute($params);
$list = $stmt->fetchAll();

// Statistik
$totalBaru = (int)$pdo->query("SELECT COUNT(*) FROM kontak WHERE status='baru'")->fetchColumn();
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Kontak Masuk</h5>
    <small class="text-muted">Total <?= count($list) ?> pesan
      <?php if ($totalBaru): ?>
        &middot; <span class="text-danger"><?= $totalBaru ?> pesan baru</span>
      <?php endif; ?>
    </small>
  </div>
</div>

<div class="panel">
  <div class="panel-body">

    <form method="get" class="filter-bar">
      <select name="status" class="form-select">
        <option value="">Semua Status</option>
        <?php foreach (['baru','dibaca','dibalas'] as $s): ?>
          <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn btn-navy"><i class="fa-solid fa-filter me-1"></i>Filter</button>
      <a href="<?= BASE_URL ?>admin/kontak/index.php" class="btn btn-ghost">Reset</a>
    </form>

    <div class="table-responsive">
      <table class="table table-admin align-middle">
        <thead>
          <tr>
            <th>Pengirim</th>
            <th>Kontak</th>
            <th>Subjek</th>
            <th>Status</th>
            <th>Tanggal</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($list): foreach ($list as $row):
            $badgeStatus = match($row['status']) {
              'baru'    => 'bg-danger-subtle text-danger-emphasis border border-danger-subtle',
              'dibaca'  => 'bg-info-subtle text-info-emphasis border border-info-subtle',
              'dibalas' => 'bg-success-subtle text-success-emphasis border border-success-subtle',
              default   => 'bg-secondary-subtle',
            };
          ?>
            <tr class="<?= $row['status'] === 'baru' ? 'fw-semibold' : '' ?>">
              <td>
                <strong style="font-size:13.5px"><?= e($row['nama']) ?></strong>
                <?php if ($row['status'] === 'baru'): ?>
                  <span class="badge bg-danger ms-1" style="font-size:9.5px">BARU</span>
                <?php endif; ?>
              </td>
              <td>
                <small>
                  <a href="mailto:<?= e($row['email']) ?>" class="text-decoration-none">
                    <?= e($row['email']) ?>
                  </a>
                  <?php if ($row['telepon']): ?>
                    <br><?= e($row['telepon']) ?>
                  <?php endif; ?>
                </small>
              </td>
              <td><small><?= e($row['subjek'] ?: '-') ?></small></td>
              <td><span class="badge <?= $badgeStatus ?>"><?= e(ucfirst($row['status'])) ?></span></td>
              <td><small><?= tanggal_id($row['created_at']) ?></small></td>
              <td class="text-end">
                <div class="d-flex gap-1 justify-content-end">
                  <button type="button" class="btn btn-sm btn-navy btn-detail"
                          data-id="<?= (int)$row['id'] ?>"
                          data-nama="<?= e($row['nama']) ?>"
                          data-email="<?= e($row['email']) ?>"
                          data-telepon="<?= e($row['telepon']) ?>"
                          data-subjek="<?= e($row['subjek']) ?>"
                          data-pesan="<?= e($row['pesan']) ?>"
                          data-status="<?= e($row['status']) ?>"
                          data-created="<?= e(tanggal_id($row['created_at'], true)) ?>">
                    <i class="fa-solid fa-eye"></i>
                  </button>
                  <a href="?hapus=<?= (int)$row['id'] ?>"
                     class="btn btn-sm btn-danger btn-konfirmasi-hapus"
                     data-msg="Hapus pesan dari <?= e($row['nama']) ?>?">
                    <i class="fa-solid fa-trash"></i>
                  </a>
                </div>
              </td>
            </tr>
          <?php endforeach; else: ?>
            <tr><td colspan="6" class="text-center py-5 text-muted">
              <i class="fa-regular fa-envelope-open d-block mb-2" style="font-size:32px;opacity:.4"></i>
              Belum ada pesan masuk.
            </td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- MODAL DETAIL -->
<div class="modal fade" id="modalDetail" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa-regular fa-envelope text-orange me-2"></i>Detail Pesan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="row g-3 mb-3">
          <div class="col-md-6"><small class="text-muted d-block">Nama</small><strong id="dNama"></strong></div>
          <div class="col-md-6"><small class="text-muted d-block">Email</small>
            <a id="dEmailL" href="#" class="text-decoration-none"><strong id="dEmail"></strong></a>
          </div>
          <div class="col-md-6"><small class="text-muted d-block">Telepon</small><strong id="dTelepon"></strong></div>
          <div class="col-md-6"><small class="text-muted d-block">Dikirim pada</small><strong id="dCreated"></strong></div>
          <div class="col-12"><small class="text-muted d-block">Subjek</small><strong id="dSubjek"></strong></div>
          <div class="col-12">
            <small class="text-muted d-block mb-1">Pesan</small>
            <div id="dPesan" style="background:var(--bg-soft);padding:16px;border-radius:10px;font-size:14px;line-height:1.7;white-space:pre-wrap"></div>
          </div>
        </div>

        <hr>

        <form method="post">
          <input type="hidden" name="update_status" value="1">
          <input type="hidden" name="id" id="dId">
          <label class="form-label fw-bold">Ubah Status Pesan</label>
          <div class="d-flex gap-2 flex-wrap mb-3">
            <?php foreach (['baru','dibaca','dibalas'] as $s): ?>
              <button type="submit" name="status" value="<?= $s ?>" class="btn btn-outline-navy btn-sm">
                <?= ucfirst($s) ?>
              </button>
            <?php endforeach; ?>
          </div>
        </form>

        <div class="d-flex gap-2 flex-wrap">
          <a id="btnBalasEmail" href="#" class="btn btn-brand flex-grow-1">
            <i class="fa-regular fa-envelope me-2"></i>Balas via Email
          </a>
          <a id="btnWaBalas" href="#" target="_blank" class="btn btn-wa flex-grow-1">
            <i class="fa-brands fa-whatsapp me-2"></i>Balas via WA
          </a>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- MODAL HAPUS -->
<div class="modal fade" id="modalHapus" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title">Konfirmasi Hapus</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body"><p class="mb-0" id="msgHapus"></p></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" data-bs-dismiss="modal">Batal</button>
        <a href="#" id="linkHapus" class="btn btn-danger">Hapus</a>
      </div>
    </div>
  </div>
</div>

<script>
document.querySelectorAll('.btn-detail').forEach(function(el){
  el.addEventListener('click', function(){
    const d = this.dataset;
    document.getElementById('dId').value = d.id;
    document.getElementById('dNama').textContent = d.nama;
    document.getElementById('dEmail').textContent = d.email;
    document.getElementById('dEmailL').href = 'mailto:' + d.email;
    document.getElementById('dTelepon').textContent = d.telepon || '-';
    document.getElementById('dSubjek').textContent = d.subjek || '(Tanpa subjek)';
    document.getElementById('dPesan').textContent = d.pesan;
    document.getElementById('dCreated').textContent = d.created;

    document.getElementById('btnBalasEmail').href =
      'mailto:' + d.email + '?subject=Re: ' + encodeURIComponent(d.subjek || 'Pesan Anda');

    const waNum = (d.telepon || '').replace(/[^0-9]/g, '');
    document.getElementById('btnWaBalas').href = waNum
      ? 'https://wa.me/' + waNum
      : '<?= wa_link('Halo, terima kasih telah menghubungi ' . setting('nama_dealer')) ?>';

    new bootstrap.Modal(document.getElementById('modalDetail')).show();
  });
});

document.querySelectorAll('.btn-konfirmasi-hapus').forEach(function(el){
  el.addEventListener('click', function(e){
    e.preventDefault();
    document.getElementById('msgHapus').textContent = this.dataset.msg;
    document.getElementById('linkHapus').href = this.href;
    new bootstrap.Modal(document.getElementById('modalHapus')).show();
  });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>