<?php
/**
 * Inspeksi - Form Tambah/Edit
 * Lokasi: admin/inspeksi/form.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

$mobil_id = (int)($_GET['mobil_id'] ?? 0);
if ($mobil_id <= 0) {
    set_flash('danger', 'ID mobil tidak valid.');
    header('Location: ' . BASE_URL . 'admin/inspeksi/index.php');
    exit;
}

// Ambil mobil
$stmt = $pdo->prepare("SELECT m.*, mk.nama_merek FROM mobil m JOIN merek mk ON mk.id = m.merek_id WHERE m.id = :id");
$stmt->execute([':id' => $mobil_id]);
$mobil = $stmt->fetch();

if (!$mobil) {
    set_flash('danger', 'Mobil tidak ditemukan.');
    header('Location: ' . BASE_URL . 'admin/inspeksi/index.php');
    exit;
}

// Ambil inspeksi terakhir kalau ada
$stmtI = $pdo->prepare("SELECT * FROM inspeksi WHERE mobil_id = :id ORDER BY id DESC LIMIT 1");
$stmtI->execute([':id' => $mobil_id]);
$inspeksi = $stmtI->fetch();

$errors = [];
$opsiKondisi = ['Sangat Baik', 'Baik', 'Perlu Perhatian'];

// ============ PROSES POST ============
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $eksterior   = $_POST['eksterior'] ?? 'Baik';
    $interior    = $_POST['interior'] ?? 'Baik';
    $mesin       = $_POST['mesin'] ?? 'Baik';
    $kelistrikan = $_POST['kelistrikan'] ?? 'Baik';
    $ban         = $_POST['ban'] ?? 'Baik';
    $dokumen     = $_POST['dokumen'] ?? 'Baik';
    $catatan     = trim($_POST['catatan'] ?? '');
    $tanggal     = $_POST['tanggal_inspeksi'] ?? date('Y-m-d');
    $pemeriksa   = trim($_POST['pemeriksa'] ?? '');

    foreach ([
        ['eksterior',$eksterior],['interior',$interior],['mesin',$mesin],
        ['kelistrikan',$kelistrikan],['ban',$ban],['dokumen',$dokumen]
    ] as $cek) {
        if (!in_array($cek[1], $opsiKondisi, true)) $errors[] = "Kondisi {$cek[0]} tidak valid.";
    }
    if ($pemeriksa === '') $errors[] = 'Nama pemeriksa wajib diisi.';

    if (!$errors) {
        if ($inspeksi) {
            $upd = $pdo->prepare("
                UPDATE inspeksi SET eksterior=:eks, interior=:int, mesin=:msn,
                    kelistrikan=:kel, ban=:ban, dokumen=:dok, catatan=:cat,
                    tanggal_inspeksi=:tgl, pemeriksa=:pmr
                WHERE id=:id
            ");
            $upd->execute([
                ':eks'=>$eksterior, ':int'=>$interior, ':msn'=>$mesin,
                ':kel'=>$kelistrikan, ':ban'=>$ban, ':dok'=>$dokumen,
                ':cat'=>$catatan ?: null, ':tgl'=>$tanggal, ':pmr'=>$pemeriksa,
                ':id'=>$inspeksi['id'],
            ]);
            set_flash('success', 'Hasil inspeksi berhasil diperbarui.');
        } else {
            $ins = $pdo->prepare("
                INSERT INTO inspeksi (mobil_id, eksterior, interior, mesin, kelistrikan, ban, dokumen,
                    catatan, tanggal_inspeksi, pemeriksa)
                VALUES (:mid, :eks, :int, :msn, :kel, :ban, :dok, :cat, :tgl, :pmr)
            ");
            $ins->execute([
                ':mid'=>$mobil_id, ':eks'=>$eksterior, ':int'=>$interior, ':msn'=>$mesin,
                ':kel'=>$kelistrikan, ':ban'=>$ban, ':dok'=>$dokumen,
                ':cat'=>$catatan ?: null, ':tgl'=>$tanggal, ':pmr'=>$pemeriksa,
            ]);
            set_flash('success', 'Hasil inspeksi berhasil disimpan.');
        }
        header('Location: ' . BASE_URL . 'admin/inspeksi/index.php');
        exit;
    }
}
// ============ END POST ============

$pageTitle = $inspeksi ? 'Edit Inspeksi' : 'Inspeksi Baru';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1"><?= $inspeksi ? 'Edit' : 'Input' ?> Hasil Inspeksi</h5>
    <small class="text-muted"><?= e($mobil['nama_merek']) ?> <?= e($mobil['nama_mobil']) ?> · <?= (int)$mobil['tahun'] ?></small>
  </div>
  <a href="<?= BASE_URL ?>admin/inspeksi/index.php" class="btn btn-ghost">
    <i class="fa-solid fa-arrow-left me-1"></i>Kembali
  </a>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<form method="post">
  <div class="row g-4">
    <div class="col-lg-8">
      <div class="panel">
        <div class="panel-head"><h5><i class="fa-solid fa-clipboard-check text-orange me-2"></i>Kondisi Kendaraan</h5></div>
        <div class="panel-body">
          <div class="row g-3">
            <?php
            $fields = [
              ['eksterior','Eksterior','fa-car-side'],
              ['interior','Interior','fa-couch'],
              ['mesin','Mesin','fa-gears'],
              ['kelistrikan','Kelistrikan','fa-bolt'],
              ['ban','Ban','fa-circle-dot'],
              ['dokumen','Dokumen','fa-file-shield'],
            ];
            foreach ($fields as $f):
              $val = $inspeksi[$f[0]] ?? 'Baik';
            ?>
              <div class="col-md-6">
                <label class="form-label"><i class="fa-solid <?= $f[2] ?> me-1"></i>Kondisi <?= $f[1] ?></label>
                <select name="<?= $f[0] ?>" class="form-select">
                  <?php foreach ($opsiKondisi as $op): ?>
                    <option value="<?= $op ?>" <?= $val === $op ? 'selected' : '' ?>><?= $op ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            <?php endforeach; ?>

            <div class="col-md-6">
              <label class="form-label">Tanggal Inspeksi</label>
              <input type="date" name="tanggal_inspeksi" class="form-control"
                     value="<?= e($inspeksi['tanggal_inspeksi'] ?? date('Y-m-d')) ?>">
            </div>
            <div class="col-md-6">
              <label class="form-label">Nama Pemeriksa</label>
              <input type="text" name="pemeriksa" class="form-control" required
                     placeholder="Contoh: Budi Santoso"
                     value="<?= e($_POST['pemeriksa'] ?? $inspeksi['pemeriksa'] ?? ($user['nama'] ?? '')) ?>">
            </div>
            <div class="col-12">
              <label class="form-label">Catatan Inspeksi</label>
              <textarea name="catatan" class="form-control" rows="4"
                        placeholder="Catatan detail temuan pemeriksaan..."><?= e($_POST['catatan'] ?? $inspeksi['catatan'] ?? '') ?></textarea>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-4">
      <div class="panel mb-4">
        <div class="panel-body">
          <img src="<?= img_mobil($mobil['foto_utama']) ?>" class="img-fluid rounded mb-3"
               style="aspect-ratio:16/11;object-fit:cover">
          <div class="d-flex flex-wrap gap-2 mb-2">
            <span class="<?= badge_mobil($mobil['status']) ?>"><?= e($mobil['status']) ?></span>
            <span class="badge bg-light text-dark border"><?= km($mobil['kilometer']) ?></span>
          </div>
          <strong style="font-size:14px"><?= e($mobil['nama_mobil']) ?></strong>
        </div>
      </div>

      <div class="panel">
        <div class="panel-body d-grid gap-2">
          <button type="submit" class="btn btn-brand btn-lg">
            <i class="fa-solid fa-floppy-disk me-2"></i>Simpan Hasil Inspeksi
          </button>
          <a href="<?= BASE_URL ?>admin/inspeksi/index.php" class="btn btn-ghost">Batal</a>
        </div>
      </div>
    </div>
  </div>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>