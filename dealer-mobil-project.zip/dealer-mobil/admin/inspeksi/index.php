<?php
/**
 * Inspeksi - List
 * Lokasi: admin/inspeksi/index.php
 */
$pageTitle = 'Data Inspeksi';
require_once __DIR__ . '/../includes/header.php';

$sql = "SELECT m.id, m.nama_mobil, m.tahun, m.foto_utama, m.status AS status_mobil,
               mk.nama_merek,
               i.id AS inspeksi_id, i.tanggal_inspeksi, i.pemeriksa,
               i.eksterior, i.interior, i.mesin
        FROM mobil m
        JOIN merek mk ON mk.id = m.merek_id
        LEFT JOIN inspeksi i ON i.mobil_id = m.id
        ORDER BY m.nama_mobil ASC";
$list = $pdo->query($sql)->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Data Inspeksi</h5>
    <small class="text-muted">Total <?= count($list) ?> unit</small>
  </div>
</div>

<div class="panel">
  <div class="panel-body">
    <div class="table-responsive">
      <table class="table table-admin align-middle">
        <thead>
          <tr>
            <th>Foto</th>
            <th>Mobil</th>
            <th>Tanggal</th>
            <th>Pemeriksa</th>
            <th>Kondisi Utama</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($list as $row): ?>
          <tr>
            <td><img src="<?= img_mobil($row['foto_utama']) ?>" class="thumb" alt=""></td>
            <td>
              <strong style="font-size:13.5px"><?= e($row['nama_mobil']) ?></strong><br>
              <small class="text-muted"><?= e($row['nama_merek']) ?> · <?= (int)$row['tahun'] ?></small>
            </td>
            <td>
              <?php if ($row['inspeksi_id']): ?>
                <small><?= tanggal_id($row['tanggal_inspeksi']) ?></small>
              <?php else: ?>
                <span class="badge bg-secondary-subtle text-secondary-emphasis">Belum diinspeksi</span>
              <?php endif; ?>
            </td>
            <td><small><?= e($row['pemeriksa'] ?: '-') ?></small></td>
            <td>
              <?php if ($row['inspeksi_id']): ?>
                <div class="d-flex flex-wrap gap-1">
                  <span class="<?= badge_kondisi($row['eksterior']) ?>">Eks: <?= e($row['eksterior']) ?></span>
                  <span class="<?= badge_kondisi($row['interior']) ?>">Int: <?= e($row['interior']) ?></span>
                  <span class="<?= badge_kondisi($row['mesin']) ?>">Msin: <?= e($row['mesin']) ?></span>
                </div>
              <?php else: ?>
                <small class="text-muted">-</small>
              <?php endif; ?>
            </td>
            <td class="text-end">
              <a href="<?= BASE_URL ?>admin/inspeksi/form.php?mobil_id=<?= (int)$row['id'] ?>"
                 class="btn btn-sm <?= $row['inspeksi_id'] ? 'btn-navy' : 'btn-brand' ?>">
                <i class="fa-solid fa-<?= $row['inspeksi_id'] ? 'pen' : 'plus' ?> me-1"></i>
                <?= $row['inspeksi_id'] ? 'Edit' : 'Inspeksi' ?>
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>