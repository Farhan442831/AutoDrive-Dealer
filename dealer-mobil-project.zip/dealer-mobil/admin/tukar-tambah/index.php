<?php
/**
 * Tukar Tambah - Kelola
 * Lokasi: admin/tukar-tambah/index.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/wa_helper.php';

wajib_role(['admin', 'sales']);

// Update status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $tid    = (int)$_POST['id'];
    $status = $_POST['status'] ?? '';
    $valid  = ['Pending','Diproses','Dihubungi','Selesai','Ditolak'];
    if ($tid > 0 && in_array($status, $valid, true)) {
        $pdo->prepare("UPDATE tukar_tambah SET status = :s WHERE id = :id")
            ->execute([':s' => $status, ':id' => $tid]);
        set_flash('success', 'Status diperbarui menjadi ' . $status . '.');
    }
    header('Location: ' . BASE_URL . 'admin/tukar-tambah/index.php');
    exit;
}

// Hapus
if (isset($_GET['hapus'])) {
    $hid = (int)$_GET['hapus'];
    $stmt = $pdo->prepare("SELECT foto FROM tukar_tambah WHERE id = :id");
    $stmt->execute([':id' => $hid]);
    $row = $stmt->fetch();
    if ($row && $row['foto']) hapus_gambar($row['foto'], 'jual-mobil');

    $pdo->prepare("DELETE FROM tukar_tambah WHERE id = :id")->execute([':id' => $hid]);
    set_flash('success', 'Data pengajuan dihapus.');
    header('Location: ' . BASE_URL . 'admin/tukar-tambah/index.php');
    exit;
}

$pageTitle = 'Tukar Tambah';
require_once __DIR__ . '/../includes/header.php';

$status = trim($_GET['status'] ?? '');
$where = '';
$params = [];
if (in_array($status, ['Pending','Diproses','Dihubungi','Selesai','Ditolak'], true)) {
    $where = 'WHERE tt.status = :s';
    $params[':s'] = $status;
}

$stmt = $pdo->prepare("
    SELECT tt.*, m.nama_mobil AS target_mobil, mk.nama_merek AS target_merek
    FROM tukar_tambah tt
    LEFT JOIN mobil m ON m.id = tt.mobil_id
    LEFT JOIN merek mk ON mk.id = m.merek_id
    $where
    ORDER BY tt.created_at DESC
");
$stmt->execute($params);
$list = $stmt->fetchAll();
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Pengajuan Tukar Tambah</h5>
    <small class="text-muted">Total <?= count($list) ?> pengajuan</small>
  </div>
  <a href="<?= BASE_URL ?>tukar_tambah.php" target="_blank" class="btn btn-ghost">
    <i class="fa-solid fa-external-link-alt me-1"></i>Lihat Form Customer
  </a>
</div>

<div class="panel">
  <div class="panel-body">

    <form method="get" class="filter-bar">
      <select name="status" class="form-select">
        <option value="">Semua Status</option>
        <?php foreach (['Pending','Diproses','Dihubungi','Selesai','Ditolak'] as $s): ?>
          <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= $s ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn btn-navy"><i class="fa-solid fa-filter me-1"></i>Filter</button>
      <a href="<?= BASE_URL ?>admin/tukar-tambah/index.php" class="btn btn-ghost">Reset</a>
    </form>

    <div class="table-responsive">
      <table class="table table-admin align-middle">
        <thead>
          <tr>
            <th>Foto</th>
            <th>Nama / Kontak</th>
            <th>Mobil Ditukar</th>
            <th>Mobil Diminati</th>
            <th>Status</th>
            <th class="text-end">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($list): foreach ($list as $row): ?>
            <tr>
              <td>
                <?php if ($row['foto']): ?>
                  <img src="<?= img_mobil($row['foto'], 'jual-mobil') ?>" class="thumb"
                       onclick="bukaFoto('<?= img_mobil($row['foto'], 'jual-mobil') ?>')" style="cursor:pointer">
                <?php else: ?>
                  <span class="badge bg-light text-muted">No foto</span>
                <?php endif; ?>
              </td>
              <td>
                <strong style="font-size:13.5px"><?= e($row['nama']) ?></strong><br>
                <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $row['whatsapp']) ?>"
                   target="_blank" class="text-success" style="font-size:12.5px">
                  <i class="fa-brands fa-whatsapp"></i> <?= e($row['whatsapp']) ?>
                </a>
              </td>
              <td>
                <small>
                  <strong><?= e($row['merek']) ?> <?= e($row['model']) ?></strong><br>
                  <?= (int)$row['tahun'] ?> &middot; <?= rupiah($row['harga_perkiraan']) ?>
                </small>
              </td>
              <td>
                <?php if ($row['target_mobil']): ?>
                  <small><?= e($row['target_merek']) ?> <?= e($row['target_mobil']) ?></small>
                <?php else: ?>
                  <small class="text-muted">-</small>
                <?php endif; ?>
              </td>
              <td>
                <?php
                $kelasStatus = match ($row['status']) {
                    'Pending'   => 'st-pending',
                    'Diproses'  => 'st-diproses',
                    'Dihubungi' => 'st-diproses',
                    'Selesai'   => 'st-selesai',
                    'Ditolak'   => 'st-ditolak',
                    default     => '',
                };
                ?>
                <form method="post" class="d-inline">
                  <input type="hidden" name="update_status" value="1">
                  <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                  <select name="status" class="select-status <?= $kelasStatus ?>"
                          style="min-width:130px" onchange="this.form.submit()">
                    <?php foreach (['Pending','Diproses','Dihubungi','Selesai','Ditolak'] as $s): ?>
                      <option value="<?= $s ?>" <?= $row['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
                    <?php endforeach; ?>
                  </select>
                </form>
              </td>
              <td class="text-end">
                <div class="dropdown d-inline-block">
                  <button class="btn btn-sm btn-wa dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fa-brands fa-whatsapp"></i> Balas
                  </button>
                  <ul class="dropdown-menu dropdown-menu-end shadow-sm">
                    <li><h6 class="dropdown-header">Kirim pesan status:</h6></li>
                    <?php foreach (['Pending','Diproses','Dihubungi','Selesai','Ditolak'] as $s): ?>
                      <li>
                        <a class="dropdown-item" target="_blank"
                           href="<?= wa_link(wa_template_tukar_tambah($row, $s), $row['whatsapp']) ?>">
                          <?= $s ?>
                        </a>
                      </li>
                    <?php endforeach; ?>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                      <a class="dropdown-item text-danger"
                         href="?hapus=<?= (int)$row['id'] ?>"
                         onclick="return confirm('Hapus pengajuan dari <?= e($row['nama']) ?>?')">
                        <i class="fa-solid fa-trash me-2"></i>Hapus Data
                      </a>
                    </li>
                  </ul>
                </div>
              </td>
            </tr>
          <?php endforeach; else: ?>
            <tr><td colspan="6" class="text-center py-5 text-muted">
              <i class="fa-solid fa-inbox d-block mb-2" style="font-size:32px;opacity:.4"></i>
              Belum ada pengajuan tukar tambah.
            </td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
function bukaFoto(src) {
  const w = window.open('', '_blank');
  w.document.write('<html><head><title>Foto</title></head><body style="margin:0;background:#000;display:flex;align-items:center;justify-content:center;height:100vh"><img src="' + src + '" style="max-width:100%;max-height:100%"></body></html>');
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>