<?php
/**
 * Laporan
 * Lokasi: admin/laporan/index.php
 */
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/auth.php';

wajib_role(['admin', 'sales']);

$jenis = $_GET['jenis'] ?? 'mobil';
$dari  = $_GET['dari'] ?? date('Y-m-01');
$ke    = $_GET['ke']   ?? date('Y-m-d');

$data = [];
$judul = '';

switch ($jenis) {
    case 'mobil':
        $judul = 'Laporan Data Mobil';
        $stmt = $pdo->query("
            SELECT m.*, mk.nama_merek FROM mobil m
            JOIN merek mk ON mk.id = m.merek_id
            ORDER BY m.created_at DESC
        ");
        $data = $stmt->fetchAll();
        break;

    case 'terjual':
        $judul = 'Laporan Mobil Terjual';
        $stmt = $pdo->prepare("
            SELECT m.*, mk.nama_merek FROM mobil m
            JOIN merek mk ON mk.id = m.merek_id
            WHERE m.status = 'Sold Out'
              AND DATE(m.updated_at) BETWEEN :dari AND :ke
            ORDER BY m.updated_at DESC
        ");
        $stmt->execute([':dari' => $dari, ':ke' => $ke]);
        $data = $stmt->fetchAll();
        break;

    case 'customer':
        $judul = 'Laporan Customer';
        $stmt = $pdo->prepare("
            SELECT * FROM users WHERE role='customer'
              AND DATE(created_at) BETWEEN :dari AND :ke
            ORDER BY created_at DESC
        ");
        $stmt->execute([':dari' => $dari, ':ke' => $ke]);
        $data = $stmt->fetchAll();
        break;

    case 'test_drive':
        $judul = 'Laporan Test Drive';
        $stmt = $pdo->prepare("
            SELECT td.*, m.nama_mobil, mk.nama_merek
            FROM test_drive td
            LEFT JOIN mobil m ON m.id = td.mobil_id
            LEFT JOIN merek mk ON mk.id = m.merek_id
            WHERE DATE(td.created_at) BETWEEN :dari AND :ke
            ORDER BY td.created_at DESC
        ");
        $stmt->execute([':dari' => $dari, ':ke' => $ke]);
        $data = $stmt->fetchAll();
        break;

    case 'jual_mobil':
        $judul = 'Laporan Jual Mobil';
        $stmt = $pdo->prepare("
            SELECT * FROM jual_mobil
            WHERE DATE(created_at) BETWEEN :dari AND :ke
            ORDER BY created_at DESC
        ");
        $stmt->execute([':dari' => $dari, ':ke' => $ke]);
        $data = $stmt->fetchAll();
        break;

    case 'tukar_tambah':
        $judul = 'Laporan Tukar Tambah';
        $stmt = $pdo->prepare("
            SELECT tt.*, m.nama_mobil AS target_mobil, mk.nama_merek AS target_merek
            FROM tukar_tambah tt
            LEFT JOIN mobil m ON m.id = tt.mobil_id
            LEFT JOIN merek mk ON mk.id = m.merek_id
            WHERE DATE(tt.created_at) BETWEEN :dari AND :ke
            ORDER BY tt.created_at DESC
        ");
        $stmt->execute([':dari' => $dari, ':ke' => $ke]);
        $data = $stmt->fetchAll();
        break;
}

$pageTitle = 'Laporan';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h5 class="mb-1">Laporan</h5>
    <small class="text-muted">Generate dan cetak laporan sesuai kebutuhan</small>
  </div>
  <button onclick="window.print()" class="btn btn-navy no-print">
    <i class="fa-solid fa-print me-2"></i>Cetak Laporan
  </button>
</div>

<div class="panel no-print mb-4">
  <div class="panel-body">
    <form method="get" class="row g-3 align-items-end">
      <div class="col-md-4">
        <label class="form-label">Jenis Laporan</label>
        <select name="jenis" class="form-select">
          <option value="mobil"         <?= $jenis === 'mobil'         ? 'selected' : '' ?>>Data Mobil</option>
          <option value="terjual"       <?= $jenis === 'terjual'       ? 'selected' : '' ?>>Mobil Terjual</option>
          <option value="customer"      <?= $jenis === 'customer'      ? 'selected' : '' ?>>Customer</option>
          <option value="test_drive"    <?= $jenis === 'test_drive'    ? 'selected' : '' ?>>Test Drive</option>
          <option value="jual_mobil"    <?= $jenis === 'jual_mobil'    ? 'selected' : '' ?>>Jual Mobil</option>
          <option value="tukar_tambah"  <?= $jenis === 'tukar_tambah'  ? 'selected' : '' ?>>Tukar Tambah</option>
        </select>
      </div>
      <div class="col-md-3">
        <label class="form-label">Dari Tanggal</label>
        <input type="date" name="dari" class="form-control" value="<?= e($dari) ?>">
      </div>
      <div class="col-md-3">
        <label class="form-label">Sampai Tanggal</label>
        <input type="date" name="ke" class="form-control" value="<?= e($ke) ?>">
      </div>
      <div class="col-md-2">
        <button type="submit" class="btn btn-brand w-100">
          <i class="fa-solid fa-filter me-1"></i>Tampilkan
        </button>
      </div>
    </form>
  </div>
</div>

<div class="panel">
  <div class="panel-head">
    <div>
      <h5 class="mb-1"><?= e($judul) ?></h5>
      <small class="text-muted">
        Periode: <?= tanggal_id($dari) ?> s/d <?= tanggal_id($ke) ?>
        &middot; Total <?= count($data) ?> data
      </small>
    </div>
    <div class="text-end">
      <div style="font-size:12.5px;color:var(--ink-500)">
        Dicetak: <?= tanggal_id(date('Y-m-d'), true) ?>
      </div>
    </div>
  </div>
  <div class="panel-body">
    <div class="table-responsive">
      <?php if ($jenis === 'mobil' || $jenis === 'terjual'): ?>
        <table class="table table-admin">
          <thead>
            <tr><th>#</th><th>Mobil</th><th>Tahun</th><th>Harga</th><th>KM</th><th>Status</th></tr>
          </thead>
          <tbody>
            <?php foreach ($data as $i => $d): ?>
              <tr>
                <td><?= $i + 1 ?></td>
                <td><?= e($d['nama_merek']) ?> <?= e($d['nama_mobil']) ?></td>
                <td><?= (int)$d['tahun'] ?></td>
                <td><strong><?= rupiah($d['harga']) ?></strong></td>
                <td><?= km($d['kilometer']) ?></td>
                <td><span class="<?= badge_mobil($d['status']) ?>"><?= e($d['status']) ?></span></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

      <?php elseif ($jenis === 'customer'): ?>
        <table class="table table-admin">
          <thead><tr><th>#</th><th>Nama</th><th>Email</th><th>WhatsApp</th><th>Terdaftar</th></tr></thead>
          <tbody>
            <?php foreach ($data as $i => $d): ?>
              <tr>
                <td><?= $i + 1 ?></td>
                <td><?= e($d['nama']) ?></td>
                <td><?= e($d['email']) ?></td>
                <td><?= e($d['no_whatsapp'] ?: '-') ?></td>
                <td><?= tanggal_id($d['created_at']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

      <?php elseif ($jenis === 'test_drive'): ?>
        <table class="table table-admin">
          <thead><tr><th>#</th><th>Nama</th><th>Mobil</th><th>Jadwal</th><th>Status</th></tr></thead>
          <tbody>
            <?php foreach ($data as $i => $d): ?>
              <tr>
                <td><?= $i + 1 ?></td>
                <td><?= e($d['nama']) ?></td>
                <td><?= e(($d['nama_merek'] ?? '') . ' ' . ($d['nama_mobil'] ?? '-')) ?></td>
                <td><?= tanggal_id($d['tanggal']) ?> · <?= substr($d['jam'],0,5) ?></td>
                <td><span class="<?= badge_pengajuan($d['status']) ?>"><?= e($d['status']) ?></span></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

      <?php elseif ($jenis === 'jual_mobil'): ?>
        <table class="table table-admin">
          <thead><tr><th>#</th><th>Nama</th><th>Kendaraan</th><th>Harga Harapan</th><th>Status</th></tr></thead>
          <tbody>
            <?php foreach ($data as $i => $d): ?>
              <tr>
                <td><?= $i + 1 ?></td>
                <td><?= e($d['nama']) ?></td>
                <td><?= e($d['merek']) ?> <?= e($d['model']) ?> (<?= (int)$d['tahun'] ?>)</td>
                <td><strong><?= rupiah($d['harga_harapan']) ?></strong></td>
                <td><span class="<?= badge_pengajuan($d['status']) ?>"><?= e($d['status']) ?></span></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

      <?php elseif ($jenis === 'tukar_tambah'): ?>
        <table class="table table-admin">
          <thead><tr><th>#</th><th>Nama</th><th>Kendaraan</th><th>Target</th><th>Status</th></tr></thead>
          <tbody>
            <?php foreach ($data as $i => $d): ?>
              <tr>
                <td><?= $i + 1 ?></td>
                <td><?= e($d['nama']) ?></td>
                <td><?= e($d['merek']) ?> <?= e($d['model']) ?> (<?= (int)$d['tahun'] ?>)</td>
                <td><?= e(($d['target_merek'] ?? '') . ' ' . ($d['target_mobil'] ?? '-')) ?></td>
                <td><span class="<?= badge_pengajuan($d['status']) ?>"><?= e($d['status']) ?></span></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>

      <?php if (!$data): ?>
        <div class="empty-state">
          <i class="fa-solid fa-folder-open"></i>
          <h5>Tidak Ada Data</h5>
          <p>Tidak ada data untuk filter yang dipilih.</p>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<style>
@media print{
  .no-print, .admin-sidebar, .admin-topbar, .sidebar-overlay, .footer-main, .wa-float, .back-top{ display:none !important; }
  .admin-main{ margin-left:0 !important; }
  .admin-content{ padding:0 !important; }
  .panel{ box-shadow:none !important; border:1px solid #ddd !important; }
  .stat-card, .btn{ display:none !important; }
  body{ background:#fff !important; }
}
</style>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>