<?php
/**
 * Homepage — Hero Carousel + Search Bar
 * Lokasi: index.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Dealer Mobil Bekas Terpercaya';
$pageDesc  = setting('footer_text');

$merekList = $pdo->query("SELECT * FROM merek ORDER BY nama_merek ASC")->fetchAll();

// Hero slides
$heroSlides = [];
try {
    $heroSlides = $pdo->query("
        SELECT * FROM hero_slides
        WHERE status = 'aktif'
        ORDER BY urutan ASC, id ASC
    ")->fetchAll();
} catch (PDOException $e) {
    $heroSlides = [];
}

if (empty($heroSlides)) {
    $heroSlides = [[
        'judul'       => 'Temukan Mobil Bekas Berkualitas dengan Harga Terpercaya',
        'subjudul'    => setting('nama_dealer') . ' menyediakan unit pilihan yang telah melewati inspeksi menyeluruh. Transparan, aman, dan tanpa biaya tersembunyi.',
        'gambar'      => null,
        'badge_text'  => 'Inspeksi 150 Titik · Garansi Mesin',
        'tombol_text' => 'Lihat Katalog',
        'tombol_link' => 'katalog.php',
    ]];
}

$mobilUnggulan = $pdo->query("
    SELECT m.*, mk.nama_merek
    FROM mobil m
    JOIN merek mk ON mk.id = m.merek_id
    WHERE m.status = 'Ready'
    ORDER BY m.unggulan DESC, m.created_at DESC
    LIMIT 8
")->fetchAll();

$promoList = $pdo->query("
    SELECT * FROM promo
    WHERE status='aktif' AND tanggal_selesai >= CURDATE()
    ORDER BY tanggal_mulai DESC LIMIT 3
")->fetchAll();

$artikelList = $pdo->query("
    SELECT * FROM artikel WHERE status='publish'
    ORDER BY created_at DESC LIMIT 3
")->fetchAll();

$testimoniList = $pdo->query("
    SELECT * FROM testimoni WHERE status='tampil'
    ORDER BY created_at DESC LIMIT 4
")->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<!-- ================= HERO CAROUSEL ================= -->
<section class="hero-v2">
  <div id="heroCarousel" class="carousel slide carousel-fade"
       data-bs-ride="carousel" data-bs-interval="6000" data-bs-pause="hover">

    <?php if (count($heroSlides) > 1): ?>
      <div class="carousel-indicators">
        <?php foreach ($heroSlides as $i => $s): ?>
          <button type="button" data-bs-target="#heroCarousel"
                  data-bs-slide-to="<?= $i ?>"
                  class="<?= $i === 0 ? 'active' : '' ?>"
                  aria-label="Slide <?= $i + 1 ?>"></button>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <div class="carousel-inner">
      <?php foreach ($heroSlides as $i => $slide):
        $bgUrl = img_aset($slide['gambar'], 'hero');
        $hasGambar = !empty($slide['gambar']) && is_file(UPLOAD_PATH . 'hero/' . $slide['gambar']);
      ?>
        <div class="carousel-item <?= $i === 0 ? 'active' : '' ?>">
          <div class="hero-slide" style="background-image:url('<?= $hasGambar ? $bgUrl : '' ?>')">
            <div class="hero-slide-overlay"></div>

            <div class="container">
              <div class="hero-slide-inner">
                <?php if (!empty($slide['badge_text'])): ?>
                  <span class="hero-badge">
                    <i class="fa-solid fa-shield-halved"></i>
                    <?= e($slide['badge_text']) ?>
                  </span>
                <?php endif; ?>

                <h1><?= e($slide['judul']) ?></h1>

                <?php if (!empty($slide['subjudul'])): ?>
                  <p class="hero-lead"><?= e($slide['subjudul']) ?></p>
                <?php endif; ?>

                <div class="hero-actions">
                  <a href="<?= BASE_URL . e($slide['tombol_link'] ?: 'katalog.php') ?>"
                     class="btn btn-brand btn-lg">
                    <i class="fa-solid fa-arrow-right me-2"></i><?= e($slide['tombol_text'] ?: 'Lihat Katalog') ?>
                  </a>
                  <a href="<?= wa_link('Halo, saya ingin bertanya mengenai mobil yang tersedia') ?>"
                     target="_blank" rel="noopener" class="btn btn-outline-light-nav btn-lg">
                    <i class="fa-brands fa-whatsapp me-2"></i>WhatsApp
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <?php if (count($heroSlides) > 1): ?>
      <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
        <i class="fa-solid fa-chevron-left"></i>
        <span class="visually-hidden">Sebelumnya</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
        <i class="fa-solid fa-chevron-right"></i>
        <span class="visually-hidden">Selanjutnya</span>
      </button>
    <?php endif; ?>
  </div>
</section>

<!-- ================= SEARCH BAR ================= -->
<section class="search-bar-section">
  <div class="container">
    <div class="search-bar-card">
      <div class="search-bar-head">
        <h5><i class="fa-solid fa-magnifying-glass text-orange me-2"></i>Cari Mobil Impian Anda</h5>
        <p>Masukkan kriteria untuk menemukan unit yang sesuai</p>
      </div>

      <form action="<?= BASE_URL ?>katalog.php" method="get">
        <div class="row g-3 align-items-end">
          <div class="col-lg-3 col-md-6">
            <label class="form-label">Kata Kunci</label>
            <input type="text" name="q" class="form-control"
                   placeholder="Contoh: Avanza, Brio">
          </div>

          <div class="col-lg-2 col-md-6">
            <label class="form-label">Merek</label>
            <select name="merek_id" class="form-select">
              <option value="">Semua Merek</option>
              <?php foreach ($merekList as $m): ?>
                <option value="<?= (int)$m['id'] ?>"><?= e($m['nama_merek']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="col-lg-2 col-md-6">
            <label class="form-label">Transmisi</label>
            <select name="transmisi" class="form-select">
              <option value="">Semua</option>
              <option value="Automatic">Automatic</option>
              <option value="Manual">Manual</option>
            </select>
          </div>

          <div class="col-lg-2 col-md-6">
            <label class="form-label">Tahun Min</label>
            <select name="tahun_min" class="form-select">
              <option value="">Semua</option>
              <?php for ($y = (int)date('Y'); $y >= 2010; $y--): ?>
                <option value="<?= $y ?>"><?= $y ?></option>
              <?php endfor; ?>
            </select>
          </div>

          <div class="col-lg-2 col-md-6">
            <label class="form-label">Harga Maks</label>
            <select name="harga_max" class="form-select">
              <option value="">Semua</option>
              <option value="150000000">Rp 150 Jt</option>
              <option value="250000000">Rp 250 Jt</option>
              <option value="350000000">Rp 350 Jt</option>
              <option value="500000000">Rp 500 Jt</option>
              <option value="9999999999">500 Jt+</option>
            </select>
          </div>

          <div class="col-lg-1 col-md-6">
            <button type="submit" class="btn btn-brand w-100 search-btn">
              <i class="fa-solid fa-magnifying-glass"></i>
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</section>

<!-- ================= KEUNGGULAN ================= -->
<section class="section">
  <div class="container">
    <div class="section-head text-center">
      <span class="eyebrow"><i class="fa-solid fa-award"></i> Mengapa Kami</span>
      <h2 class="section-title">Alasan Ribuan Pelanggan Mempercayai Kami</h2>
      <p class="section-sub">Kami tidak hanya menjual mobil, kami memastikan Anda membeli kendaraan yang tepat.</p>
    </div>

    <div class="row g-4">
      <?php
      $keunggulan = [
        ['fa-clipboard-check', 'Inspeksi 150 Titik', 'Setiap unit melewati pemeriksaan menyeluruh oleh teknisi berpengalaman sebelum dipasarkan.'],
        ['fa-file-shield',     'Dokumen 100% Aman',  'BPKB, STNK, dan faktur diperiksa keasliannya. Bebas sengketa dan bebas banjir.'],
        ['fa-hand-holding-dollar', 'Harga Transparan', 'Harga yang tertera adalah harga nyata. Tidak ada biaya tersembunyi atau kejutan.'],
        ['fa-car-on',          'Garansi Mesin',      'Garansi mesin dan transmisi hingga 1 tahun untuk ketenangan pikiran Anda.'],
        ['fa-credit-card',     'Kredit Mudah',       'Bekerja sama dengan banyak leasing terpercaya. Pengajuan dibantu sampai approve.'],
        ['fa-headset',         'Layanan Purna Jual', 'Tim kami siap membantu Anda setelah pembelian, dari servis hingga perpanjangan pajak.'],
      ];
      foreach ($keunggulan as $i => $k): ?>
        <div class="col-lg-4 col-md-6 reveal">
          <div class="feature-card <?= $i % 3 === 0 ? 'is-accent' : '' ?>">
            <div class="feature-icon"><i class="fa-solid <?= $k[0] ?>"></i></div>
            <h6><?= e($k[1]) ?></h6>
            <p><?= e($k[2]) ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================= KATALOG PILIHAN ================= -->
<section class="section section-soft">
  <div class="container">
    <div class="section-head-split">
      <div class="section-head-left">
        <span class="eyebrow"><i class="fa-solid fa-star"></i> Unit Pilihan</span>
        <h2 class="section-title">Mobil Bekas Terbaik Bulan Ini</h2>
        <p class="section-sub">Unit dengan kondisi terbaik dan harga paling kompetitif.</p>
      </div>
      <div class="section-head-right">
        <a href="<?= BASE_URL ?>katalog.php" class="btn btn-outline-navy">
          Lihat Semua Unit <i class="fa-solid fa-arrow-right ms-2"></i>
        </a>
      </div>
    </div>

    <?php if ($mobilUnggulan): ?>
      <div class="row g-4">
        <?php foreach ($mobilUnggulan as $m): ?>
          <div class="col-xl-3 col-lg-4 col-md-6 reveal">
            <?php include __DIR__ . '/includes/card_mobil.php'; ?>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="empty-state">
        <i class="fa-solid fa-car-burst"></i>
        <h5>Belum Ada Unit Tersedia</h5>
        <p>Silakan cek kembali beberapa waktu ke depan.</p>
      </div>
    <?php endif; ?>
  </div>
</section>

<!-- ================= PROSES ================= -->
<section class="section">
  <div class="container">
    <div class="section-head text-center">
      <span class="eyebrow"><i class="fa-solid fa-route"></i> Cara Pembelian</span>
      <h2 class="section-title">Hanya 4 Langkah Mudah</h2>
      <p class="section-sub">Prosesnya cepat, sederhana, dan transparan dari awal sampai serah terima.</p>
    </div>

    <div class="row g-4 pt-3">
      <?php
      $langkah = [
        ['Pilih Mobil', 'Jelajahi katalog kami dan temukan unit yang sesuai kebutuhan dan anggaran Anda.'],
        ['Hubungi Kami', 'Chat WhatsApp atau booking test drive untuk melihat kondisi mobil secara langsung.'],
        ['Simulasi & Kredit', 'Gunakan simulasi kredit untuk merencanakan cicilan, atau bayar tunai.'],
        ['Serah Terima', 'Setelah dokumen selesai, mobil siap dibawa pulang. Kami urus semua administrasinya.'],
      ];
      foreach ($langkah as $i => $l): ?>
        <div class="col-lg-3 col-md-6 reveal">
          <div class="step-card">
            <span class="step-num"><?= $i + 1 ?></span>
            <h6><?= e($l[0]) ?></h6>
            <p><?= e($l[1]) ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ================= LAYANAN ================= -->
<section class="section section-soft">
  <div class="container">
    <div class="section-head text-center">
      <span class="eyebrow"><i class="fa-solid fa-handshake"></i> Layanan Kami</span>
      <h2 class="section-title">Ingin Jual atau Tukar Mobil Anda?</h2>
      <p class="section-sub">Kami siap membantu Anda menjual atau menukar mobil lama dengan proses yang mudah dan harga bersaing.</p>
    </div>

    <div class="row g-4">
      <div class="col-lg-4 col-md-6">
        <div class="layanan-card">
          <div class="layanan-icon"><i class="fa-solid fa-hand-holding-dollar"></i></div>
          <h5>Jual Mobil Anda</h5>
          <p>Jual mobil langsung ke kami dengan harga terbaik. Proses cepat, pembayaran langsung, dan tanpa perantara.</p>
          <a href="<?= BASE_URL ?>jual_mobil.php" class="btn btn-brand w-100">
            <i class="fa-solid fa-arrow-right me-2"></i>Jual Sekarang
          </a>
        </div>
      </div>

      <div class="col-lg-4 col-md-6">
        <div class="layanan-card">
          <div class="layanan-icon"><i class="fa-solid fa-right-left"></i></div>
          <h5>Tukar Tambah</h5>
          <p>Tukar mobil lama Anda dengan unit baru dari katalog kami. Kami nilai dengan harga pasaran yang fair.</p>
          <a href="<?= BASE_URL ?>tukar_tambah.php" class="btn btn-brand w-100">
            <i class="fa-solid fa-arrow-right me-2"></i>Tukar Tambah
          </a>
        </div>
      </div>

      <div class="col-lg-4 col-md-6">
        <div class="layanan-card">
          <div class="layanan-icon"><i class="fa-solid fa-car-side"></i></div>
          <h5>Booking Test Drive</h5>
          <p>Jadwalkan test drive gratis untuk merasakan langsung performa dan kenyamanan mobil pilihan Anda.</p>
          <a href="<?= BASE_URL ?>test_drive.php" class="btn btn-brand w-100">
            <i class="fa-solid fa-arrow-right me-2"></i>Booking Test Drive
          </a>
        </div>
      </div>
    </div>

    <div class="text-center mt-4">
      <a href="<?= wa_link('Halo, saya ingin menanyakan layanan jual mobil / tukar tambah') ?>"
         target="_blank" rel="noopener" class="btn btn-outline-navy">
        <i class="fa-brands fa-whatsapp me-2"></i>Konsultasi via WhatsApp
      </a>
    </div>
  </div>
</section>

<!-- ================= PROMO ================= -->
<?php if ($promoList): ?>
<section class="section">
  <div class="container">
    <div class="section-head-split">
      <div class="section-head-left">
        <span class="eyebrow"><i class="fa-solid fa-tags"></i> Penawaran Terbatas</span>
        <h2 class="section-title">Promo Terbaru</h2>
        <p class="section-sub">Manfaatkan penawaran spesial sebelum periodenya berakhir.</p>
      </div>
      <div class="section-head-right">
        <a href="<?= BASE_URL ?>promo.php" class="btn btn-outline-navy">
          Semua Promo <i class="fa-solid fa-arrow-right ms-2"></i>
        </a>
      </div>
    </div>

    <div class="row g-4">
      <?php foreach ($promoList as $p): ?>
        <div class="col-lg-4 col-md-6 reveal">
          <div class="promo-card">
            <div class="promo-thumb">
              <img src="<?= img_aset($p['gambar'], 'promo') ?>" alt="<?= e($p['judul']) ?>" loading="lazy">
            </div>
            <div class="promo-body">
              <span class="promo-periode">
                <i class="fa-regular fa-calendar"></i>
                <?= tanggal_id($p['tanggal_mulai']) ?> &ndash; <?= tanggal_id($p['tanggal_selesai']) ?>
              </span>
              <h6><?= e($p['judul']) ?></h6>
              <p><?= e(potong($p['deskripsi'], 105)) ?></p>
              <a href="<?= BASE_URL ?>promo.php" class="btn btn-ghost mt-auto align-self-start">
                Lihat Detail <i class="fa-solid fa-arrow-right ms-2"></i>
              </a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ================= ARTIKEL ================= -->
<?php if ($artikelList): ?>
<section class="section section-soft">
  <div class="container">
    <div class="section-head-split">
      <div class="section-head-left">
        <span class="eyebrow"><i class="fa-regular fa-newspaper"></i> Informasi</span>
        <h2 class="section-title">Artikel &amp; Tips Terbaru</h2>
        <p class="section-sub">Panduan seputar dunia mobil bekas dari tim kami.</p>
      </div>
      <div class="section-head-right">
        <a href="<?= BASE_URL ?>artikel.php" class="btn btn-outline-navy">
          Semua Artikel <i class="fa-solid fa-arrow-right ms-2"></i>
        </a>
      </div>
    </div>

    <div class="row g-4">
      <?php foreach ($artikelList as $a): ?>
        <div class="col-lg-4 col-md-6 reveal">
          <article class="artikel-card">
            <a href="<?= BASE_URL ?>detail_artikel.php?id=<?= (int)$a['id'] ?>" class="artikel-thumb d-block">
              <img src="<?= img_aset($a['thumbnail'], 'artikel') ?>" alt="<?= e($a['judul']) ?>" loading="lazy">
            </a>
            <div class="artikel-body">
              <span class="artikel-kategori"><?= e($a['kategori']) ?></span>
              <h6>
                <a href="<?= BASE_URL ?>detail_artikel.php?id=<?= (int)$a['id'] ?>">
                  <?= e($a['judul']) ?>
                </a>
              </h6>
              <p><?= e(potong($a['ringkasan'], 110)) ?></p>
              <div class="artikel-meta">
                <span><i class="fa-regular fa-calendar me-1"></i><?= tanggal_id($a['created_at']) ?></span>
                <span><i class="fa-regular fa-eye me-1"></i><?= (int)$a['views'] ?>x dibaca</span>
              </div>
            </div>
          </article>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ================= TESTIMONI ================= -->
<?php if ($testimoniList): ?>
<section class="section">
  <div class="container">
    <div class="section-head text-center">
      <span class="eyebrow"><i class="fa-solid fa-quote-left"></i> Testimoni</span>
      <h2 class="section-title">Apa Kata Pelanggan Kami</h2>
      <p class="section-sub">Kepuasan pelanggan adalah prioritas utama kami.</p>
    </div>

    <div class="row g-4">
      <?php foreach ($testimoniList as $t): ?>
        <div class="col-lg-3 col-md-6 reveal">
          <div class="testi-card">
            <div class="testi-stars">
              <?php for ($i = 1; $i <= 5; $i++): ?>
                <i class="fa-<?= $i <= (int)$t['rating'] ? 'solid' : 'regular' ?> fa-star"></i>
              <?php endfor; ?>
            </div>
            <p class="testi-text">&ldquo;<?= e($t['pesan']) ?>&rdquo;</p>
            <div class="testi-user">
              <div class="testi-avatar"><?= e(inisial($t['nama'])) ?></div>
              <div>
                <strong><?= e($t['nama']) ?></strong>
                <span><?= e($t['pekerjaan'] ?: 'Pelanggan') ?><?= $t['kota'] ? ' &middot; ' . e($t['kota']) : '' ?></span>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ================= LOKASI ================= -->
<section class="section section-soft">
  <div class="container">
    <div class="section-head text-center">
      <span class="eyebrow"><i class="fa-solid fa-location-dot"></i> Kunjungi Kami</span>
      <h2 class="section-title">Lokasi Dealer</h2>
      <p class="section-sub">Silakan datang langsung untuk melihat unit secara lebih detail.</p>
    </div>

    <div class="row g-4">
      <div class="col-lg-4">
        <div class="d-flex flex-column gap-3 h-100">
          <div class="info-box">
            <div class="d-flex gap-3">
              <div class="info-icon"><i class="fa-solid fa-location-dot"></i></div>
              <div><h6>Alamat Showroom</h6><p><?= e(setting('alamat')) ?></p></div>
            </div>
          </div>
          <div class="info-box">
            <div class="d-flex gap-3">
              <div class="info-icon"><i class="fa-regular fa-clock"></i></div>
              <div><h6>Jam Operasional</h6><p><?= e(setting('jam_operasional')) ?></p></div>
            </div>
          </div>
          <div class="info-box">
            <div class="d-flex gap-3">
              <div class="info-icon"><i class="fa-brands fa-whatsapp"></i></div>
              <div>
                <h6>WhatsApp &amp; Telepon</h6>
                <p>
                  <a href="<?= wa_link('Halo, saya ingin berkunjung ke showroom') ?>" target="_blank" rel="noopener">
                    <?= e(setting('whatsapp')) ?></a><br>
                  <?= e(setting('telepon')) ?>
                </p>
              </div>
            </div>
          </div>
          <a href="<?= BASE_URL ?>kontak.php" class="btn btn-navy w-100">
            <i class="fa-solid fa-diamond-turn-right me-2"></i>Petunjuk Arah
          </a>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="maps-wrap">
          <iframe src="<?= e(setting('maps_embed')) ?>"
                  loading="lazy" referrerpolicy="no-referrer-when-downgrade"
                  title="Lokasi <?= e(setting('nama_dealer')) ?>"></iframe>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ================= CTA ================= -->
<section class="section-sm">
  <div class="container">
    <div class="cta-section-box">
      <div class="row align-items-center g-4">
        <div class="col-lg-8">
          <h3 class="mb-2">Masih Bingung Memilih Mobil?</h3>
          <p class="mb-0">
            Konsultasikan kebutuhan Anda dengan tim kami secara gratis. Kami akan merekomendasikan
            unit yang paling sesuai dengan budget dan kebutuhan Anda.
          </p>
        </div>
        <div class="col-lg-4 text-lg-end">
          <a href="<?= wa_link('Halo, saya butuh rekomendasi mobil sesuai budget saya') ?>"
             target="_blank" rel="noopener" class="btn btn-wa btn-lg w-100">
            <i class="fa-brands fa-whatsapp me-2"></i>Konsultasi Gratis
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>