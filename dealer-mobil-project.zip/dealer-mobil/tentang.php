<?php
/**
 * Tentang Dealer
 * Lokasi: tentang.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Tentang Kami';
$pageDesc  = 'Profil ' . setting('nama_dealer') . ' - dealer mobil bekas terpercaya.';

// Statistik
$totalMobil   = (int)$pdo->query("SELECT COUNT(*) FROM mobil")->fetchColumn();
$totalTerjual = (int)$pdo->query("SELECT COUNT(*) FROM mobil WHERE status='Sold Out'")->fetchColumn();
$totalCustomer = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='customer'")->fetchColumn();

include __DIR__ . '/includes/header.php';
?>

<div class="breadcrumb-bar">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-2">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Home</a></li>
        <li class="breadcrumb-item active">Tentang Kami</li>
      </ol>
    </nav>
    <h1>Tentang <?= e(setting('nama_dealer')) ?></h1>
    <p class="mb-0" style="color:rgba(255,255,255,.7);font-size:14px">
      <?= e(setting('tagline')) ?>
    </p>
  </div>
</div>

<!-- PROFIL -->
<section class="section">
  <div class="container">
    <div class="row g-5 align-items-center">
      <div class="col-lg-6">
        <span class="eyebrow"><i class="fa-solid fa-car-side"></i> Profil Perusahaan</span>
        <h2 class="section-title mb-3">Dealer Mobil Bekas Pilihan Keluarga Indonesia</h2>
        <p style="font-size:15px;line-height:1.85">
          <?= e(setting('nama_dealer')) ?> berdiri sejak tahun 2012 dengan visi menjadi dealer mobil bekas
          paling terpercaya di Indonesia. Kami percaya bahwa membeli mobil bekas harus sama aman dan
          nyamannya dengan membeli mobil baru.
        </p>
        <p style="font-size:15px;line-height:1.85">
          Setiap unit yang kami jual telah melewati inspeksi menyeluruh 150 titik oleh teknisi
          berpengalaman. Kami juga memberikan laporan inspeksi transparan kepada setiap calon pembeli,
          sehingga Anda dapat mengambil keputusan dengan percaya diri.
        </p>

        <div class="row g-3 mt-4">
          <div class="col-4">
            <div class="stat-kecil">
              <strong><?= number_format($totalMobil) ?>+</strong>
              <span>Unit Tersedia</span>
            </div>
          </div>
          <div class="col-4">
            <div class="stat-kecil">
              <strong><?= number_format($totalTerjual) ?>+</strong>
              <span>Unit Terjual</span>
            </div>
          </div>
          <div class="col-4">
            <div class="stat-kecil">
              <strong>12+</strong>
              <span>Tahun Pengalaman</span>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="tentang-gambar">
          <img src="<?= BASE_URL ?>assets/images/showroom.jpg" alt="Showroom"
               onerror="this.src='<?= BASE_URL ?>assets/images/no-image.svg'">
        </div>
      </div>
    </div>
  </div>
</section>

<!-- VISI MISI -->
<section class="section section-soft">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-6">
        <div class="visi-misi-card visi">
          <div class="vm-icon"><i class="fa-solid fa-eye"></i></div>
          <h3>Visi</h3>
          <p>
            Menjadi dealer mobil bekas nomor satu di Indonesia yang dikenal karena kejujuran,
            transparansi, dan kualitas layanan prima, sehingga setiap pelanggan merasa aman
            dan puas bertransaksi dengan kami.
          </p>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="visi-misi-card misi">
          <div class="vm-icon"><i class="fa-solid fa-bullseye"></i></div>
          <h3>Misi</h3>
          <ul>
            <li>Menyediakan unit mobil bekas berkualitas dengan harga yang transparan dan kompetitif.</li>
            <li>Menjalankan inspeksi menyeluruh pada setiap unit untuk memastikan keamanan dan kenyamanan pelanggan.</li>
            <li>Memberikan pelayanan yang ramah, cepat, dan profesional dalam setiap transaksi.</li>
            <li>Membangun kepercayaan jangka panjang dengan pelanggan melalui integritas dan konsistensi.</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- KEUNGGULAN -->
<section class="section">
  <div class="container">
    <div class="section-head text-center">
      <span class="eyebrow"><i class="fa-solid fa-award"></i> Keunggulan</span>
      <h2 class="section-title">Mengapa Memilih Kami?</h2>
      <p class="section-sub">Kami berkomitmen memberikan pengalaman terbaik bagi setiap pelanggan.</p>
    </div>

    <div class="row g-4">
      <?php
      $keunggulan = [
        ['fa-clipboard-check', 'Inspeksi 150 Titik', 'Setiap unit diperiksa menyeluruh oleh teknisi berpengalaman sebelum dijual.'],
        ['fa-file-shield', 'Dokumen Terjamin', 'Semua dokumen BPKB, STNK, dan faktur diverifikasi keasliannya.'],
        ['fa-hand-holding-dollar', 'Harga Transparan', 'Tidak ada biaya tersembunyi. Harga yang tertera adalah harga nyata.'],
        ['fa-car-on', 'Garansi Mesin', 'Garansi mesin dan transmisi hingga 1 tahun untuk ketenangan Anda.'],
        ['fa-credit-card', 'Kredit Mudah', 'Bekerja sama dengan berbagai leasing terpercaya. Pengajuan dibantu sampai approve.'],
        ['fa-headset', 'Layanan Purna Jual', 'Tim kami siap membantu Anda setelah pembelian, dari servis hingga perpanjangan pajak.'],
      ];
      foreach ($keunggulan as $i => $k): ?>
        <div class="col-lg-4 col-md-6 reveal">
          <div class="feature-card <?= $i % 3 === 0 ? 'is-accent' : '' ?>">
            <div class="feature-icon"><i class="fa-solid <?= $k[0] ?>"></i></div>
            <h6><?= e($k[1]) ?></h6>
            <p><?= e($k[2]) ?></p>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- INFO DEALER -->
<section class="section section-soft">
  <div class="container">
    <div class="row g-4">
      <div class="col-md-4">
        <div class="info-box text-center h-100">
          <div class="info-icon mx-auto mb-3" style="width:60px;height:60px;font-size:24px">
            <i class="fa-solid fa-location-dot"></i>
          </div>
          <h6>Alamat Showroom</h6>
          <p><?= e(setting('alamat')) ?></p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="info-box text-center h-100">
          <div class="info-icon mx-auto mb-3" style="width:60px;height:60px;font-size:24px">
            <i class="fa-regular fa-clock"></i>
          </div>
          <h6>Jam Operasional</h6>
          <p><?= e(setting('jam_operasional')) ?></p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="info-box text-center h-100">
          <div class="info-icon mx-auto mb-3" style="width:60px;height:60px;font-size:24px">
            <i class="fa-brands fa-whatsapp"></i>
          </div>
          <h6>Hubungi Kami</h6>
          <p>
            <a href="<?= wa_link('Halo, saya ingin bertanya') ?>" target="_blank" rel="noopener" class="text-success">
              <?= e(setting('whatsapp')) ?>
            </a><br>
            <a href="mailto:<?= e(setting('email')) ?>"><?= e(setting('email')) ?></a>
          </p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="section-sm">
  <div class="container">
    <div class="p-4 p-lg-5 rounded-lg" style="background:linear-gradient(120deg,#0f2440,#1b3a66)">
      <div class="row align-items-center g-4">
        <div class="col-lg-8 text-white">
          <h3 class="text-white mb-2">Kunjungi Showroom Kami</h3>
          <p class="mb-0" style="color:rgba(255,255,255,.75)">
            Rasakan langsung pengalaman membeli mobil bekas yang aman dan nyaman bersama kami.
          </p>
        </div>
        <div class="col-lg-4 text-lg-end">
          <a href="<?= BASE_URL ?>kontak.php" class="btn btn-brand btn-lg w-100 mb-2">
            <i class="fa-solid fa-diamond-turn-right me-2"></i>Petunjuk Arah
          </a>
          <a href="<?= wa_link('Halo, saya ingin berkunjung ke showroom') ?>"
             target="_blank" rel="noopener" class="btn btn-wa w-100">
            <i class="fa-brands fa-whatsapp me-2"></i>Chat Dulu
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

<style>
.stat-kecil{
  background:var(--bg-soft);border-radius:12px;padding:16px;text-align:center;
}
.stat-kecil strong{
  display:block;font-size:22px;font-weight:800;color:var(--navy-700);line-height:1.1;
}
.stat-kecil span{font-size:12px;color:var(--ink-500)}

.tentang-gambar{
  border-radius:var(--radius-lg);overflow:hidden;box-shadow:var(--shadow-lg);
  aspect-ratio:4/3;background:var(--bg-soft);
}
.tentang-gambar img{width:100%;height:100%;object-fit:cover}

.visi-misi-card{
  background:#fff;border:1px solid var(--line);border-radius:var(--radius);
  padding:32px 28px;height:100%;transition:.28s;
}
.visi-misi-card:hover{transform:translateY(-4px);box-shadow:var(--shadow-lg)}
.vm-icon{
  width:56px;height:56px;border-radius:16px;display:grid;place-items:center;
  font-size:22px;margin-bottom:18px;
}
.visi-misi-card.visi .vm-icon{background:rgba(249,115,22,.12);color:var(--orange-600)}
.visi-misi-card.misi .vm-icon{background:rgba(19,41,75,.08);color:var(--navy-700)}
.visi-misi-card h3{font-size:20px;margin-bottom:14px}
.visi-misi-card p, .visi-misi-card li{font-size:14.5px;line-height:1.8;color:var(--ink-700)}
.visi-misi-card ul{padding-left:20px;margin:0}
.visi-misi-card ul li{margin-bottom:8px}
</style>

<?php include __DIR__ . '/includes/footer.php'; ?>