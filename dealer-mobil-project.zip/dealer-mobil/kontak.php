<?php
/**
 * Kontak
 * Lokasi: kontak.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Hubungi Kami';
$pageDesc  = 'Hubungi ' . setting('nama_dealer') . ' untuk pertanyaan, test drive, atau konsultasi.';

$errors = [];
$sukses = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama    = trim($_POST['nama'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $telepon = trim($_POST['telepon'] ?? '');
    $subjek  = trim($_POST['subjek'] ?? '');
    $pesan   = trim($_POST['pesan'] ?? '');

    if ($nama === '')     $errors[] = 'Nama wajib diisi.';
    if ($email === '')    $errors[] = 'Email wajib diisi.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Format email tidak valid.';
    if ($pesan === '')    $errors[] = 'Pesan wajib diisi.';

    if (!$errors) {
        $stmt = $pdo->prepare("
            INSERT INTO kontak (nama, email, telepon, subjek, pesan, status)
            VALUES (:nama, :email, :telepon, :subjek, :pesan, 'baru')
        ");
        $stmt->execute([
            ':nama' => $nama,
            ':email' => $email,
            ':telepon' => $telepon ?: null,
            ':subjek' => $subjek ?: null,
            ':pesan' => $pesan,
        ]);
        set_flash('success', 'Pesan Anda berhasil dikirim. Tim kami akan segera menghubungi Anda.');
        header('Location: ' . BASE_URL . 'kontak.php');
        exit;
    }
}

include __DIR__ . '/includes/header.php';
?>

<div class="breadcrumb-bar">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-2">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Home</a></li>
        <li class="breadcrumb-item active">Kontak</li>
      </ol>
    </nav>
    <h1>Hubungi Kami</h1>
    <p class="mb-0" style="color:rgba(255,255,255,.7);font-size:14px">
      Kami siap membantu Anda dengan pertanyaan, konsultasi, atau penjadwalan.
    </p>
  </div>
</div>

<!-- INFO KONTAK -->
<section class="section-sm">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-3 col-md-6">
        <div class="info-box text-center h-100">
          <div class="info-icon mx-auto mb-3" style="width:60px;height:60px;font-size:24px">
            <i class="fa-solid fa-location-dot"></i>
          </div>
          <h6>Alamat</h6>
          <p><?= e(setting('alamat')) ?></p>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="info-box text-center h-100">
          <div class="info-icon mx-auto mb-3" style="width:60px;height:60px;font-size:24px">
            <i class="fa-brands fa-whatsapp"></i>
          </div>
          <h6>WhatsApp</h6>
          <p>
            <a href="<?= wa_link('Halo, saya ingin bertanya') ?>" target="_blank" rel="noopener" class="text-success fw-bold">
              <?= e(setting('whatsapp')) ?>
            </a>
          </p>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="info-box text-center h-100">
          <div class="info-icon mx-auto mb-3" style="width:60px;height:60px;font-size:24px">
            <i class="fa-regular fa-envelope"></i>
          </div>
          <h6>Email</h6>
          <p><a href="mailto:<?= e(setting('email')) ?>"><?= e(setting('email')) ?></a></p>
        </div>
      </div>
      <div class="col-lg-3 col-md-6">
        <div class="info-box text-center h-100">
          <div class="info-icon mx-auto mb-3" style="width:60px;height:60px;font-size:24px">
            <i class="fa-regular fa-clock"></i>
          </div>
          <h6>Jam Operasional</h6>
          <p><?= e(setting('jam_operasional')) ?></p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- FORM & MAPS -->
<section class="section">
  <div class="container">
    <div class="row g-4">

      <div class="col-lg-6">
        <div class="detail-box">
          <h5 class="detail-heading"><i class="fa-regular fa-paper-plane"></i> Kirim Pesan</h5>
          <p class="text-muted mb-4" style="font-size:14px">
            Isi form di bawah, tim kami akan merespon dalam 1x24 jam.
          </p>

          <?php if ($errors): ?>
            <div class="alert alert-danger">
              <ul class="mb-0 ps-3">
                <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
              </ul>
            </div>
          <?php endif; ?>

          <form method="post">
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label">Nama <span class="text-danger">*</span></label>
                <input type="text" name="nama" class="form-control" required
                       value="<?= e($_POST['nama'] ?? '') ?>">
              </div>
              <div class="col-md-6">
                <label class="form-label">Email <span class="text-danger">*</span></label>
                <input type="email" name="email" class="form-control" required
                       value="<?= e($_POST['email'] ?? '') ?>">
              </div>
              <div class="col-md-6">
                <label class="form-label">Nomor Telepon</label>
                <input type="text" name="telepon" class="form-control"
                       value="<?= e($_POST['telepon'] ?? '') ?>">
              </div>
              <div class="col-md-6">
                <label class="form-label">Subjek</label>
                <input type="text" name="subjek" class="form-control"
                       value="<?= e($_POST['subjek'] ?? '') ?>">
              </div>
              <div class="col-12">
                <label class="form-label">Pesan <span class="text-danger">*</span></label>
                <textarea name="pesan" class="form-control" rows="5" required><?= e($_POST['pesan'] ?? '') ?></textarea>
              </div>
              <div class="col-12">
                <button type="submit" class="btn btn-brand btn-lg w-100">
                  <i class="fa-solid fa-paper-plane me-2"></i>Kirim Pesan
                </button>
              </div>
            </div>
          </form>

          <div class="mt-4 pt-4" style="border-top:1px solid var(--line)">
            <p class="text-muted mb-2" style="font-size:13px">
              <i class="fa-solid fa-bolt text-warning me-1"></i>
              Butuh respon cepat? Chat kami via WhatsApp.
            </p>
            <a href="<?= wa_link('Halo, saya ingin bertanya') ?>" target="_blank" rel="noopener"
               class="btn btn-wa w-100">
              <i class="fa-brands fa-whatsapp me-2"></i>Chat WhatsApp Sekarang
            </a>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="maps-wrap" style="min-height:100%;height:100%">
          <iframe src="<?= e(setting('maps_embed')) ?>"
                  loading="lazy" referrerpolicy="no-referrer-when-downgrade"
                  style="width:100%;height:100%;min-height:500px;border:0">
          </iframe>
        </div>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>