<?php
/**
 * Katalog Mobil + Filter
 * Lokasi: katalog.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = 'Katalog Mobil';
$pageDesc  = 'Jelajahi seluruh unit mobil bekas berkualitas di ' . setting('nama_dealer');

// ---- Ambil input filter --------------------------------------------
$q          = trim($_GET['q'] ?? '');
$merek_id   = trim($_GET['merek_id'] ?? '');
$harga_min  = trim($_GET['harga_min'] ?? '');
$harga_max  = trim($_GET['harga_max'] ?? '');
$tahun_min  = trim($_GET['tahun_min'] ?? '');
$tahun_max  = trim($_GET['tahun_max'] ?? '');
$transmisi  = trim($_GET['transmisi'] ?? '');
$bahan_bakar= trim($_GET['bahan_bakar'] ?? '');
$status     = trim($_GET['status'] ?? '');
$urut       = trim($_GET['urut'] ?? 'terbaru');

// ---- Bangun query ---------------------------------------------------
$where  = [];
$params = [];

if ($q !== '') {
    // PDO tidak mengizinkan placeholder duplikat → pakai q1, q2, q3
    $where[] = '(m.nama_mobil LIKE :q1 OR m.model LIKE :q2 OR mk.nama_merek LIKE :q3)';
    $params[':q1'] = '%' . $q . '%';
    $params[':q2'] = '%' . $q . '%';
    $params[':q3'] = '%' . $q . '%';
}
if ($merek_id !== '' && ctype_digit($merek_id)) {
    $where[] = 'm.merek_id = :merek_id';
    $params[':merek_id'] = (int)$merek_id;
}
if ($harga_min !== '' && is_numeric($harga_min)) {
    $where[] = 'm.harga >= :harga_min';
    $params[':harga_min'] = (int)$harga_min;
}
if ($harga_max !== '' && is_numeric($harga_max)) {
    $where[] = 'm.harga <= :harga_max';
    $params[':harga_max'] = (int)$harga_max;
}
if ($tahun_min !== '' && ctype_digit($tahun_min)) {
    $where[] = 'm.tahun >= :tahun_min';
    $params[':tahun_min'] = (int)$tahun_min;
}
if ($tahun_max !== '' && ctype_digit($tahun_max)) {
    $where[] = 'm.tahun <= :tahun_max';
    $params[':tahun_max'] = (int)$tahun_max;
}
if (in_array($transmisi, ['Manual','Automatic'], true)) {
    $where[] = 'm.transmisi = :transmisi';
    $params[':transmisi'] = $transmisi;
}
if (in_array($bahan_bakar, ['Bensin','Diesel','Hybrid','Listrik'], true)) {
    $where[] = 'm.bahan_bakar = :bahan_bakar';
    $params[':bahan_bakar'] = $bahan_bakar;
}
if (in_array($status, ['Ready','Booked','Sold Out'], true)) {
    $where[] = 'm.status = :status';
    $params[':status'] = $status;
}

$orderBy = match ($urut) {
    'termurah'   => 'm.harga ASC',
    'termahal'   => 'm.harga DESC',
    'tahun_baru' => 'm.tahun DESC',
    'km_rendah'  => 'm.kilometer ASC',
    default      => 'm.unggulan DESC, m.created_at DESC',
};

$sql = "SELECT m.*, mk.nama_merek
        FROM mobil m
        JOIN merek mk ON mk.id = m.merek_id"
     . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
     . " ORDER BY $orderBy";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$mobilList = $stmt->fetchAll();

// Merek untuk dropdown
$merekList = $pdo->query("SELECT * FROM merek ORDER BY nama_merek ASC")->fetchAll();

// Cek apakah ada filter aktif
$adaFilter = $q || $merek_id || $harga_min || $harga_max || $tahun_min || $tahun_max
          || $transmisi || $bahan_bakar || $status;

include __DIR__ . '/includes/header.php';
?>

<!-- BREADCRUMB -->
<div class="breadcrumb-bar">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-2">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Katalog Mobil</li>
      </ol>
    </nav>
    <h1>Katalog Mobil Bekas</h1>
    <p class="mb-0" style="color:rgba(255,255,255,.7);font-size:14px">
      Ditemukan <strong style="color:#fff"><?= count($mobilList) ?></strong> unit
      <?= $adaFilter ? 'yang sesuai filter Anda' : 'yang tersedia' ?>
    </p>
  </div>
</div>

<section class="section">
  <div class="container">
    <div class="row g-4">

      <!-- SIDEBAR FILTER -->
      <div class="col-lg-3">
        <form method="get" action="<?= BASE_URL ?>katalog.php" class="filter-panel sticky-top"
              style="top:90px">
          <div class="filter-title">
            <i class="fa-solid fa-filter"></i> Filter Pencarian
          </div>

          <div class="mb-3">
            <label class="form-label">Kata Kunci</label>
            <input type="text" name="q" class="form-control" value="<?= e($q) ?>"
                   placeholder="Nama mobil / merek">
          </div>

          <div class="mb-3">
            <label class="form-label">Merek</label>
            <select name="merek_id" class="form-select">
              <option value="">Semua Merek</option>
              <?php foreach ($merekList as $mk): ?>
                <option value="<?= (int)$mk['id'] ?>" <?= $merek_id == $mk['id'] ? 'selected' : '' ?>>
                  <?= e($mk['nama_merek']) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label">Harga (Rp)</label>
            <div class="row g-2">
              <div class="col-6">
                <input type="number" name="harga_min" id="harga_min" class="form-control"
                       value="<?= e($harga_min) ?>" placeholder="Min" min="0" step="1000000">
              </div>
              <div class="col-6">
                <input type="number" name="harga_max" id="harga_max" class="form-control"
                       value="<?= e($harga_max) ?>" placeholder="Max" min="0" step="1000000">
              </div>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label">Tahun</label>
            <div class="row g-2">
              <div class="col-6">
                <input type="number" name="tahun_min" class="form-control"
                       value="<?= e($tahun_min) ?>" placeholder="Min" min="1990" max="<?= date('Y') ?>">
              </div>
              <div class="col-6">
                <input type="number" name="tahun_max" class="form-control"
                       value="<?= e($tahun_max) ?>" placeholder="Max" min="1990" max="<?= date('Y') ?>">
              </div>
            </div>
          </div>

          <div class="mb-3">
            <label class="form-label">Transmisi</label>
            <select name="transmisi" class="form-select">
              <option value="">Semua</option>
              <option value="Automatic" <?= $transmisi === 'Automatic' ? 'selected' : '' ?>>Automatic</option>
              <option value="Manual"    <?= $transmisi === 'Manual'    ? 'selected' : '' ?>>Manual</option>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label">Bahan Bakar</label>
            <select name="bahan_bakar" class="form-select">
              <option value="">Semua</option>
              <?php foreach (['Bensin','Diesel','Hybrid','Listrik'] as $bb): ?>
                <option value="<?= $bb ?>" <?= $bahan_bakar === $bb ? 'selected' : '' ?>><?= $bb ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
              <option value="">Semua</option>
              <?php foreach (['Ready','Booked','Sold Out'] as $st): ?>
                <option value="<?= $st ?>" <?= $status === $st ? 'selected' : '' ?>><?= $st ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label">Urutkan</label>
            <select name="urut" class="form-select">
              <option value="terbaru"    <?= $urut === 'terbaru'    ? 'selected' : '' ?>>Terbaru</option>
              <option value="termurah"   <?= $urut === 'termurah'   ? 'selected' : '' ?>>Harga Termurah</option>
              <option value="termahal"   <?= $urut === 'termahal'   ? 'selected' : '' ?>>Harga Termahal</option>
              <option value="tahun_baru" <?= $urut === 'tahun_baru' ? 'selected' : '' ?>>Tahun Terbaru</option>
              <option value="km_rendah"  <?= $urut === 'km_rendah'  ? 'selected' : '' ?>>KM Terendah</option>
            </select>
          </div>

          <div class="d-grid gap-2">
            <button type="submit" class="btn btn-brand">
              <i class="fa-solid fa-magnifying-glass me-2"></i>Terapkan Filter
            </button>
            <a href="<?= BASE_URL ?>katalog.php" class="btn btn-ghost">
              <i class="fa-solid fa-rotate-left me-2"></i>Reset Filter
            </a>
          </div>
        </form>
      </div>

      <!-- HASIL -->
      <div class="col-lg-9">

        <?php if ($adaFilter): ?>
          <div class="alert alert-light border d-flex align-items-center gap-2 mb-4" style="font-size:13.5px">
            <i class="fa-solid fa-circle-info text-orange"></i>
            <div>
              Menampilkan <strong><?= count($mobilList) ?></strong> unit berdasarkan filter aktif.
              <a href="<?= BASE_URL ?>katalog.php" class="ms-2 text-decoration-underline">Hapus semua filter</a>
            </div>
          </div>
        <?php endif; ?>

        <?php if ($mobilList): ?>
          <div class="row g-4">
            <?php foreach ($mobilList as $m): ?>
              <div class="col-xl-4 col-md-6 reveal">
                <?php include __DIR__ . '/includes/card_mobil.php'; ?>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <div class="empty-state">
            <i class="fa-solid fa-magnifying-glass"></i>
            <h5>Tidak Ada Unit yang Cocok</h5>
            <p>Coba ubah atau kurangi kriteria filter Anda, atau reset filter untuk melihat semua unit.</p>
            <a href="<?= BASE_URL ?>katalog.php" class="btn btn-brand">
              <i class="fa-solid fa-rotate-left me-2"></i>Reset Filter
            </a>
          </div>
        <?php endif; ?>

      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>