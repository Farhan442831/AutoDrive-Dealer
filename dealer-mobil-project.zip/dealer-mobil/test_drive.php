<?php
/**
 * Booking Test Drive (Customer)
 * Lokasi: test_drive.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/wa_helper.php';

$pageTitle = 'Booking Test Drive';
$pageDesc  = 'Jadwalkan test drive mobil pilihan Anda di ' . setting('nama_dealer');

$user = $_SESSION['user'] ?? null;

$mobilList = $pdo->query("
    SELECT m.id, m.nama_mobil, m.tahun, m.harga, mk.nama_merek
    FROM mobil m JOIN merek mk ON mk.id = m.merek_id
    WHERE m.status IN ('Ready','Booked')
    ORDER BY mk.nama_merek, m.nama_mobil
")->fetchAll();

$mobil_id = (int)($_GET['mobil_id'] ?? 0);

$errors = [];
$sukses = false;
$notifWaUrl = null;
$namaCustomer = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama     = trim($_POST['nama'] ?? '');
    $whatsapp = trim($_POST['whatsapp'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $mobilId  = (int)($_POST['mobil_id'] ?? 0);
    $tanggal  = $_POST['tanggal'] ?? '';
    $jam      = $_POST['jam'] ?? '';
    $catatan  = trim($_POST['catatan'] ?? '');

    if ($nama === '')                                   $errors[] = 'Nama lengkap wajib diisi.';
    if ($whatsapp === '')                               $errors[] = 'Nomor WhatsApp wajib diisi.';
    elseif (!preg_match('/^[0-9+\-\s]{8,20}$/', $whatsapp)) $errors[] = 'Format nomor WhatsApp tidak valid.';
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Format email tidak valid.';
    if ($mobilId <= 0)                                  $errors[] = 'Pilih mobil yang ingin di-test drive.';
    if ($tanggal === '')                                $errors[] = 'Tanggal test drive wajib diisi.';
    elseif (strtotime($tanggal) < strtotime('today'))   $errors[] = 'Tanggal tidak boleh di masa lalu.';
    if ($jam === '')                                    $errors[] = 'Jam test drive wajib diisi.';

    if (!$errors) {
        $stmt = $pdo->prepare("
            INSERT INTO test_drive (mobil_id, user_id, nama, whatsapp, email, tanggal, jam, catatan, status)
            VALUES (:mobil_id, :user_id, :nama, :whatsapp, :email, :tanggal, :jam, :catatan, 'Pending')
        ");
        $stmt->execute([
            ':mobil_id' => $mobilId,
            ':user_id'  => $user['id'] ?? null,
            ':nama'     => $nama,
            ':whatsapp' => $whatsapp,
            ':email'    => $email ?: null,
            ':tanggal'  => $tanggal,
            ':jam'      => $jam,
            ':catatan'  => $catatan ?: null,
        ]);

        $tdId = (int)$pdo->lastInsertId();

        // Ambil data lengkap untuk notif admin
        $stmtN = $pdo->prepare("
            SELECT td.*, m.nama_mobil, mk.nama_merek
            FROM test_drive td
            LEFT JOIN mobil m ON m.id = td.mobil_id
            LEFT JOIN merek mk ON mk.id = m.merek_id
            WHERE td.id = :id
        ");
        $stmtN->execute([':id' => $tdId]);
        $tdData = $stmtN->fetch();

        $_SESSION['td_sukses'] = [
            'nama'  => $nama,
            'notif' => wa_link(wa_notif_admin_test_drive($tdData), wa_admin()),
        ];

        header('Location: ' . BASE_URL . 'test_drive.php?sukses=1');
        exit;
    }
}

if (!empty($_GET['sukses']) && !empty($_SESSION['td_sukses'])) {
    $sukses       = true;
    $notifWaUrl   = $_SESSION['td_sukses']['notif'];
    $namaCustomer = $_SESSION['td_sukses']['nama'];
    unset($_SESSION['td_sukses']);
}

include __DIR__ . '/includes/header.php';
?>

<div class="breadcrumb-bar">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-2">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Home</a></li>
        <li class="breadcrumb-item active">Test Drive</li>
      </ol>
    </nav>
    <h1>Booking Test Drive</h1>
    <p class="mb-0" style="color:rgba(255,255,255,.7);font-size:14px">
      Isi form di bawah, tim kami akan menghubungi Anda untuk konfirmasi jadwal.
    </p>
  </div>
</div>

<section class="section">
  <div class="container">
    <div class="row g-4">

      <div class="col-lg-7">

        <?php if ($sukses): ?>
          <div class="detail-box" style="border:2px solid #25d366">
            <div class="text-center mb-4">
              <div style="width:64px;height:64px;border-radius:50%;background:#25d366;color:#fff;display:grid;place-items:center;margin:0 auto 14px;font-size:28px">
                <i class="fa-solid fa-check"></i>
              </div>
              <h3 class="mb-2">Pengajuan Berhasil Dikirim</h3>
              <p class="text-muted mb-0" style="font-size:14.5px">
                Terima kasih, <strong><?= e($namaCustomer) ?></strong>.
                Tim kami akan menghubungi Anda melalui WhatsApp untuk konfirmasi jadwal.
              </p>
            </div>

            <div style="background:#f5f7fa;border-radius:12px;padding:20px;text-align:center;margin-bottom:16px">
              <p class="mb-3" style="font-size:14px">
                Kirim notifikasi ke admin agar pengajuan Anda diproses lebih cepat.
              </p>
              <a href="<?= e($notifWaUrl) ?>" target="_blank" rel="noopener"
                 class="btn btn-wa btn-lg">
                <i class="fa-brands fa-whatsapp me-2"></i>Kirim Notifikasi ke Admin
              </a>
            </div>

            <div class="text-center text-muted" style="font-size:13px">
              <a href="<?= BASE_URL ?>katalog.php">Kembali ke katalog</a>
              &nbsp;&middot;&nbsp;
              <a href="<?= BASE_URL ?>index.php">Halaman utama</a>
            </div>
          </div>
        <?php else: ?>

          <?php if ($errors): ?>
            <div class="alert alert-danger">
              <strong>Periksa kembali data Anda:</strong>
              <ul class="mb-0 mt-2 ps-3">
                <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
              </ul>
            </div>
          <?php endif; ?>

          <div class="detail-box">
            <h5 class="detail-heading"><i class="fa-solid fa-car-side"></i> Form Booking Test Drive</h5>

            <form method="post" novalidate>
              <div class="row g-3">
                <div class="col-md-6">
                  <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                  <input type="text" name="nama" class="form-control" required
                         value="<?= e($_POST['nama'] ?? $user['nama'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Nomor WhatsApp <span class="text-danger">*</span></label>
                  <input type="text" name="whatsapp" class="form-control" required
                         placeholder="08xxxxxxxxxx"
                         value="<?= e($_POST['whatsapp'] ?? $user['no_whatsapp'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Email</label>
                  <input type="email" name="email" class="form-control"
                         value="<?= e($_POST['email'] ?? $user['email'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Pilih Mobil <span class="text-danger">*</span></label>
                  <select name="mobil_id" class="form-select" required>
                    <option value="">-- Pilih mobil --</option>
                    <?php foreach ($mobilList as $m):
                      $selected = (int)($_POST['mobil_id'] ?? $mobil_id) === (int)$m['id']; ?>
                      <option value="<?= (int)$m['id'] ?>" <?= $selected ? 'selected' : '' ?>>
                        <?= e($m['nama_merek']) ?> <?= e($m['nama_mobil']) ?> (<?= (int)$m['tahun'] ?>)
                      </option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Tanggal Test Drive <span class="text-danger">*</span></label>
                  <input type="date" name="tanggal" class="form-control" required
                         min="<?= date('Y-m-d') ?>"
                         value="<?= e($_POST['tanggal'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Jam Test Drive <span class="text-danger">*</span></label>
                  <input type="time" name="jam" class="form-control" required
                         min="08:00" max="17:00"
                         value="<?= e($_POST['jam'] ?? '') ?>">
                  <small class="form-text">Jam operasional: 08.00 - 17.00 WIB</small>
                </div>
                <div class="col-12">
                  <label class="form-label">Catatan Tambahan</label>
                  <textarea name="catatan" class="form-control" rows="3"
                            placeholder="Contoh: Saya ingin melihat kondisi interior dan mesin lebih detail."><?= e($_POST['catatan'] ?? '') ?></textarea>
                </div>
                <div class="col-12">
                  <button type="submit" class="btn btn-brand btn-lg w-100">
                    <i class="fa-solid fa-paper-plane me-2"></i>Kirim Pengajuan
                  </button>
                </div>
              </div>
            </form>
          </div>
        <?php endif; ?>
      </div>

      <div class="col-lg-5">
        <div class="detail-box mb-4">
          <h5 class="detail-heading"><i class="fa-solid fa-circle-info"></i> Informasi</h5>
          <div class="info-mini">
            <div class="d-flex gap-3 mb-3">
              <i class="fa-solid fa-clock"></i>
              <div>
                <strong>Durasi</strong>
                <p class="mb-0">Test drive kurang lebih 15-30 menit.</p>
              </div>
            </div>
            <div class="d-flex gap-3 mb-3">
              <i class="fa-solid fa-id-card"></i>
              <div>
                <strong>Syarat</strong>
                <p class="mb-0">Bawa SIM A yang masih berlaku dan KTP.</p>
              </div>
            </div>
            <div class="d-flex gap-3 mb-3">
              <i class="fa-solid fa-user-tie"></i>
              <div>
                <strong>Didampingi Sales</strong>
                <p class="mb-0">Anda akan didampingi sales kami.</p>
              </div>
            </div>
            <div class="d-flex gap-3">
              <i class="fa-solid fa-location-dot"></i>
              <div>
                <strong>Lokasi</strong>
                <p class="mb-0"><?= e(setting('alamat')) ?></p>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>