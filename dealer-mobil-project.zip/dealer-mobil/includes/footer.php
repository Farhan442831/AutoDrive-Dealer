<?php
/**
 * Footer global
 * Lokasi: includes/footer.php
 */
?>
<footer class="footer-main">
  <div class="container">

    <div class="footer-cta">
      <div class="row align-items-center g-3">
        <div class="col-lg-8">
          <h3 class="mb-1">Tertarik dengan salah satu unit kami?</h3>
          <p class="mb-0">Konsultasi gratis, tanpa biaya. Tim kami siap membantu Anda memilih mobil yang tepat.</p>
        </div>
        <div class="col-lg-4 text-lg-end">
          <a href="<?= wa_link('Halo, saya ingin konsultasi mengenai pembelian mobil di ' . setting('nama_dealer')) ?>"
             target="_blank" rel="noopener" class="btn btn-wa btn-lg w-100 w-lg-auto">
            <i class="fa-brands fa-whatsapp"></i> Chat Sekarang
          </a>
        </div>
      </div>
    </div>

    <div class="row g-4 footer-body">
      <div class="col-lg-4 col-md-6">
        <div class="footer-brand">
          <span class="brand-mark"><i class="fa-solid fa-car-side"></i></span>
          <span class="brand-name"><?= e(setting('nama_dealer', 'AutoPrime Motor')) ?></span>
        </div>
        <p class="footer-desc"><?= e(setting('footer_text')) ?></p>

        <div class="footer-social">
          <?php if (setting('facebook')): ?>
            <a href="<?= e(setting('facebook')) ?>" target="_blank" rel="noopener" aria-label="Facebook">
              <i class="fa-brands fa-facebook-f"></i></a>
          <?php endif; ?>
          <?php if (setting('instagram')): ?>
            <a href="<?= e(setting('instagram')) ?>" target="_blank" rel="noopener" aria-label="Instagram">
              <i class="fa-brands fa-instagram"></i></a>
          <?php endif; ?>
          <?php if (setting('youtube')): ?>
            <a href="<?= e(setting('youtube')) ?>" target="_blank" rel="noopener" aria-label="YouTube">
              <i class="fa-brands fa-youtube"></i></a>
          <?php endif; ?>
          <a href="<?= wa_link('Halo, saya ingin bertanya mengenai unit mobil') ?>" target="_blank" rel="noopener" aria-label="WhatsApp">
            <i class="fa-brands fa-whatsapp"></i></a>
        </div>
      </div>

      <div class="col-lg-2 col-md-6 col-6">
        <h6 class="footer-title">Navigasi</h6>
        <ul class="footer-list">
          <li><a href="<?= BASE_URL ?>index.php">Home</a></li>
          <li><a href="<?= BASE_URL ?>katalog.php">Katalog Mobil</a></li>
          <li><a href="<?= BASE_URL ?>promo.php">Promo</a></li>
          <li><a href="<?= BASE_URL ?>artikel.php">Artikel</a></li>
          <li><a href="<?= BASE_URL ?>tentang.php">Tentang Kami</a></li>
          <li><a href="<?= BASE_URL ?>kontak.php">Kontak</a></li>
        </ul>
      </div>

      <div class="col-lg-2 col-md-6 col-6">
        <h6 class="footer-title">Layanan</h6>
        <ul class="footer-list">
          <li><a href="<?= BASE_URL ?>katalog.php">Beli Mobil</a></li>
          <li><a href="<?= BASE_URL ?>jual_mobil.php">Jual Mobil</a></li>
          <li><a href="<?= BASE_URL ?>tukar_tambah.php">Tukar Tambah</a></li>
          <li><a href="<?= BASE_URL ?>test_drive.php">Booking Test Drive</a></li>
          <li><a href="<?= BASE_URL ?>simulasi_kredit.php">Simulasi Kredit</a></li>
        </ul>
      </div>

      <div class="col-lg-4 col-md-6">
        <h6 class="footer-title">Hubungi Kami</h6>
        <ul class="footer-contact">
          <li>
            <i class="fa-solid fa-location-dot"></i>
            <span><?= e(setting('alamat')) ?></span>
          </li>
          <li>
            <i class="fa-brands fa-whatsapp"></i>
            <a href="<?= wa_link('Halo, saya ingin bertanya') ?>" target="_blank" rel="noopener">
              <?= e(setting('whatsapp')) ?></a>
          </li>
          <li>
            <i class="fa-regular fa-envelope"></i>
            <a href="mailto:<?= e(setting('email')) ?>"><?= e(setting('email')) ?></a>
          </li>
          <li>
            <i class="fa-regular fa-clock"></i>
            <span><?= e(setting('jam_operasional')) ?></span>
          </li>
        </ul>
      </div>
    </div>

    <div class="footer-bottom">
      <p class="mb-0">&copy; <?= date('Y') ?> <?= e(setting('nama_dealer')) ?>. Seluruh hak cipta dilindungi.</p>
      <p class="mb-0 footer-note">Harga dan ketersediaan unit dapat berubah sewaktu-waktu.</p>
    </div>
  </div>
</footer>

<a href="<?= wa_link('Halo, saya ingin bertanya mengenai mobil yang tersedia') ?>"
   class="wa-float" target="_blank" rel="noopener" aria-label="Chat WhatsApp">
  <i class="fa-brands fa-whatsapp"></i>
  <span class="wa-float-text">Chat Kami</span>
</a>

<button class="back-top" id="backTop" aria-label="Kembali ke atas">
  <i class="fa-solid fa-arrow-up"></i>
</button>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
<script src="<?= BASE_URL ?>assets/js/polish.js"></script>
</body>
</html>