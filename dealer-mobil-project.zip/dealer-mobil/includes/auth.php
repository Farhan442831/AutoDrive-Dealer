<?php
/**
 * Helper autentikasi & role
 * Lokasi: includes/auth.php
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

/** Ambil user yang sedang login */
function user_login(): ?array
{
    return $_SESSION['user'] ?? null;
}

/** Wajib login, kalau belum redirect ke login.php */
function wajib_login(): void
{
    if (!user_login()) {
        set_flash('warning', 'Silakan login terlebih dahulu.');
        header('Location: ' . BASE_URL . 'login.php');
        exit;
    }
}

/** Wajib punya role tertentu */
function wajib_role(array $roles): void
{
    wajib_login();
    $u = user_login();
    if (!in_array($u['role'], $roles, true)) {
        set_flash('danger', 'Anda tidak memiliki akses ke halaman tersebut.');
        header('Location: ' . BASE_URL . 'index.php');
        exit;
    }
}

/** Cek apakah user punya role tertentu */
function punya_role(array $roles): bool
{
    $u = user_login();
    return $u && in_array($u['role'], $roles, true);
}