<?php
/**
 * Kumpulan fungsi bantu
 * Lokasi: includes/functions.php
 */

/** Escape output (anti XSS) */
function e($str): string
{
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

/** Format rupiah */
function rupiah($angka): string
{
    return 'Rp ' . number_format((float)$angka, 0, ',', '.');
}

/** Format angka kilometer */
function km($angka): string
{
    return number_format((float)$angka, 0, ',', '.') . ' KM';
}

/** Format tanggal Indonesia */
function tanggal_id($tanggal, bool $denganHari = false): string
{
    if (!$tanggal) return '-';
    $bulan = [1=>'Januari','Februari','Maret','April','Mei','Juni',
              'Juli','Agustus','September','Oktober','November','Desember'];
    $ts = strtotime($tanggal);
    $hasil = date('j', $ts) . ' ' . $bulan[(int)date('n', $ts)] . ' ' . date('Y', $ts);
    if ($denganHari) {
        $hari = ['Sunday'=>'Minggu','Monday'=>'Senin','Tuesday'=>'Selasa',
                 'Wednesday'=>'Rabu','Thursday'=>'Kamis','Friday'=>'Jumat','Saturday'=>'Sabtu'];
        $hasil = $hari[date('l', $ts)] . ', ' . $hasil;
    }
    return $hasil;
}

/** Ambil pengaturan website (cached) */
function setting(string $key, string $default = ''): string
{
    global $pdo;
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            $stmt = $pdo->query("SELECT nama_pengaturan, nilai FROM pengaturan");
            foreach ($stmt as $row) {
                $cache[$row['nama_pengaturan']] = $row['nilai'];
            }
        } catch (PDOException $e) {
            $cache = [];
        }
    }
    return isset($cache[$key]) && $cache[$key] !== '' ? $cache[$key] : $default;
}

/** URL gambar mobil dengan fallback */
function img_mobil(?string $file, string $folder = 'mobil'): string
{
    if ($file) {
        $path = UPLOAD_PATH . $folder . '/' . $file;
        if (is_file($path)) {
            return UPLOAD_URL . $folder . '/' . rawurlencode($file);
        }
    }
    return BASE_URL . 'assets/images/no-image.svg';
}

/** URL gambar umum (promo / artikel) */
function img_aset(?string $file, string $folder = 'promo'): string
{
    return img_mobil($file, $folder);
}

/** Bangun link WhatsApp */
function wa_link(string $pesan = '', ?string $nomor = null): string
{
    $nomor = $nomor ?: setting('whatsapp', '6281234567890');
    $nomor = preg_replace('/[^0-9]/', '', $nomor);
    if (str_starts_with($nomor, '0')) {
        $nomor = '62' . substr($nomor, 1);
    }
    $url = 'https://wa.me/' . $nomor;
    if ($pesan !== '') {
        $url .= '?text=' . rawurlencode($pesan);
    }
    return $url;
}

/** Kelas badge Bootstrap untuk status mobil */
function badge_mobil(string $status): string
{
    return match ($status) {
        'Ready'    => 'badge bg-success-subtle text-success-emphasis border border-success-subtle',
        'Booked'   => 'badge bg-warning-subtle text-warning-emphasis border border-warning-subtle',
        'Sold Out' => 'badge bg-secondary-subtle text-secondary-emphasis border border-secondary-subtle',
        default    => 'badge bg-light text-dark',
    };
}

/** Kelas badge untuk status pengajuan */
function badge_pengajuan(string $status): string
{
    return match ($status) {
        'Pending'   => 'badge bg-warning-subtle text-warning-emphasis border border-warning-subtle',
        'Diproses'  => 'badge bg-info-subtle text-info-emphasis border border-info-subtle',
        'Dihubungi' => 'badge bg-primary-subtle text-primary-emphasis border border-primary-subtle',
        'Disetujui' => 'badge bg-success-subtle text-success-emphasis border border-success-subtle',
        'Selesai'   => 'badge bg-success text-white',
        'Ditolak'   => 'badge bg-danger-subtle text-danger-emphasis border border-danger-subtle',
        default     => 'badge bg-light text-dark',
    };
}

/** Kelas badge kondisi inspeksi */
function badge_kondisi(string $kondisi): string
{
    return match ($kondisi) {
        'Sangat Baik'     => 'badge bg-success-subtle text-success-emphasis border border-success-subtle',
        'Baik'            => 'badge bg-primary-subtle text-primary-emphasis border border-primary-subtle',
        'Perlu Perhatian' => 'badge bg-warning-subtle text-warning-emphasis border border-warning-subtle',
        default           => 'badge bg-light text-dark',
    };
}

/** Buat slug dari string */
function buat_slug(string $text): string
{
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
    $text = preg_replace('/[\s-]+/', '-', $text);
    return trim($text, '-');
}

/** Ambil inisial nama untuk avatar */
function inisial(string $nama): string
{
    $parts = preg_split('/\s+/', trim($nama));
    $ini = strtoupper(substr($parts[0] ?? '', 0, 1));
    if (count($parts) > 1) {
        $ini .= strtoupper(substr(end($parts), 0, 1));
    }
    return $ini ?: '?';
}

/** Alert flash message sederhana */
function set_flash(string $tipe, string $pesan): void
{
    $_SESSION['flash'] = ['tipe' => $tipe, 'pesan' => $pesan];
}

function tampil_flash(): string
{
    if (empty($_SESSION['flash'])) return '';
    $f = $_SESSION['flash'];
    unset($_SESSION['flash']);
    $tipe = in_array($f['tipe'], ['success','danger','warning','info'], true) ? $f['tipe'] : 'info';
    return '<div class="alert alert-' . $tipe . ' alert-dismissible fade show" role="alert">'
         . e($f['pesan'])
         . '<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>';
}

/** Potong teks */
function potong(string $text, int $limit = 120): string
{
    $text = trim(strip_tags($text));
    if (mb_strlen($text) <= $limit) return $text;
    return mb_substr($text, 0, $limit) . '...';
}

/**
 * Upload gambar dengan validasi
 * @return array ['sukses'=>bool, 'file'=>string|null, 'error'=>string|null]
 */
function upload_gambar(array $file, string $folder = 'mobil', int $maxMB = 2): array
{
    if (!isset($file['error']) || is_array($file['error'])) {
        return ['sukses' => false, 'file' => null, 'error' => 'Parameter upload tidak valid.'];
    }

    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['sukses' => false, 'file' => null, 'error' => null]; // tidak ada file
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['sukses' => false, 'file' => null, 'error' => 'Gagal mengunggah file (kode: ' . $file['error'] . ').'];
    }

    // Batas ukuran
    if ($file['size'] > $maxMB * 1024 * 1024) {
        return ['sukses' => false, 'file' => null, 'error' => "Ukuran file maksimal {$maxMB} MB."];
    }

    // Validasi tipe MIME
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
    ];

    if (!isset($allowed[$mime])) {
        return ['sukses' => false, 'file' => null, 'error' => 'Format gambar harus JPG, PNG, WEBP, atau GIF.'];
    }

    // Pastikan folder ada
    $dir = UPLOAD_PATH . $folder . '/';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }

    // Generate nama unik
    $namaBaru = date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $allowed[$mime];

    if (!move_uploaded_file($file['tmp_name'], $dir . $namaBaru)) {
        return ['sukses' => false, 'file' => null, 'error' => 'Gagal menyimpan file di server.'];
    }

    return ['sukses' => true, 'file' => $namaBaru, 'error' => null];
}

/**
 * Hapus file gambar dari folder upload
 */
function hapus_gambar(?string $file, string $folder = 'mobil'): void
{
    if (!$file) return;
    $path = UPLOAD_PATH . $folder . '/' . $file;
    if (is_file($path)) {
        @unlink($path);
    }
}