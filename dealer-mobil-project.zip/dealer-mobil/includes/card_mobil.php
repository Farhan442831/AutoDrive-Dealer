<?php
/**
 * Partial: Kartu Mobil
 * Lokasi: includes/card_mobil.php
 * Variabel yang dibutuhkan: $m (array data mobil + nama_merek)
 */
$pesanWa = 'Halo, saya tertarik dengan ' . $m['nama_mobil'] . ' ' . $m['tahun']
         . ' dengan harga ' . rupiah($m['harga']) . '. Saya ingin mendapatkan informasi lebih lanjut.';
?>
<div class="car-card">
  <div class="car-thumb">
    <a href="<?= BASE_URL ?>detail_mobil.php?id=<?= (int)$m['id'] ?>">
      <img src="<?= img_mobil($m['foto_utama']) ?>"
           alt="<?= e($m['nama_mobil']) ?>" loading="lazy">
    </a>
    <div class="car-badges">
      <span class="<?= badge_mobil($m['status']) ?>"><?= e($m['status']) ?></span>
      <?php if (!empty($m['unggulan'])): ?>
        <span class="badge badge-unggulan"><i class="fa-solid fa-star me-1"></i>Pilihan</span>
      <?php endif; ?>
    </div>
  </div>

  <div class="car-body">
    <div class="car-merek"><?= e($m['nama_merek']) ?></div>
    <h6 class="car-nama">
      <a href="<?= BASE_URL ?>detail_mobil.php?id=<?= (int)$m['id'] ?>">
        <?= e($m['nama_mobil']) ?>
      </a>
    </h6>
    <div class="car-harga"><?= rupiah($m['harga']) ?></div>

    <div class="car-specs">
      <span><i class="fa-regular fa-calendar"></i><?= (int)$m['tahun'] ?></span>
      <span><i class="fa-solid fa-gauge-high"></i><?= km($m['kilometer']) ?></span>
      <span><i class="fa-solid fa-gear"></i><?= e($m['transmisi']) ?></span>
      <span><i class="fa-solid fa-gas-pump"></i><?= e($m['bahan_bakar']) ?></span>
    </div>

    <div class="car-actions">
      <a href="<?= BASE_URL ?>detail_mobil.php?id=<?= (int)$m['id'] ?>" class="btn btn-navy">
        <i class="fa-solid fa-circle-info me-1"></i> Detail
      </a>
      <a href="<?= wa_link($pesanWa) ?>" target="_blank" rel="noopener"
         class="btn btn-wa btn-icon" title="Chat WhatsApp">
        <i class="fa-brands fa-whatsapp"></i>
      </a>
    </div>
  </div>
</div>