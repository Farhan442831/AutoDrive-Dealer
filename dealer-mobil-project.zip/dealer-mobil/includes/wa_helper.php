<?php
/**
 * Helper template WhatsApp
 * Lokasi: includes/wa_helper.php
 */

/** Ambil nomor WA admin utama */
function wa_admin(): string
{
    return setting('whatsapp', '6281234567890');
}

/* =====================================================================
   TEST DRIVE
   ===================================================================== */

/** Template pesan WA untuk customer berdasarkan status test drive */
function wa_template_test_drive(array $td, string $status): string
{
    $dealer  = setting('nama_dealer', 'Dealer');
    $alamat  = setting('alamat', '');
    $telepon = setting('telepon', '');
    $nama    = $td['nama'] ?? 'Bapak/Ibu';
    $mobil   = trim(($td['nama_merek'] ?? '') . ' ' . ($td['nama_mobil'] ?? ''));
    $tanggal = isset($td['tanggal']) ? tanggal_id($td['tanggal']) : '';
    $jam     = isset($td['jam']) ? substr($td['jam'], 0, 5) : '';

    switch ($status) {
        case 'Pending':
            return "Halo {$nama}, terima kasih telah mengajukan test drive untuk {$mobil} di {$dealer}.\n\n"
                 . "Pengajuan Anda sudah kami terima dan akan segera diproses. "
                 . "Mohon tunggu kabar dari kami maksimal 1x24 jam.\n\n"
                 . "Terima kasih.";

        case 'Diproses':
            return "Halo {$nama}, pengajuan test drive Anda untuk {$mobil} sedang kami proses.\n\n"
                 . "Tim kami akan menghubungi Anda kembali untuk konfirmasi jadwal.\n\n"
                 . "Terima kasih.";

        case 'Disetujui':
            return "Halo {$nama}, pengajuan test drive Anda telah kami setujui.\n\n"
                 . "Detail jadwal:\n"
                 . "- Mobil: {$mobil}\n"
                 . "- Tanggal: {$tanggal}\n"
                 . "- Jam: {$jam} WIB\n"
                 . "- Lokasi: {$alamat}\n\n"
                 . "Mohon membawa KTP asli dan SIM A yang masih berlaku.\n\n"
                 . "Jika ada perubahan jadwal, silakan hubungi kami di {$telepon}.\n\n"
                 . "Terima kasih.";

        case 'Selesai':
            return "Halo {$nama}, terima kasih telah melakukan test drive di {$dealer}.\n\n"
                 . "Jika ingin melanjutkan ke tahap pembelian atau ada pertanyaan lain, "
                 . "silakan hubungi kami kembali. Kami siap membantu.\n\n"
                 . "Salam,\n{$dealer}";

        case 'Ditolak':
            return "Halo {$nama}, mohon maaf pengajuan test drive Anda untuk {$mobil} "
                 . "belum dapat kami proses saat ini.\n\n"
                 . "Anda tetap bisa mengajukan jadwal ulang atau memilih unit lain. "
                 . "Silakan hubungi kami di {$telepon}.\n\n"
                 . "Terima kasih.";

        default:
            return "Halo {$nama}, terima kasih telah menghubungi {$dealer}.";
    }
}

/** Notifikasi ke admin saat ada pengajuan test drive baru */
function wa_notif_admin_test_drive(array $td): string
{
    $nama    = $td['nama'] ?? '-';
    $wa      = $td['whatsapp'] ?? '-';
    $email   = $td['email'] ?: '-';
    $mobil   = trim(($td['nama_merek'] ?? '') . ' ' . ($td['nama_mobil'] ?? '-'));
    $tanggal = isset($td['tanggal']) ? tanggal_id($td['tanggal']) : '-';
    $jam     = isset($td['jam']) ? substr($td['jam'], 0, 5) : '-';
    $catatan = $td['catatan'] ?: '-';

    return "Pengajuan Test Drive Baru\n\n"
         . "Nama: {$nama}\n"
         . "WhatsApp: {$wa}\n"
         . "Email: {$email}\n"
         . "Mobil: {$mobil}\n"
         . "Tanggal: {$tanggal}\n"
         . "Jam: {$jam} WIB\n"
         . "Catatan: {$catatan}\n\n"
         . "Mohon dicek di dashboard admin untuk diproses.";
}

/* =====================================================================
   JUAL MOBIL
   ===================================================================== */

/** Template pesan WA untuk customer berdasarkan status jual mobil */
function wa_template_jual_mobil(array $jm, string $status): string
{
    $dealer  = setting('nama_dealer', 'Dealer');
    $telepon = setting('telepon', '');
    $nama    = $jm['nama'] ?? 'Bapak/Ibu';
    $mobil   = trim(($jm['merek'] ?? '') . ' ' . ($jm['model'] ?? '') . ' ' . ($jm['tahun'] ?? ''));

    switch ($status) {
        case 'Pending':
            return "Halo {$nama}, terima kasih telah mengajukan penjualan mobil {$mobil} ke {$dealer}.\n\n"
                 . "Pengajuan Anda sudah kami terima. Tim penilai kami akan segera mereview data kendaraan Anda.\n\n"
                 . "Mohon tunggu kabar dari kami maksimal 1x24 jam.\n\n"
                 . "Terima kasih.";

        case 'Diproses':
            return "Halo {$nama}, pengajuan penjualan mobil {$mobil} Anda sedang kami proses.\n\n"
                 . "Tim kami akan menghubungi Anda untuk penjadwalan inspeksi kendaraan.\n\n"
                 . "Mohon ditunggu.\n\n"
                 . "Terima kasih.";

        case 'Dihubungi':
            return "Halo {$nama}, tim kami akan segera menghubungi Anda terkait penjualan mobil {$mobil}.\n\n"
                 . "Mohon pastikan nomor WhatsApp Anda aktif. Untuk info lebih cepat, hubungi kami di {$telepon}.\n\n"
                 . "Terima kasih.";

        case 'Selesai':
            return "Halo {$nama}, transaksi penjualan mobil {$mobil} telah selesai.\n\n"
                 . "Terima kasih telah mempercayai {$dealer}. Semoga rezeki Anda semakin lancar.\n\n"
                 . "Jika butuh bantuan lain, jangan ragu hubungi kami kembali.";

        case 'Ditolak':
            return "Halo {$nama}, mohon maaf saat ini penjualan mobil {$mobil} belum dapat kami proses.\n\n"
                 . "Alasannya bisa berupa kondisi, harga, atau stok. Silakan hubungi kami di {$telepon} untuk diskusi lebih lanjut.\n\n"
                 . "Terima kasih.";

        default:
            return "Halo {$nama}, terima kasih telah menghubungi {$dealer}.";
    }
}

/** Notifikasi ke admin saat ada pengajuan jual mobil baru */
function wa_notif_admin_jual_mobil(array $jm): string
{
    $nama    = $jm['nama'] ?? '-';
    $wa      = $jm['whatsapp'] ?? '-';
    $email   = $jm['email'] ?: '-';
    $mobil   = trim(($jm['merek'] ?? '') . ' ' . ($jm['model'] ?? '') . ' ' . ($jm['tahun'] ?? ''));
    $km      = isset($jm['kilometer']) ? number_format((int)$jm['kilometer'], 0, ',', '.') . ' KM' : '-';
    $harga   = isset($jm['harga_harapan']) ? rupiah($jm['harga_harapan']) : '-';
    $kondisi = $jm['kondisi'] ?: '-';

    return "Pengajuan Jual Mobil Baru\n\n"
         . "Nama: {$nama}\n"
         . "WhatsApp: {$wa}\n"
         . "Email: {$email}\n"
         . "Mobil: {$mobil}\n"
         . "Kilometer: {$km}\n"
         . "Harga Harapan: {$harga}\n"
         . "Kondisi: {$kondisi}\n\n"
         . "Mohon dicek di dashboard admin untuk diproses.";
}

/* =====================================================================
   TUKAR TAMBAH
   ===================================================================== */

/** Template pesan WA untuk customer berdasarkan status tukar tambah */
function wa_template_tukar_tambah(array $tt, string $status): string
{
    $dealer  = setting('nama_dealer', 'Dealer');
    $telepon = setting('telepon', '');
    $nama    = $tt['nama'] ?? 'Bapak/Ibu';
    $mobil   = trim(($tt['merek'] ?? '') . ' ' . ($tt['model'] ?? '') . ' ' . ($tt['tahun'] ?? ''));

    switch ($status) {
        case 'Pending':
            return "Halo {$nama}, terima kasih telah mengajukan tukar tambah mobil {$mobil} di {$dealer}.\n\n"
                 . "Pengajuan Anda sudah kami terima dan akan segera diproses.\n\n"
                 . "Mohon tunggu kabar dari kami maksimal 1x24 jam.\n\n"
                 . "Terima kasih.";

        case 'Diproses':
            return "Halo {$nama}, pengajuan tukar tambah mobil {$mobil} Anda sedang kami proses.\n\n"
                 . "Tim kami akan menghubungi Anda untuk penjadwalan inspeksi dan penilaian kendaraan.\n\n"
                 . "Terima kasih.";

        case 'Dihubungi':
            return "Halo {$nama}, tim kami akan segera menghubungi Anda terkait tukar tambah mobil {$mobil}.\n\n"
                 . "Mohon standby di WhatsApp. Untuk info cepat, hubungi {$telepon}.\n\n"
                 . "Terima kasih.";

        case 'Selesai':
            return "Halo {$nama}, proses tukar tambah mobil {$mobil} telah selesai.\n\n"
                 . "Terima kasih telah mempercayai {$dealer}. Semoga unit barunya membawa keberkahan.\n\n"
                 . "Salam hangat dari kami.";

        case 'Ditolak':
            return "Halo {$nama}, mohon maaf pengajuan tukar tambah mobil {$mobil} belum dapat kami proses saat ini.\n\n"
                 . "Silakan hubungi kami di {$telepon} untuk alternatif lain atau diskusi lebih lanjut.\n\n"
                 . "Terima kasih.";

        default:
            return "Halo {$nama}, terima kasih telah menghubungi {$dealer}.";
    }
}

/** Notifikasi ke admin saat ada pengajuan tukar tambah baru */
function wa_notif_admin_tukar_tambah(array $tt): string
{
    $nama   = $tt['nama'] ?? '-';
    $wa     = $tt['whatsapp'] ?? '-';
    $email  = $tt['email'] ?: '-';
    $mobil  = trim(($tt['merek'] ?? '') . ' ' . ($tt['model'] ?? '') . ' ' . ($tt['tahun'] ?? ''));
    $target = trim(($tt['target_merek'] ?? '') . ' ' . ($tt['target_mobil'] ?? ''));
    $harga  = isset($tt['harga_perkiraan']) ? rupiah($tt['harga_perkiraan']) : '-';

    return "Pengajuan Tukar Tambah Baru\n\n"
         . "Nama: {$nama}\n"
         . "WhatsApp: {$wa}\n"
         . "Email: {$email}\n"
         . "Mobil Ditukar: {$mobil}\n"
         . "Harga Perkiraan: {$harga}\n"
         . "Mobil Diminati: {$target}\n\n"
         . "Mohon dicek di dashboard admin untuk diproses.";
}