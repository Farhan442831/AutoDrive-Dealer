<?php
/**
 * Navbar utama
 * Lokasi: includes/navbar.php
 */
$menuUtama = [
    'index.php'   => 'Home',
    'katalog.php' => 'Katalog Mobil',
];
$menuLayanan = [
    'test_drive.php'      => 'Booking Test Drive',
    'jual_mobil.php'      => 'Jual Mobil',
    'tukar_tambah.php'    => 'Tukar Tambah',
    'simulasi_kredit.php' => 'Simulasi Kredit',
];
$menuKonten = [
    'promo.php'   => 'Promo',
    'artikel.php' => 'Artikel',
    'tentang.php' => 'Tentang Kami',
    'kontak.php'  => 'Kontak',
];

$current = basename($_SERVER['PHP_SELF']);
$user = $_SESSION['user'] ?? null;

function menuAktif(array $menu, string $current): bool {
    return array_key_exists($current, $menu);
}

// Tentukan sumber logo
$logoSrc = '';
if (setting('logo')) {
    $pathLogo = UPLOAD_PATH . 'logo/' . setting('logo');
    if (is_file($pathLogo)) {
        $logoSrc = UPLOAD_URL . 'logo/' . rawurlencode(setting('logo'));
    }
}
if (!$logoSrc) {
    $logoSrc = BASE_URL . 'assets/images/logo.svg';
}
?>
<nav class="navbar navbar-expand-lg navbar-main sticky-top" id="mainNavbar">
  <div class="container">

    <a class="navbar-brand" href="<?= BASE_URL ?>index.php">
      <img src="<?= $logoSrc ?>" alt="<?= e(setting('nama_dealer', 'AutoDrive')) ?>" class="navbar-logo">
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navUtama"
            aria-controls="navUtama" aria-expanded="false" aria-label="Buka menu">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navUtama">
      <ul class="navbar-nav mx-auto mb-3 mb-lg-0">

        <?php foreach ($menuUtama as $file => $label): ?>
          <li class="nav-item">
            <a class="nav-link <?= $current === $file ? 'active' : '' ?>"
               href="<?= BASE_URL . $file ?>"><?= e($label) ?></a>
          </li>
        <?php endforeach; ?>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle <?= menuAktif($menuLayanan, $current) ? 'active' : '' ?>"
             href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Layanan
          </a>
          <ul class="dropdown-menu shadow-sm">
            <?php foreach ($menuLayanan as $file => $label):
              $icon = match($file) {
                'test_drive.php'      => 'fa-car-side',
                'jual_mobil.php'      => 'fa-hand-holding-dollar',
                'tukar_tambah.php'    => 'fa-right-left',
                'simulasi_kredit.php' => 'fa-calculator',
                default               => 'fa-circle'
              };
            ?>
              <li>
                <a class="dropdown-item <?= $current === $file ? 'active' : '' ?>"
                   href="<?= BASE_URL . $file ?>">
                  <i class="fa-solid <?= $icon ?> me-2"></i><?= e($label) ?>
                </a>
              </li>
            <?php endforeach; ?>
          </ul>
        </li>

        <?php foreach ($menuKonten as $file => $label): ?>
          <li class="nav-item">
            <a class="nav-link <?= $current === $file ? 'active' : '' ?>"
               href="<?= BASE_URL . $file ?>"><?= e($label) ?></a>
          </li>
        <?php endforeach; ?>

      </ul>

      <div class="nav-actions d-flex flex-column flex-lg-row align-items-stretch align-items-lg-center gap-2">
        <a href="<?= wa_link('Halo, saya ingin bertanya mengenai mobil yang tersedia di ' . setting('nama_dealer')) ?>"
           target="_blank" rel="noopener" class="btn btn-wa">
          <i class="fa-brands fa-whatsapp"></i> WhatsApp
        </a>

        <?php if ($user): ?>
          <div class="dropdown">
            <button class="btn btn-akun dropdown-toggle" type="button" data-bs-toggle="dropdown">
              <span class="avatar-mini"><?= e(inisial($user['nama'])) ?></span>
              <span class="d-none d-xl-inline"><?= e(explode(' ', $user['nama'])[0]) ?></span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow-sm">
              <?php if (in_array($user['role'], ['admin','sales'], true)): ?>
                <li><a class="dropdown-item" href="<?= BASE_URL ?>admin/index.php">
                  <i class="fa-solid fa-gauge-high me-2"></i>Dashboard Admin</a></li>
                <li><hr class="dropdown-divider"></li>
              <?php endif; ?>
              <li><a class="dropdown-item" href="<?= BASE_URL ?>akun.php">
                <i class="fa-regular fa-user me-2"></i>Akun Saya</a></li>
              <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>logout.php">
                <i class="fa-solid fa-arrow-right-from-bracket me-2"></i>Logout</a></li>
            </ul>
          </div>
        <?php else: ?>
          <a href="<?= BASE_URL ?>login.php" class="btn btn-outline-light-nav">
            <i class="fa-regular fa-user"></i> Masuk
          </a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>