<?php
/**
 * Header global
 * Lokasi: includes/header.php
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

$pageTitle = $pageTitle ?? setting('nama_dealer', 'Dealer Mobil');
$pageDesc  = $pageDesc  ?? setting('footer_text');
$bodyClass = $bodyClass ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title><?= e($pageTitle) ?> | <?= e(setting('nama_dealer', 'AutoPrime Motor')) ?></title>
<meta name="description" content="<?= e(potong($pageDesc, 160)) ?>">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link href="<?= BASE_URL ?>assets/css/style.css" rel="stylesheet">
<link href="<?= BASE_URL ?>assets/css/polish.css" rel="stylesheet">
</head>
<body class="<?= e($bodyClass) ?>">

<?php include __DIR__ . '/navbar.php'; ?>

<?php if ($flash = tampil_flash()): ?>
  <div class="container mt-3"><?= $flash ?></div>
<?php endif; ?>