<?php
/**
 * Login
 * Lokasi: login.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

if (!empty($_SESSION['user'])) {
    header('Location: ' . BASE_URL . 'index.php');
    exit;
}

$pageTitle = 'Masuk';
$errors = [];
$redirect = $_GET['redirect'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $redirect = $_POST['redirect'] ?? '';

    if ($email === '' || $password === '') {
        $errors[] = 'Email dan password wajib diisi.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if (!$user) {
            $errors[] = 'Email atau password salah.';
        } elseif ($user['status'] !== 'aktif') {
            $errors[] = 'Akun Anda tidak aktif. Hubungi administrator.';
        } elseif (!password_verify($password, $user['password'])) {
            $errors[] = 'Email atau password salah.';
        } else {
            // Login berhasil
            session_regenerate_id(true);
            $_SESSION['user'] = [
                'id'          => $user['id'],
                'nama'        => $user['nama'],
                'email'       => $user['email'],
                'role'        => $user['role'],
                'no_whatsapp' => $user['no_whatsapp'],
            ];

            set_flash('success', 'Selamat datang, ' . $user['nama'] . '!');

            if ($redirect && str_starts_with($redirect, BASE_URL)) {
                header('Location: ' . $redirect);
            } elseif (in_array($user['role'], ['admin','sales'], true)) {
                header('Location: ' . BASE_URL . 'admin/index.php');
            } else {
                header('Location: ' . BASE_URL . 'index.php');
            }
            exit;
        }
    }
}

include __DIR__ . '/includes/header.php';
?>

<section class="section">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-5 col-md-8">
        <div class="detail-box">
          <div class="text-center mb-4">
            <div class="brand-mark mx-auto mb-3" style="width:56px;height:56px;font-size:22px">
              <i class="fa-solid fa-right-to-bracket"></i>
            </div>
            <h3 class="mb-1">Masuk ke Akun Anda</h3>
            <p class="text-muted mb-0" style="font-size:14px">
              Silakan masukkan email dan password Anda.
            </p>
          </div>

          <?php if ($errors): ?>
            <div class="alert alert-danger">
              <?php foreach ($errors as $err): ?><div><?= e($err) ?></div><?php endforeach; ?>
            </div>
          <?php endif; ?>

          <form method="post">
            <input type="hidden" name="redirect" value="<?= e($redirect) ?>">
            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control" required autofocus
                     value="<?= e($_POST['email'] ?? '') ?>">
            </div>
            <div class="mb-3">
              <label class="form-label">Password</label>
              <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-brand w-100">
              <i class="fa-solid fa-right-to-bracket me-2"></i>Masuk
            </button>
          </form>

          <div class="divider my-4"></div>

          <div class="text-center" style="font-size:14px">
            Belum punya akun?
            <a href="<?= BASE_URL ?>register.php" class="fw-bold">Daftar sekarang</a>
          </div>
      </div>
    </div>
  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>