<?php
/**
 * Jual Mobil (Form Customer)
 * Lokasi: jual_mobil.php
 */
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/wa_helper.php';

$pageTitle = 'Jual Mobil Anda';
$pageDesc  = 'Jual mobil Anda ke ' . setting('nama_dealer') . ' dengan proses cepat dan harga bersaing.';

$user = $_SESSION['user'] ?? null;
$errors = [];
$sukses = false;
$notifWaUrl = null;
$namaCustomer = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama          = trim($_POST['nama'] ?? '');
    $whatsapp      = trim($_POST['whatsapp'] ?? '');
    $email         = trim($_POST['email'] ?? '');
    $merek         = trim($_POST['merek'] ?? '');
    $model         = trim($_POST['model'] ?? '');
    $tahun         = (int)($_POST['tahun'] ?? 0);
    $kilometer     = (int)str_replace(['.', ',', ' '], '', $_POST['kilometer'] ?? '0');
    $transmisi     = $_POST['transmisi'] ?? 'Manual';
    $harga_harapan = (int)str_replace(['.', ',', ' '], '', $_POST['harga_harapan'] ?? '0');
    $kondisi       = trim($_POST['kondisi'] ?? '');
    $catatan       = trim($_POST['catatan'] ?? '');

    if ($nama === '')                     $errors[] = 'Nama lengkap wajib diisi.';
    if ($whatsapp === '')                 $errors[] = 'Nomor WhatsApp wajib diisi.';
    elseif (!preg_match('/^[0-9+\-\s]{8,20}$/', $whatsapp)) $errors[] = 'Format WhatsApp tidak valid.';
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Format email tidak valid.';
    if ($merek === '')                    $errors[] = 'Merek mobil wajib diisi.';
    if ($model === '')                    $errors[] = 'Model mobil wajib diisi.';
    if ($tahun < 1990 || $tahun > (int)date('Y') + 1) $errors[] = 'Tahun tidak valid.';
    if (!in_array($transmisi, ['Manual','Automatic'], true)) $errors[] = 'Transmisi tidak valid.';
    if ($harga_harapan <= 0)              $errors[] = 'Harga harapan wajib diisi.';

    // Upload foto (opsional)
    $foto = null;
    if (!empty($_FILES['foto']['name'])) {
        $up = upload_gambar($_FILES['foto'], 'jual-mobil');
        if ($up['sukses']) {
            $foto = $up['file'];
        } elseif ($up['error']) {
            $errors[] = 'Foto kendaraan: ' . $up['error'];
        }
    }

    if (!$errors) {
        $stmt = $pdo->prepare("
            INSERT INTO jual_mobil
            (user_id, nama, whatsapp, email, merek, model, tahun, kilometer, transmisi,
             harga_harapan, kondisi, foto, catatan, status)
            VALUES
            (:uid, :nama, :wa, :email, :merek, :model, :tahun, :km, :tr,
             :harga, :kondisi, :foto, :catatan, 'Pending')
        ");
        $stmt->execute([
            ':uid'     => $user['id'] ?? null,
            ':nama'    => $nama,
            ':wa'      => $whatsapp,
            ':email'   => $email ?: null,
            ':merek'   => $merek,
            ':model'   => $model,
            ':tahun'   => $tahun,
            ':km'      => $kilometer,
            ':tr'      => $transmisi,
            ':harga'   => $harga_harapan,
            ':kondisi' => $kondisi ?: null,
            ':foto'    => $foto,
            ':catatan' => $catatan ?: null,
        ]);

        $jmId = (int)$pdo->lastInsertId();

        $stmtN = $pdo->prepare("SELECT * FROM jual_mobil WHERE id = :id");
        $stmtN->execute([':id' => $jmId]);
        $jmData = $stmtN->fetch();

        $_SESSION['jm_sukses'] = [
            'nama'  => $nama,
            'notif' => wa_link(wa_notif_admin_jual_mobil($jmData), wa_admin()),
        ];

        header('Location: ' . BASE_URL . 'jual_mobil.php?sukses=1');
        exit;
    }
}

if (!empty($_GET['sukses']) && !empty($_SESSION['jm_sukses'])) {
    $sukses = true;
    $notifWaUrl = $_SESSION['jm_sukses']['notif'];
    $namaCustomer = $_SESSION['jm_sukses']['nama'];
    unset($_SESSION['jm_sukses']);
}

include __DIR__ . '/includes/header.php';
?>

<div class="breadcrumb-bar">
  <div class="container">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-2">
        <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Home</a></li>
        <li class="breadcrumb-item active">Jual Mobil</li>
      </ol>
    </nav>
    <h1>Jual Mobil Anda</h1>
    <p class="mb-0" style="color:rgba(255,255,255,.7);font-size:14px">
      Isi form di bawah, tim kami akan menilai dan menghubungi Anda.
    </p>
  </div>
</div>

<section class="section">
  <div class="container">
    <div class="row g-4">

      <div class="col-lg-7">
        <?php if ($sukses): ?>
          <div class="detail-box" style="border:2px solid #25d366">
            <div class="text-center mb-4">
              <div style="width:64px;height:64px;border-radius:50%;background:#25d366;color:#fff;display:grid;place-items:center;margin:0 auto 14px;font-size:28px">
                <i class="fa-solid fa-check"></i>
              </div>
              <h3 class="mb-2">Pengajuan Berhasil Dikirim</h3>
              <p class="text-muted mb-0" style="font-size:14.5px">
                Terima kasih, <strong><?= e($namaCustomer) ?></strong>.
                Tim kami akan mereview data kendaraan Anda dan menghubungi Anda.
              </p>
            </div>

            <div style="background:#f5f7fa;border-radius:12px;padding:20px;text-align:center;margin-bottom:16px">
              <p class="mb-3" style="font-size:14px">
                Kirim notifikasi ke admin agar pengajuan Anda diproses lebih cepat.
              </p>
              <a href="<?= e($notifWaUrl) ?>" target="_blank" rel="noopener" class="btn btn-wa btn-lg">
                <i class="fa-brands fa-whatsapp me-2"></i>Kirim Notifikasi ke Admin
              </a>
            </div>

            <div class="text-center text-muted" style="font-size:13px">
              <a href="<?= BASE_URL ?>katalog.php">Kembali ke katalog</a> &middot;
              <a href="<?= BASE_URL ?>index.php">Halaman utama</a>
            </div>
          </div>
        <?php else: ?>

          <?php if ($errors): ?>
            <div class="alert alert-danger">
              <strong>Periksa kembali data Anda:</strong>
              <ul class="mb-0 mt-2 ps-3">
                <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
              </ul>
            </div>
          <?php endif; ?>

          <div class="detail-box">
            <h5 class="detail-heading"><i class="fa-solid fa-hand-holding-dollar"></i> Form Pengajuan Jual Mobil</h5>

            <form method="post" enctype="multipart/form-data" novalidate>
              <h6 class="mb-3 mt-2" style="font-size:14px;color:var(--ink-500)">Data Diri</h6>
              <div class="row g-3 mb-3">
                <div class="col-md-6">
                  <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                  <input type="text" name="nama" class="form-control" required
                         value="<?= e($_POST['nama'] ?? $user['nama'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Nomor WhatsApp <span class="text-danger">*</span></label>
                  <input type="text" name="whatsapp" class="form-control" required
                         placeholder="08xxxxxxxxxx"
                         value="<?= e($_POST['whatsapp'] ?? $user['no_whatsapp'] ?? '') ?>">
                </div>
                <div class="col-12">
                  <label class="form-label">Email</label>
                  <input type="email" name="email" class="form-control"
                         value="<?= e($_POST['email'] ?? $user['email'] ?? '') ?>">
                </div>
              </div>

              <hr class="my-4">

              <h6 class="mb-3" style="font-size:14px;color:var(--ink-500)">Data Kendaraan</h6>
              <div class="row g-3 mb-3">
                <div class="col-md-6">
                  <label class="form-label">Merek <span class="text-danger">*</span></label>
                  <input type="text" name="merek" class="form-control" required
                         placeholder="Toyota"
                         value="<?= e($_POST['merek'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Model <span class="text-danger">*</span></label>
                  <input type="text" name="model" class="form-control" required
                         placeholder="Avanza"
                         value="<?= e($_POST['model'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Tahun <span class="text-danger">*</span></label>
                  <input type="number" name="tahun" class="form-control" required
                         min="1990" max="<?= date('Y') + 1 ?>"
                         value="<?= e($_POST['tahun'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Kilometer</label>
                  <input type="number" name="kilometer" class="form-control" min="0"
                         placeholder="45000"
                         value="<?= e($_POST['kilometer'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                  <label class="form-label">Transmisi</label>
                  <select name="transmisi" class="form-select">
                    <option value="Manual"    <?= ($_POST['transmisi'] ?? '') === 'Manual'    ? 'selected' : '' ?>>Manual</option>
                    <option value="Automatic" <?= ($_POST['transmisi'] ?? '') === 'Automatic' ? 'selected' : '' ?>>Automatic</option>
                  </select>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Harga Harapan (Rp) <span class="text-danger">*</span></label>
                  <input type="number" name="harga_harapan" class="form-control" required min="0" step="1000000"
                         placeholder="180000000"
                         value="<?= e($_POST['harga_harapan'] ?? '') ?>">
                </div>
                <div class="col-12">
                  <label class="form-label">Kondisi Kendaraan</label>
                  <textarea name="kondisi" class="form-control" rows="3"
                            placeholder="Contoh: Terawat, servis rutin, tidak ada tabrakan."><?= e($_POST['kondisi'] ?? '') ?></textarea>
                </div>
                <div class="col-12">
                  <label class="form-label">Foto Kendaraan</label>
                  <input type="file" name="foto" class="form-control" accept="image/*">
                  <small class="form-text">JPG/PNG/WEBP max 2 MB. Foto tampak depan atau samping.</small>
                </div>
                <div class="col-12">
                  <label class="form-label">Catatan Tambahan</label>
                  <textarea name="catatan" class="form-control" rows="2"><?= e($_POST['catatan'] ?? '') ?></textarea>
                </div>
              </div>

              <button type="submit" class="btn btn-brand btn-lg w-100">
                <i class="fa-solid fa-paper-plane me-2"></i>Kirim Pengajuan
              </button>
            </form>
          </div>
        <?php endif; ?>
      </div>

      <div class="col-lg-5">
        <div class="detail-box mb-4">
          <h5 class="detail-heading"><i class="fa-solid fa-list-ol"></i> Cara Kerja</h5>
          <div class="info-mini">
            <div class="d-flex gap-3 mb-3">
              <i class="fa-solid fa-1"></i>
              <div>
                <strong>Isi Form</strong>
                <p class="mb-0">Lengkapi data kendaraan dan harga harapan Anda.</p>
              </div>
            </div>
            <div class="d-flex gap-3 mb-3">
              <i class="fa-solid fa-2"></i>
              <div>
                <strong>Kami Review</strong>
                <p class="mb-0">Tim kami menilai kendaraan dalam 1x24 jam.</p>
              </div>
            </div>
            <div class="d-flex gap-3 mb-3">
              <i class="fa-solid fa-3"></i>
              <div>
                <strong>Inspeksi</strong>
                <p class="mb-0">Inspeksi langsung di lokasi Anda atau kantor kami.</p>
              </div>
            </div>
            <div class="d-flex gap-3">
              <i class="fa-solid fa-4"></i>
              <div>
                <strong>Pembayaran</strong>
                <p class="mb-0">Jika deal, pembayaran langsung transfer ke rekening Anda.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="p-4 rounded-lg" style="background:linear-gradient(160deg,#0f2440,#1b3a66);color:#fff">
          <h6 class="text-white mb-2"><i class="fa-brands fa-whatsapp me-2"></i>Butuh Bantuan?</h6>
          <p style="color:rgba(255,255,255,.75);font-size:13.5px">
            Tanya-tanya dulu saja juga tidak masalah.
          </p>
          <a href="<?= wa_link('Halo, saya ingin menanyakan proses jual mobil') ?>"
             target="_blank" rel="noopener" class="btn btn-wa w-100">
            <i class="fa-brands fa-whatsapp me-2"></i>Chat Sekarang
          </a>
        </div>
      </div>

    </div>
  </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>